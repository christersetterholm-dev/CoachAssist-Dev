import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { RotateCcw, Trophy, ArrowLeft, Check, Sun, Moon, Timer as TimerIcon, Edit2, Zap, Rocket, Users, LayoutDashboard, Unlock, LogIn, LogOut, User as UserIcon, ShieldCheck, Cloud, Globe, AlertTriangle, Calendar, Settings, RefreshCw, Bell, Building2, Shirt, VibrateOff } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { SquadPlayer, Exercise, Team, PointsConfig, Period, PeriodStandings, Lineup, TrainingSession, TrainingSettings, CoachData, BankExercise, SessionMoment, UserProfile, ClubMember, ClubTeam, Club } from './types';
import { auth, signInWithGoogle, db, handleFirestoreError, OperationType, getApiUrl, doc, onSnapshot, setDoc, getDoc, collection, getDocs, onAuthStateChanged, signOut, User } from './lib/firebase';
import { calculateLeaderboard } from './lib/leaderboardUtils';
import { syncSquadToClubMembers, getMergedSquadAndClubMembers, deduplicateSquad } from './lib/clubUtils';

import GameSetup from './components/GameSetup';
import PlayerCard from './components/PlayerCard';
import Timer from './components/Timer';
import SquadManager from './components/SquadManager';
import Leaderboard from './components/Leaderboard';
import LineupBuilder from './components/LineupBuilder';

import TeamPage from './components/TeamPage';
import TrainingManager from './components/TrainingManager';
import SessionEditor from './components/SessionEditor';
import TeamOverviewModal from './components/TeamOverviewModal';

import ProfileAndSettings from './components/ProfileAndSettings';
import ClubAdminDashboard from './components/ClubAdminDashboard';
import VersionFooter from './components/VersionFooter';
import { OnboardingModal } from './components/OnboardingModal';
import { PendingRequestsModal } from './components/PendingRequestsModal';
import { ShakeProtectionModal, QuickShakeModal } from './components/ShakeProtectionModal';

type View = 'training' | 'setup' | 'exercise' | 'squad' | 'leaderboard' | 'profile' | 'lineup' | 'teampage' | 'clubadmin';

const INITIAL_DATA: CoachData = {
  squad: [],
  exercises: [],
  sessions: [],
  deletedSessions: [],
  lineups: [],
  activeLineupId: null,
  periods: [],
  currentPeriodId: null,
  activeExerciseId: null,
  teamUrl: '',
  adminUrl: '',
  seriesUrl: '',
  customFormations: [],
  pinnedFormationIds: ['4-2-3-1', '4-4-2', '4-3-3'],
  trainingSettings: {
    defaultStartTime: '18:00',
    defaultDuration: 90,
    icsUrl: 'webcal://cal.laget.se/KSKSeniorer.ics'
  },
  exerciseBank: [],
  exerciseBankCategories: []
};

const getSessionCategory = (session: TrainingSession): 'match' | 'training' | 'other' => {
  const title = (session.title || '').trim().toLowerCase();
  if (!title) {
    return 'training';
  }
  if (
    title.includes('match') || 
    title.includes('vs') || 
    title.includes('mot') || 
    title.includes('seriematch') || 
    title.includes('cup') || 
    title.includes('kval') || 
    title.includes('träningsmatch')
  ) {
    return 'match';
  }
  if (
    title.includes('träning') || 
    title.includes('pass') || 
    title.includes('fys') || 
    title.includes('praktik') || 
    title.includes('istid') || 
    title.includes('poolspel')
  ) {
    return 'training';
  }
  return 'other';
};

const isQuotaError = (error: any): boolean => {
  if (!error) return false;
  const errMsg = (error.message || String(error)).toLowerCase();
  return (
    error.code === 'resource-exhausted' ||
    errMsg.includes('quota') ||
    errMsg.includes('exhausted') ||
    errMsg.includes('billing')
  );
};

const deduplicateById = <T extends { id: string }>(arr: T[] | undefined | null): T[] => {
  if (!arr || !Array.isArray(arr)) return [];
  const seen = new Set<string>();
  return arr.filter(item => {
    if (!item || !item.id) return false;
    if (seen.has(item.id)) return false;
    seen.add(item.id);
    return true;
  });
};

const normalizeExerciseBank = (arr: any[] | undefined | null): BankExercise[] => {
  if (!arr || !Array.isArray(arr)) return [];
  return arr.map(ex => {
    if (!ex) return ex;
    const list: string[] = [];
    if (Array.isArray(ex.imageUrls)) {
      for (const u of ex.imageUrls) {
        if (typeof u === 'string' && u.trim() && !list.includes(u.trim())) list.push(u.trim());
      }
    }
    if (typeof ex.imageUrl === 'string' && ex.imageUrl.trim() && !list.includes(ex.imageUrl.trim())) {
      list.push(ex.imageUrl.trim());
    }
    if (typeof ex.image === 'string' && ex.image.trim() && !list.includes(ex.image.trim())) {
      list.push(ex.image.trim());
    }
    if (typeof ex.photoUrl === 'string' && ex.photoUrl.trim() && !list.includes(ex.photoUrl.trim())) {
      list.push(ex.photoUrl.trim());
    }
    if (typeof ex.mediaUrl === 'string' && ex.mediaUrl.trim() && !list.includes(ex.mediaUrl.trim())) {
      list.push(ex.mediaUrl.trim());
    }
    const primaryImg = list[0] || undefined;
    return {
      ...ex,
      imageUrl: primaryImg,
      imageUrls: list.length > 0 ? list : undefined
    };
  });
};

const normalizeSessionMoments = (sessions: any[] | undefined | null, bank: BankExercise[] = []): TrainingSession[] => {
  if (!sessions || !Array.isArray(sessions)) return [];
  return sessions.map(sess => {
    if (!sess || !Array.isArray(sess.moments)) return sess;
    const updatedMoments = sess.moments.map((m: any) => {
      if (!m) return m;
      const list: string[] = [];
      if (Array.isArray(m.imageUrls)) {
        for (const u of m.imageUrls) {
          if (typeof u === 'string' && u.trim() && !list.includes(u.trim())) list.push(u.trim());
        }
      }
      if (typeof m.imageUrl === 'string' && m.imageUrl.trim() && !list.includes(m.imageUrl.trim())) {
        list.push(m.imageUrl.trim());
      }
      if (typeof m.image === 'string' && m.image.trim() && !list.includes(m.image.trim())) {
        list.push(m.image.trim());
      }
      if (typeof m.photoUrl === 'string' && m.photoUrl.trim() && !list.includes(m.photoUrl.trim())) {
        list.push(m.photoUrl.trim());
      }
      if (typeof m.mediaUrl === 'string' && m.mediaUrl.trim() && !list.includes(m.mediaUrl.trim())) {
        list.push(m.mediaUrl.trim());
      }

      // If moment has no image but is linked to an exercise in the bank, recover image from bank!
      if (list.length === 0 && (m.bankExerciseId || m.name)) {
        const bankMatch = bank.find(b => (m.bankExerciseId && b.id === m.bankExerciseId) || (m.name && b.name?.trim().toLowerCase() === m.name?.trim().toLowerCase()));
        if (bankMatch) {
          const bankImages = (bankMatch.imageUrls && bankMatch.imageUrls.length > 0)
            ? bankMatch.imageUrls
            : (bankMatch.imageUrl ? [bankMatch.imageUrl] : []);
          for (const u of bankImages) {
            if (typeof u === 'string' && u.trim() && !list.includes(u.trim())) list.push(u.trim());
          }
        }
      }

      const primaryImg = list[0] || undefined;
      return {
        ...m,
        imageUrl: primaryImg,
        imageUrls: list.length > 0 ? list : undefined
      };
    });
    return {
      ...sess,
      moments: updatedMoments
    };
  });
};

const mergeLineups = (remoteLineups: Lineup[] = [], localLineups: Lineup[] = []): Lineup[] => {
  const map = new Map<string, Lineup>();
  for (const l of remoteLineups) {
    if (l && l.id) map.set(l.id, l);
  }
  for (const l of localLineups) {
    if (!l || !l.id) continue;
    const existing = map.get(l.id);
    if (!existing) {
      // Local lineup doesn't exist in remote (created/copied locally or offline) -> KEEP IT!
      map.set(l.id, l);
    } else {
      const localTime = l.updatedAt || l.createdAt || 0;
      const remoteTime = existing.updatedAt || existing.createdAt || 0;
      if (localTime >= remoteTime) {
        map.set(l.id, l);
      }
    }
  }
  return Array.from(map.values());
};

const mergeExercises = (remoteExercises: Exercise[] = [], localExercises: Exercise[] = []): Exercise[] => {
  const map = new Map<string, Exercise>();
  for (const e of remoteExercises) {
    if (e && e.id) map.set(e.id, e);
  }
  for (const e of localExercises) {
    if (!e || !e.id) continue;
    const existing = map.get(e.id);
    if (!existing) {
      // Local exercise doesn't exist in remote (created/copied locally or offline) -> KEEP IT!
      map.set(e.id, e);
    } else {
      const localTime = e.updatedAt || (e as any).createdAt || 0;
      const remoteTime = existing.updatedAt || (existing as any).createdAt || 0;
      if (localTime >= remoteTime) {
        map.set(e.id, e);
      }
    }
  }
  return Array.from(map.values());
};

const mergeSessions = (remoteSessions: TrainingSession[] = [], localSessions: TrainingSession[] = []): TrainingSession[] => {
  const map = new Map<string, TrainingSession>();
  for (const s of remoteSessions) {
    if (s && s.id) map.set(s.id, s);
  }
  for (const s of localSessions) {
    if (!s || !s.id) continue;
    const existing = map.get(s.id);
    if (!existing) {
      // Local session doesn't exist in remote (created locally or offline) -> KEEP IT!
      map.set(s.id, s);
    } else {
      const localTime = s.updatedAt || (s as any).createdAt || 0;
      const remoteTime = existing.updatedAt || (existing as any).createdAt || 0;
      if (localTime >= remoteTime) {
        map.set(s.id, s);
      } else {
        // Remote is newer overall, but preserve any locally added/edited moments or exercise links
        const momentMap = new Map<string, SessionMoment>();
        for (const m of existing.moments || []) {
          if (m && m.id) momentMap.set(m.id, m);
        }
        for (const m of s.moments || []) {
          if (!m || !m.id) continue;
          const exM = momentMap.get(m.id);
          if (!exM) {
            momentMap.set(m.id, m);
          } else if (m.exerciseId && !exM.exerciseId) {
            momentMap.set(m.id, { ...exM, exerciseId: m.exerciseId });
          }
        }
        map.set(s.id, {
          ...existing,
          moments: Array.from(momentMap.values())
        });
      }
    }
  }
  return Array.from(map.values());
};

const mergeExerciseBank = (remoteBank: BankExercise[] = [], localBank: BankExercise[] = []): BankExercise[] => {
  const map = new Map<string, BankExercise>();
  for (const b of remoteBank) {
    if (b && b.id) map.set(b.id, b);
  }
  for (const b of localBank) {
    if (!b || !b.id) continue;
    const existing = map.get(b.id);
    if (!existing) {
      map.set(b.id, b);
    } else {
      const localTime = Math.max((b as any).updatedAt || 0, b.createdAt || 0);
      const remoteTime = Math.max((existing as any).updatedAt || 0, existing.createdAt || 0);
      if (localTime >= remoteTime) {
        map.set(b.id, b);
      }
    }
  }
  return Array.from(map.values());
};

const getPrefixedItem = (key: string, currentUser: any) => {
  const prefix = currentUser ? currentUser.uid : 'guest';
  return localStorage.getItem(`${prefix}:${key}`);
};

const setPrefixedItem = (key: string, value: string, currentUser: any) => {
  const prefix = currentUser ? currentUser.uid : 'guest';
  localStorage.setItem(`${prefix}:${key}`, value);
};

const removePrefixedItem = (key: string, currentUser: any) => {
  const prefix = currentUser ? currentUser.uid : 'guest';
  localStorage.removeItem(`${prefix}:${key}`);
};

const migrateLegacyCache = () => {
  try {
    const lastUser = localStorage.getItem('last_local_user_id') || 'guest';
    
    const migrationDoneKey = 'legacy_migration_global_done';
    if (localStorage.getItem(migrationDoneKey) === 'true') {
      return;
    }

    const legacyKeys = [
      'football_squad',
      'football_exercises',
      'football_sessions',
      'football_deleted_sessions',
      'football_lineups',
      'active_lineup_id',
      'football_periods',
      'current_period_id',
      'active_exercise_id',
      'team_url',
      'admin_url',
      'series_url',
      'custom_formations',
      'training_settings',
      'pinned_formations',
      'football_exercise_bank',
      'football_exercise_bank_categories'
    ];

    console.log(`App: Global legacy cache migration started. Target prefix: ${lastUser}`);
    legacyKeys.forEach(key => {
      const val = localStorage.getItem(key);
      if (val !== null) {
        localStorage.setItem(`${lastUser}:${key}`, val);
        localStorage.removeItem(key);
      }
    });

    localStorage.setItem(migrationDoneKey, 'true');
  } catch (err) {
    console.error('App: Global legacy cache migration failed:', err);
  }
};

// Run global migration immediately on module load
migrateLegacyCache();

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  
  const [userProfile, setUserProfile] = useState<UserProfile>({
    fullName: '',
    phone: '',
    personnummer: '',
    activeClubId: null,
    activeTeamId: null,
  });
  const [activeClubInfo, setActiveClubInfo] = useState<{ clubName: string; teamName: string } | null>(null);
  const [userRoles, setUserRoles] = useState<string[]>([]);

  useEffect(() => {
    if (!userProfile.activeClubId) {
      setActiveClubInfo(null);
      return;
    }
    let isMounted = true;
    getDoc(doc(db, 'clubs', userProfile.activeClubId, 'teams', 'club_global', 'data', 'metadata')).then(snap => {
      if (isMounted && snap.exists()) {
        const data = snap.data();
        const clubName = data.clubName || data.name || 'Förening';
        const teamObj = Array.isArray(data.teams) ? data.teams.find((t: any) => t.id === userProfile.activeTeamId) : null;
        const teamName = teamObj?.name || (userProfile.activeTeamId === 'club_global' ? 'Hela Föreningen' : 'Lag');
        setActiveClubInfo({ clubName, teamName });
      }
    }).catch(() => {});
    return () => { isMounted = false; };
  }, [userProfile.activeClubId, userProfile.activeTeamId]);
  const [isRootAdmin, setIsRootAdmin] = useState(false);
  const [pendingRequestsCount, setPendingRequestsCount] = useState<number>(0);
  const [isPendingRequestsModalOpen, setIsPendingRequestsModalOpen] = useState<boolean>(false);

  const checkRootAdminStatus = async (uid: string, email: string, googleEmail?: string | null) => {
    try {
      const lowerEmail = (email || '').trim().toLowerCase();
      const lowerGoogleEmail = (googleEmail || '').trim().toLowerCase();
      const hardcodedRoots = ['christer.setterholm@gmail.com', 'christer@setterholm.se'];
      let isRoot = (lowerEmail && hardcodedRoots.includes(lowerEmail)) || (lowerGoogleEmail && hardcodedRoots.includes(lowerGoogleEmail));

      // Check specific admin UID document
      const adminDoc = await getDoc(doc(db, 'admins', uid));
      if (adminDoc.exists()) {
        isRoot = true;
      }

      // Check global root admins list document
      try {
        const rootAdminsListDoc = await getDoc(doc(db, 'admins', 'root_admins_list'));
        if (rootAdminsListDoc.exists()) {
          const data = rootAdminsListDoc.data();
          if (data && Array.isArray(data.admins)) {
            const hasEmail = data.admins.some((adm: any) => {
              const admEmail = (adm.email || '').trim().toLowerCase();
              return (lowerEmail && admEmail === lowerEmail) || (lowerGoogleEmail && admEmail === lowerGoogleEmail);
            });
            if (hasEmail) {
              isRoot = true;
            }
          }
        }
      } catch (listErr) {
        console.warn('Could not read global root admins list:', listErr);
      }

      setIsRootAdmin(isRoot);

      if (isRoot) {
        // Ensure a document exists in the admins collection to satisfy the Security Rules 'exists' check
        await setDoc(doc(db, 'admins', uid), {
          uid,
          email: lowerEmail || lowerGoogleEmail,
          role: 'root_admin',
          assignedAt: Date.now()
        }, { merge: true });

        // Ensure user's email is also in the global root_admins_list
        try {
          const listRef = doc(db, 'admins', 'root_admins_list');
          const listSnap = await getDoc(listRef);
          let currentAdmins: any[] = [];
          
          if (listSnap.exists()) {
            const listData = listSnap.data();
            if (listData && Array.isArray(listData.admins)) {
              currentAdmins = listData.admins;
            }
          }

          // Add hardcoded admins if missing from list
          for (const hardcoded of hardcodedRoots) {
            if (!currentAdmins.some((adm: any) => adm.email.trim().toLowerCase() === hardcoded)) {
              currentAdmins.push({
                email: hardcoded,
                uid: '',
                role: 'root_admin',
                assignedAt: Date.now()
              });
            }
          }

          // Add current user if missing from list
          const effectiveEmail = lowerEmail || lowerGoogleEmail;
          if (effectiveEmail && !currentAdmins.some((adm: any) => adm.email.trim().toLowerCase() === effectiveEmail)) {
            currentAdmins.push({
              email: effectiveEmail,
              uid: uid,
              role: 'root_admin',
              assignedAt: Date.now()
            });
          }

          await setDoc(listRef, { admins: currentAdmins });
        } catch (listSaveErr) {
          console.error('Failed to update root admins list:', listSaveErr);
        }
      }
    } catch (err) {
      console.error('Failed to check root admin status:', err);
      // Fallback to runtime email check if rules block write or firestore error
      const lowerEmail = (email || '').trim().toLowerCase();
      const lowerGoogleEmail = (googleEmail || '').trim().toLowerCase();
      const hardcodedRoots = ['christer.setterholm@gmail.com', 'christer@setterholm.se'];
      const isRoot = (lowerEmail && hardcodedRoots.includes(lowerEmail)) || (lowerGoogleEmail && hardcodedRoots.includes(lowerGoogleEmail));
      setIsRootAdmin(isRoot);
    }
  };

  const getDocRefs = (currUser: User | null, profile: UserProfile) => {
    if (!currUser) {
      return {
        docSquadRef: doc(db, 'users', 'guest', 'data', 'squad'),
        docSessionsRef: doc(db, 'users', 'guest', 'data', 'sessions'),
        docExercisesRef: doc(db, 'users', 'guest', 'data', 'exercises'),
        docLineupsRef: doc(db, 'users', 'guest', 'data', 'lineups'),
        docPeriodsRef: doc(db, 'users', 'guest', 'data', 'periods'),
        docSettingsRef: doc(db, 'users', 'guest', 'data', 'settings'),
      };
    }
    if (profile.activeClubId && profile.activeTeamId) {
      return {
        docSquadRef: doc(db, 'clubs', profile.activeClubId, 'teams', profile.activeTeamId, 'data', 'squad'),
        docSessionsRef: doc(db, 'clubs', profile.activeClubId, 'teams', profile.activeTeamId, 'data', 'sessions'),
        docExercisesRef: doc(db, 'clubs', profile.activeClubId, 'teams', profile.activeTeamId, 'data', 'exercises'),
        docLineupsRef: doc(db, 'clubs', profile.activeClubId, 'teams', profile.activeTeamId, 'data', 'lineups'),
        docPeriodsRef: doc(db, 'clubs', profile.activeClubId, 'teams', profile.activeTeamId, 'data', 'periods'),
        docSettingsRef: doc(db, 'clubs', profile.activeClubId, 'teams', profile.activeTeamId, 'data', 'settings'),
      };
    } else {
      return {
        docSquadRef: doc(db, 'users', currUser.uid, 'data', 'squad'),
        docSessionsRef: doc(db, 'users', currUser.uid, 'data', 'sessions'),
        docExercisesRef: doc(db, 'users', currUser.uid, 'data', 'exercises'),
        docLineupsRef: doc(db, 'users', currUser.uid, 'data', 'lineups'),
        docPeriodsRef: doc(db, 'users', currUser.uid, 'data', 'periods'),
        docSettingsRef: doc(db, 'users', currUser.uid, 'data', 'settings'),
      };
    }
  };
  const [sharedLeaderboardId, setSharedLeaderboardId] = useState<string | null>(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('share');
  });

  const [data, setData] = useState<CoachData>(() => {
    try {
      const lastUser = localStorage.getItem('last_local_user_id') || 'guest';
      const savedExercises = localStorage.getItem(`${lastUser}:football_exercises`);
      const savedSquad = localStorage.getItem(`${lastUser}:football_squad`);
      const savedSessions = localStorage.getItem(`${lastUser}:football_sessions`);
      const savedPeriods = localStorage.getItem(`${lastUser}:football_periods`);
      const savedLineups = localStorage.getItem(`${lastUser}:football_lineups`);
      
      const urlParams = new URLSearchParams(window.location.search);
      const urlEx = urlParams.get('ex');
      const sessionEx = sessionStorage.getItem('coach_active_exercise_id');
      const savedActiveExerciseId = localStorage.getItem(`${lastUser}:active_exercise_id`);
      const targetExId = urlEx || sessionEx || savedActiveExerciseId || null;

      if (savedExercises || savedSquad || savedSessions) {
        return {
          ...INITIAL_DATA,
          squad: savedSquad ? JSON.parse(savedSquad) : [],
          exercises: savedExercises ? JSON.parse(savedExercises) : [],
          sessions: savedSessions ? JSON.parse(savedSessions) : [],
          periods: savedPeriods ? JSON.parse(savedPeriods) : [],
          lineups: savedLineups ? JSON.parse(savedLineups) : [],
          activeExerciseId: targetExId,
        };
      }
    } catch (e) {}
    return INITIAL_DATA;
  });
  const { 
    squad = [], 
    exercises = [], 
    sessions = [], 
    deletedSessions = [], 
    lineups = [], 
    activeLineupId, 
    periods = [], 
    currentPeriodId, 
    activeExerciseId, 
    teamUrl = '', 
    adminUrl = '',
    seriesUrl = '',
    customFormations = [], 
    pinnedFormationIds = ['4-2-3-1', '4-4-2', '4-3-3'],
    trainingSettings = INITIAL_DATA.trainingSettings,
    exerciseBank = [],
    exerciseBankCategories = []
  } = (data || INITIAL_DATA);
  const latestDataRef = useRef<CoachData>(data);
  latestDataRef.current = data;
  const [sessionActionCount, setSessionActionCount] = useState(0);
  const [linkToMomentId, setLinkToMomentId] = useState<string | null>(null);
  const [prefilledName, setPrefilledName] = useState<string | null>(null);

  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      const saved = localStorage.getItem('score_theme');
      if (saved === 'dark' || saved === 'light') return saved;
    } catch (e) {}
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });

  // Sync PWA Custom App Name and Meta tags on app load
  useEffect(() => {
    fetch(getApiUrl('/api/pwa-icons'))
      .then(r => (r.ok ? r.json() : null))
      .then(data => {
        if (data && data.appName) {
          const cleanName = data.appName.trim();
          document.title = cleanName;

          let appleTitle = document.querySelector('meta[name="apple-mobile-web-app-title"]') as HTMLMetaElement;
          if (!appleTitle) {
            appleTitle = document.createElement('meta');
            appleTitle.name = 'apple-mobile-web-app-title';
            document.head.appendChild(appleTitle);
          }
          appleTitle.content = cleanName;

          let appNameMeta = document.querySelector('meta[name="application-name"]') as HTMLMetaElement;
          if (!appNameMeta) {
            appNameMeta = document.createElement('meta');
            appNameMeta.name = 'application-name';
            document.head.appendChild(appNameMeta);
          }
          appNameMeta.content = cleanName;

          if (data.themeColor) {
            let themeMeta = document.querySelector('meta[name="theme-color"]') as HTMLMetaElement;
            if (!themeMeta) {
              themeMeta = document.createElement('meta');
              themeMeta.name = 'theme-color';
              document.head.appendChild(themeMeta);
            }
            themeMeta.content = data.themeColor;
          }
        }
      })
      .catch(() => {});
  }, []);
  
  const [view, _setView] = useState<View>(() => {
    const params = new URLSearchParams(window.location.search);
    const v = params.get('view');
    const shareId = params.get('share');
    
    // If sharing, priority is leaderboard (already handled by useEffect but setting here for initial sync too)
    if (shareId) return 'leaderboard';
    
    if (v === 'squad' || v === 'training' || v === 'leaderboard' || v === 'profile' || v === 'lineup' || v === 'teampage' || v === 'exercise') {
      return v as View;
    }
    return 'training';
  });

  const setView = (newView: View | ((prev: View) => View)) => {
    _setView(prev => {
      const nextView = typeof newView === 'function' ? newView(prev) : newView;
      if (nextView === 'clubadmin' && user && !isRootAdmin && !userRoles.includes('admin') && !userRoles.includes('coach')) {
        console.warn('Unauthorized view transition to clubadmin blocked');
        return 'training';
      }
      if (nextView !== 'exercise') {
        try {
          const url = new URL(window.location.href);
          if (url.searchParams.has('view') && url.searchParams.get('view') === 'exercise') {
            url.searchParams.delete('view');
            url.searchParams.delete('ex');
            window.history.replaceState({}, '', url.toString());
          }
        } catch (e) {}
      }
      return nextView;
    });
  };
  const [trainingTab, setTrainingTab] = useState<'completed' | 'exercises' | 'calendar_view' | 'bank'>('calendar_view');
  const [calendarMonth, setCalendarMonth] = useState<Date>(() => {
    const now = new Date();
    const currentMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    try {
      const saved = sessionStorage.getItem('coach_calendar_session_month');
      const timestampStr = sessionStorage.getItem('coach_calendar_session_timestamp');
      if (saved && timestampStr) {
        const timestamp = Number(timestampStr);
        // If the user actively switched month during this session within the last 2 hours:
        if (Date.now() - timestamp < 2 * 60 * 60 * 1000) {
          const [y, m] = saved.split('-').map(Number);
          if (!isNaN(y) && !isNaN(m) && m >= 1 && m <= 12) {
            return new Date(y, m - 1, 1);
          }
        }
      }
    } catch (e) {}
    return currentMonth;
  });

  const handleCalendarMonthChange = (newMonth: Date) => {
    setCalendarMonth(newMonth);
    try {
      const y = newMonth.getFullYear();
      const m = newMonth.getMonth() + 1;
      sessionStorage.setItem('coach_calendar_session_month', `${y}-${m}`);
      sessionStorage.setItem('coach_calendar_session_timestamp', String(Date.now()));
    } catch (e) {}
  };

  const [openTrainingSettings, setOpenTrainingSettings] = useState(false);
  const [isLineupMaximized, setIsLineupMaximized] = useState(false);

  useEffect(() => {
    if (view !== 'lineup') {
      setIsLineupMaximized(false);
    }
  }, [view]);

  const [activeSessionId, setActiveSessionId] = useState<string | null>(() => {
    try {
      return sessionStorage.getItem('coach_active_session_id') || null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    try {
      if (activeSessionId) {
        sessionStorage.setItem('coach_active_session_id', activeSessionId);
      } else {
        sessionStorage.removeItem('coach_active_session_id');
      }
    } catch (e) {}
  }, [activeSessionId]);
  const [sessionEditorTab, setSessionEditorTab] = useState<'schema' | 'attendance' | 'rsvp'>('schema');
  const [sessionMode, setSessionMode] = useState<'plan' | 'live'>('plan');
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showFinishConfirm, setShowFinishConfirm] = useState(false);
  const [finishTargetPeriodId, setFinishTargetPeriodId] = useState<string | null>(null);
  const [isEditingActiveExercise, setIsEditingActiveExercise] = useState(false);
  const [editReturnView, setEditReturnView] = useState<View | null>(null);
  const [previousActiveExerciseId, setPreviousActiveExerciseId] = useState<string | null | undefined>(undefined);
  const [showTeamOverview, setShowTeamOverview] = useState(false);
  const lastSyncedAtRef = useRef<number>(0);
  const [isInitialSyncDone, setIsInitialSyncDone] = useState(false);
  const [isProfileLoaded, setIsProfileLoaded] = useState(false);
  const [hasPulledFromCloud, setHasPulledFromCloud] = useState(false);
  const sessionActionCountRef = useRef(0);
  const pendingCloudUpdateRef = useRef<{ lineups: Lineup[], activeLineupId: string | null } | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const isSyncingRef = useRef(false);
  const syncSafetyTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const setSyncingStatus = useCallback((val: boolean) => {
    isSyncingRef.current = val;
    setIsSyncing(val);
    if (syncSafetyTimeoutRef.current) {
      clearTimeout(syncSafetyTimeoutRef.current);
      syncSafetyTimeoutRef.current = null;
    }
    if (val) {
      // Hard safety timer: after 12 seconds, if sync is still active, reset it automatically
      syncSafetyTimeoutRef.current = setTimeout(() => {
        if (isSyncingRef.current) {
          console.warn("App: Global sync safety timeout triggered. Resetting isSyncing.");
          isSyncingRef.current = false;
          setIsSyncing(false);
        }
      }, 12000);
    }
  }, []);

  // Sync sessionActionCount to its ref for use in onSnapshot
  useEffect(() => {
    sessionActionCountRef.current = sessionActionCount;
    if (sessionActionCount === 0 && pendingCloudUpdateRef.current) {
      const { lineups: newLineups, activeLineupId: newActiveLineupId } = pendingCloudUpdateRef.current;
      pendingCloudUpdateRef.current = null;
      console.log("App: Applying queued real-time lineups update merged with local state.");
      setData(prev => {
        const merged = mergeLineups(newLineups, prev.lineups);
        const nextActiveId = prev.activeLineupId || newActiveLineupId || (merged[0]?.id || null);
        if (JSON.stringify(prev.lineups) === JSON.stringify(merged) && prev.activeLineupId === nextActiveId) {
          return prev;
        }
        const updated = {
          ...prev,
          lineups: merged,
          activeLineupId: nextActiveId
        };
        try {
          setPrefixedItem('football_lineups', JSON.stringify(merged), user);
          setPrefixedItem('active_lineup_id', nextActiveId || '', user);
        } catch (e) {}
        if (lastCloudDataRef.current) {
          lastCloudDataRef.current.lineups = merged;
          lastCloudDataRef.current.activeLineupId = nextActiveId;
        }
        return updated;
      });
    }
  }, [sessionActionCount]);
  const [isQuotaExceeded, setIsQuotaExceeded] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);
  const sessionIdRef = useRef<string>(Math.random().toString(36).substring(7));
  const syncUserIdRef = useRef<string | null>(null);
  const lastCloudDataRef = useRef<CoachData | null>(null);
  const notifiedMomentsRef = useRef<Set<string>>(new Set());
  const lastSharedLeaderboardsRef = useRef<Record<string, string>>({});

  // Track if user has typed into any text input during this document session
  const hasTypedInSessionRef = useRef<boolean>(false);
  const [hasTypedInSession, setHasTypedInSession] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('coach_has_typed') === 'true';
    } catch {
      return false;
    }
  });
  const [isQuickShakeModalOpen, setIsQuickShakeModalOpen] = useState<boolean>(false);
  const [isShakeInfoModalOpen, setIsShakeInfoModalOpen] = useState<boolean>(false);

  // Track if the exercise timer is currently running
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [draggedPlayerId, setDraggedPlayerId] = useState<string | null>(null);

  useEffect(() => {
    if (view !== 'exercise' || !activeExerciseId) {
      setIsTimerRunning(false);
    }
  }, [view, activeExerciseId]);

  useEffect(() => {
    const onInput = (e: Event) => {
      const target = e.target as HTMLElement | null;
      if (target) {
        if (target.tagName === 'TEXTAREA' || (target as any).isContentEditable) {
          hasTypedInSessionRef.current = true;
          setHasTypedInSession(true);
          try {
            sessionStorage.setItem('coach_has_typed', 'true');
          } catch (err) {}
          return;
        }
        if (target.tagName === 'INPUT') {
          const type = ((target as HTMLInputElement).type || 'text').toLowerCase();
          const textTypes = ['text', 'search', 'email', 'password', 'tel', 'url', 'number'];
          if (textTypes.includes(type)) {
            hasTypedInSessionRef.current = true;
            setHasTypedInSession(true);
            try {
              sessionStorage.setItem('coach_has_typed', 'true');
            } catch (err) {}
          }
        }
      }
    };
    window.addEventListener('input', onInput, true);
    return () => window.removeEventListener('input', onInput, true);
  }, []);

  const handleSelectExercise = (id: string) => {
    // Blur any active input to dismiss virtual keyboards and release text field responder
    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
    document.querySelectorAll('input, textarea').forEach(el => (el as HTMLElement).blur());
    try {
      window.getSelection()?.removeAllRanges();
    } catch (e) {}

    // Safely clear typing indicator without destructive reload
    hasTypedInSessionRef.current = false;
    setHasTypedInSession(false);
    try {
      sessionStorage.removeItem('coach_has_typed');
    } catch (e) {}

    // Persist active exercise id immediately in state and local storage using latest functional state
    setData(prev => {
      const updated = { ...prev, activeExerciseId: id };
      try {
        setPrefixedItem('active_exercise_id', id, user);
        sessionStorage.setItem('coach_active_exercise_id', id);
        setPrefixedItem('football_squad', JSON.stringify(prev.squad), user);
        setPrefixedItem('football_sessions', JSON.stringify(prev.sessions), user);
        setPrefixedItem('football_exercises', JSON.stringify(prev.exercises), user);
        setPrefixedItem('data', JSON.stringify(updated), user);
      } catch (e) {}
      return updated;
    });

    try {
      const url = new URL(window.location.href);
      url.searchParams.set('view', 'exercise');
      url.searchParams.set('ex', id);
      window.history.replaceState({}, '', url.toString());
    } catch (e) {}

    setView('exercise');
    setSessionActionCount(prev => prev + 1);

    // Immediate background push to cloud so Firestore and SQLite are always in sync
    setTimeout(() => {
      pushDirtySegments(true).catch(err => console.warn('App: Background push on select exercise:', err));
    }, 50);
  };

  const handleSafeShakeReload = async () => {
    try {
      sessionStorage.removeItem('coach_has_typed');
      hasTypedInSessionRef.current = false;
      setHasTypedInSession(false);

      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
      document.querySelectorAll('input, textarea').forEach(el => (el as HTMLElement).blur());
      try {
        window.getSelection()?.removeAllRanges();
      } catch (e) {}

      // Flush local state cleanly before reload
      setData(prev => {
        try {
          setPrefixedItem('football_squad', JSON.stringify(prev.squad), user);
          setPrefixedItem('football_sessions', JSON.stringify(prev.sessions), user);
          setPrefixedItem('football_exercises', JSON.stringify(prev.exercises), user);
          if (prev.activeExerciseId) {
            setPrefixedItem('active_exercise_id', prev.activeExerciseId, user);
            sessionStorage.setItem('coach_active_exercise_id', prev.activeExerciseId);
          }
          setPrefixedItem('data', JSON.stringify(prev), user);
        } catch (e) {}
        return prev;
      });

      // Best effort immediate cloud push
      try {
        await pushDirtySegments(true);
      } catch (e) {
        console.warn('App: Cloud push before shake reload:', e);
      }

      // Safe reload directly into the current exercise or view
      const url = new URL(window.location.href);
      if (view === 'exercise' && activeExerciseId) {
        url.searchParams.set('view', 'exercise');
        url.searchParams.set('ex', activeExerciseId);
      }
      window.location.replace(url.toString());
    } catch (err) {
      console.error("Failed to execute safe shake reload:", err);
      window.location.reload();
    }
  };

  const handleResetShakeProtection = () => {
    setIsQuickShakeModalOpen(true);
  };

  // Notification Scheduler for Training Moments & iOS Shake to Undo Protection
  useEffect(() => {
    // ONLY apply iOS Shake-to-Undo protections when actively in an exercise (competition view)
    if (view !== 'exercise') {
      return;
    }

    // Blur any open keyboard or focused text input upon starting an exercise
    try {
      const activeEl = document.activeElement as HTMLElement;
      if (activeEl && typeof activeEl.blur === 'function') {
        activeEl.blur();
      }
    } catch (e) {}

    const handleUndo = (e: any) => {
      // iOS triggers 'beforeinput' with inputType 'historyUndo' or 'historyRedo' when shaking
      if (e.inputType === 'historyUndo' || e.inputType === 'historyRedo') {
        const active = document.activeElement as HTMLElement | null;
        const isEditingText = active && (active.tagName === 'TEXTAREA' || (active.tagName === 'INPUT' && !['button', 'submit', 'checkbox', 'radio'].includes((active as HTMLInputElement).type)));
        if (!isEditingText) {
          e.preventDefault();
          e.stopPropagation();
        }
      }
    };

    const preventDefault = (e: Event) => {
      e.preventDefault();
      e.stopPropagation();
    };

    const clearSelection = () => {
      try {
        window.getSelection()?.removeAllRanges();
      } catch (e) {}
    };

    window.addEventListener('beforeinput', handleUndo, true);
    document.addEventListener('undo', preventDefault, true);
    document.addEventListener('redo', preventDefault, true);

    window.addEventListener('touchend', clearSelection, { passive: true });
    window.addEventListener('touchcancel', clearSelection, { passive: true });
    window.addEventListener('mouseup', clearSelection, { passive: true });
    document.addEventListener('selectionchange', clearSelection, { passive: true });

    return () => {
      window.removeEventListener('beforeinput', handleUndo, true);
      document.removeEventListener('undo', preventDefault, true);
      document.removeEventListener('redo', preventDefault, true);

      window.removeEventListener('touchend', clearSelection);
      window.removeEventListener('touchcancel', clearSelection);
      window.removeEventListener('mouseup', clearSelection);
      document.removeEventListener('selectionchange', clearSelection);
    };
  }, [view]);

  useEffect(() => {
    const checkNotifications = () => {
      if (!('Notification' in window) || Notification.permission !== 'granted') return;

      const now = Date.now();
      
      sessions.forEach(session => {
        if (session.isStarted && session.actualStartTime && !session.isCompleted) {
          let cumulativeMinutes = 0;
          session.moments.forEach((moment) => {
            // Combine session date with start time string (HH:mm) to get absolute planned start
            const [h, m] = (session.startTime || "00:00").split(':').map(Number);
            const momentPlannedStartBase = new Date(session.date);
            momentPlannedStartBase.setHours(h, m, 0, 0);
            
            const momentDuration = typeof moment.duration === 'string' ? parseInt(moment.duration, 10) : moment.duration;
            const scheduledStartTime = momentPlannedStartBase.getTime() + (cumulativeMinutes * 60000);
            
            // User wants notice exactly 1 minute BEFORE start
            const notificationTargetTime = scheduledStartTime - 60000;
            const notificationKey = `${session.id}-${moment.id}-${session.actualStartTime}`;
            
            // Trigger if:
            // 1. Current time is at or past notification target time
            // 2. Notification target time was NOT before we manually started the session
            // 3. We haven't notified for this specific session run yet
            if (now >= notificationTargetTime && 
                notificationTargetTime >= session.actualStartTime! && 
                !notifiedMomentsRef.current.has(notificationKey)) {
              
              // Safety window: don't notify if the moment's start time was more than 10 minutes ago
              if (now < scheduledStartTime + 10 * 60000 && document.visibilityState !== 'visible') {
                new Notification(`Om 1 minut: ${moment.name || 'Nästa moment'}`, {
                  body: `Träning: ${session.title}\nLängd: ${momentDuration} min`,
                  icon: '/favicon.ico',
                  tag: `moment-${moment.id}`,
                  silent: false
                });
              }
              notifiedMomentsRef.current.add(notificationKey);
            }
            
            cumulativeMinutes += (momentDuration || 0);
          });
        }
      });
    };

    const intervalId = window.setInterval(checkNotifications, 5000); // Check every 5 seconds
    return () => window.clearInterval(intervalId);
  }, [sessions]);

  // Initial load from localStorage for quick bootstrap
  useEffect(() => {
    if (isAuthReady && !isInitialSyncDone) {
      console.log("App: Loading cached data from localStorage for quick bootstrap");
      const savedSquad = getPrefixedItem('football_squad', user);
      const savedExercises = getPrefixedItem('football_exercises', user);
      const savedSessions = getPrefixedItem('football_sessions', user);
      const savedDeletedSessions = getPrefixedItem('football_deleted_sessions', user);
      const savedLineups = getPrefixedItem('football_lineups', user);
      const savedActiveLineupId = getPrefixedItem('active_lineup_id', user);
      const savedPeriods = getPrefixedItem('football_periods', user);
      const savedCurrentPeriodId = getPrefixedItem('current_period_id', user);
      const savedActiveExerciseId = getPrefixedItem('active_exercise_id', user);
      const savedTeamUrl = getPrefixedItem('team_url', user);
      const savedAdminUrl = getPrefixedItem('admin_url', user);
      const savedSeriesUrl = getPrefixedItem('series_url', user);
      const savedCustomFormations = getPrefixedItem('custom_formations', user);
      const savedSettings = getPrefixedItem('training_settings', user);
      const savedExerciseBank = getPrefixedItem('football_exercise_bank', user);
      const savedExerciseBankCategories = getPrefixedItem('football_exercise_bank_categories', user);

      // Robust Deduplication to prevent duplicate keys across components
      const rawSquad = savedSquad ? JSON.parse(savedSquad) : [];
      const deduplicatedSquad = Array.from(new Map(rawSquad.map((p: any) => [p.id, p])).values()) as SquadPlayer[];

      const newState: CoachData = {
        squad: deduplicatedSquad,
        exercises: savedExercises ? deduplicateById(JSON.parse(savedExercises)) : [],
        sessions: savedSessions ? normalizeSessionMoments(deduplicateById(JSON.parse(savedSessions))) : [],
        deletedSessions: savedDeletedSessions ? deduplicateById(JSON.parse(savedDeletedSessions)) : [],
        lineups: savedLineups ? deduplicateById(JSON.parse(savedLineups)) : [],
        activeLineupId: savedActiveLineupId || null,
        periods: savedPeriods ? deduplicateById(JSON.parse(savedPeriods)) : [],
        currentPeriodId: savedCurrentPeriodId || null,
        activeExerciseId: new URLSearchParams(window.location.search).get('ex') || sessionStorage.getItem('coach_active_exercise_id') || savedActiveExerciseId || null,
        teamUrl: savedTeamUrl || '',
        adminUrl: savedAdminUrl || '',
        seriesUrl: savedSeriesUrl || '',
        customFormations: savedCustomFormations ? deduplicateById(JSON.parse(savedCustomFormations)) : [],
        pinnedFormationIds: getPrefixedItem('pinned_formations', user) ? JSON.parse(getPrefixedItem('pinned_formations', user)!) : ['4-2-3-1', '4-4-2', '4-3-3'],
        trainingSettings: savedSettings ? JSON.parse(savedSettings) : INITIAL_DATA.trainingSettings,
        exerciseBank: savedExerciseBank ? normalizeExerciseBank(deduplicateById(JSON.parse(savedExerciseBank))) : [],
        exerciseBankCategories: savedExerciseBankCategories ? JSON.parse(savedExerciseBankCategories) : []
      };

      setData(newState);
      
      if (!user) {
        // For guests, we are fully loaded right away
        setIsInitialSyncDone(true);
      } else {
        // For logged-in users, set a fallback timeout to resolve initial sync immediately
        // if Firestore is slow/offline. When its snapshot resolves, it merges properly.
        const timer = setTimeout(() => {
          console.log("App: Firestore snapshot timeout reached, proceeding with cached data");
          setIsInitialSyncDone(true);
        }, 1200);
        return () => clearTimeout(timer);
      }
    }
  }, [isAuthReady, user, isInitialSyncDone]);

  // Sync to localStorage IMMEDIATELY for persistence
  useEffect(() => {
    if (isAuthReady && isInitialSyncDone && isProfileLoaded) {
      // Guard against overwriting existing non-empty cache with empty state if no user delete action occurred
      const existingSquad = getPrefixedItem('football_squad', user);
      const existingSessions = getPrefixedItem('football_sessions', user);
      const existingExercises = getPrefixedItem('football_exercises', user);

      const isStateTotallyEmpty = squad.length === 0 && sessions.length === 0 && exercises.length === 0;
      const hasExistingCache = (existingSquad && JSON.parse(existingSquad).length > 0) ||
                               (existingSessions && JSON.parse(existingSessions).length > 0) ||
                               (existingExercises && JSON.parse(existingExercises).length > 0);

      if (isStateTotallyEmpty && hasExistingCache && sessionActionCount === 0) {
        console.warn("App: Skipping localStorage write because state is empty while cache has data.");
        return;
      }

      setPrefixedItem('football_squad', JSON.stringify(squad), user);
      setPrefixedItem('football_exercises', JSON.stringify(exercises), user);
      setPrefixedItem('football_sessions', JSON.stringify(sessions), user);
      setPrefixedItem('football_deleted_sessions', JSON.stringify(deletedSessions), user);
      setPrefixedItem('football_lineups', JSON.stringify(lineups), user);
      setPrefixedItem('active_lineup_id', activeLineupId || '', user);
      setPrefixedItem('football_periods', JSON.stringify(periods), user);
      setPrefixedItem('current_period_id', currentPeriodId || '', user);
      setPrefixedItem('active_exercise_id', activeExerciseId || '', user);
      setPrefixedItem('team_url', teamUrl || '', user);
      setPrefixedItem('admin_url', adminUrl || '', user);
      setPrefixedItem('series_url', seriesUrl || '', user);
      setPrefixedItem('custom_formations', JSON.stringify(customFormations), user);
      setPrefixedItem('training_settings', JSON.stringify(trainingSettings), user);
      setPrefixedItem('pinned_formations', JSON.stringify(pinnedFormationIds), user);
      setPrefixedItem('football_exercise_bank', JSON.stringify(exerciseBank), user);
      setPrefixedItem('football_exercise_bank_categories', JSON.stringify(exerciseBankCategories), user);
      if (sessionActionCount > 0) {
        setPrefixedItem('last_local_sync_at', Date.now().toString(), user);
      }
      localStorage.setItem('last_local_user_id', user ? user.uid : 'guest');
    }
  }, [squad, exercises, sessions, deletedSessions, lineups, activeLineupId, periods, currentPeriodId, activeExerciseId, teamUrl, customFormations, trainingSettings, pinnedFormationIds, exerciseBank, exerciseBankCategories, isAuthReady, isInitialSyncDone, isProfileLoaded, user]);

  const loadUserProfile = async (uid: string, email: string) => {
    try {
      setIsProfileLoaded(false);
      const profileSnap = await getDoc(doc(db, 'users', uid, 'data', 'profile'));
      let p: UserProfile | null = profileSnap.exists() ? (profileSnap.data() as UserProfile) : null;

      if (p && !p.username && auth.currentUser?.username) {
        p.username = auth.currentUser.username;
      }
      if (p && !p.photoUrl && auth.currentUser?.photoURL) {
        p.photoUrl = auth.currentUser.photoURL;
      }

      const cleanUserEmail = (email || p?.email || '').trim().toLowerCase();

      // If user profile is missing or lacks an activeClubId or is pending, check if user belongs to any existing club
      if (!p || !p.activeClubId || p.status === 'pending') {
        try {
          // Fetch clubs list
          let clubsList: Club[] = [];
          const allClubsSnap = await getDoc(doc(db, 'shared_leaderboards', 'all_clubs'));
          if (allClubsSnap.exists()) {
            clubsList = allClubsSnap.data().clubs || [];
          }

          let foundClubId: string | null = null;
          let foundTeamId: string | null = null;
          let foundRoles: string[] = ['player'];
          let foundFullName: string | null = null;
          let foundPhone: string | null = null;
          let foundPnr: string | null = null;
          let foundPhotoUrl: string | null = null;

          for (const c of clubsList) {
            const membersSnap = await getDoc(doc(db, 'clubs', c.id, 'teams', 'club_global', 'data', 'members'));
            if (membersSnap.exists()) {
              const members: ClubMember[] = membersSnap.data().members || [];
              let isMemberUpdated = false;

              const matchedMember = members.find(m => {
                const sameUid = m.userId === uid;
                const sameEmail = m.email && cleanUserEmail && m.email.trim().toLowerCase() === cleanUserEmail;
                return sameUid || sameEmail;
              });

              if (matchedMember) {
                foundClubId = c.id;
                foundRoles = matchedMember.roles && matchedMember.roles.length > 0 ? matchedMember.roles : ['player'];
                foundFullName = matchedMember.fullName || (matchedMember as any).name || null;
                foundPhone = matchedMember.phone || null;
                foundPnr = matchedMember.personnummer || null;
                foundPhotoUrl = matchedMember.photoUrl || null;

                // Bind userId if missing
                if (!matchedMember.userId || matchedMember.userId !== uid) {
                  matchedMember.userId = uid;
                  isMemberUpdated = true;
                }

                if (isMemberUpdated) {
                  setDoc(doc(db, 'clubs', c.id, 'teams', 'club_global', 'data', 'members'), { members }).catch(() => {});
                }

                // Determine activeTeamId
                if (matchedMember.teams && matchedMember.teams.length > 0) {
                  foundTeamId = matchedMember.teams[0];
                } else {
                  const metaSnap = await getDoc(doc(db, 'clubs', c.id, 'teams', 'club_global', 'data', 'metadata'));
                  if (metaSnap.exists()) {
                    const teams: ClubTeam[] = metaSnap.data().teams || [];
                    foundTeamId = teams.length > 0 ? teams[0].id : 'club_global';
                  } else {
                    foundTeamId = 'club_global';
                  }
                }
                break;
              }
            }
          }

          if (foundClubId) {
            const resolvedProfile: UserProfile = {
              fullName: foundFullName || p?.fullName || (cleanUserEmail ? cleanUserEmail.split('@')[0] : 'Bruker'),
              email: cleanUserEmail,
              phone: foundPhone || p?.phone || '',
              personnummer: foundPnr || p?.personnummer || '',
              photoUrl: foundPhotoUrl || p?.photoUrl || auth.currentUser?.photoURL || undefined,
              activeClubId: foundClubId,
              activeTeamId: foundTeamId,
              status: 'approved',
              onboardingCompleted: p?.onboardingCompleted ?? false,
              username: p?.username || auth.currentUser?.username
            };
            await setDoc(doc(db, 'users', uid, 'data', 'profile'), resolvedProfile, { merge: true });
            if (resolvedProfile.photoUrl) {
              if (auth.currentUser && !auth.currentUser.photoURL) {
                auth.currentUser.photoURL = resolvedProfile.photoUrl;
              }
              setUser(prev => prev ? { ...prev, photoURL: resolvedProfile.photoUrl || prev.photoURL } : prev);
            }
            setUserProfile(resolvedProfile);
            setUserRoles(foundRoles);
            setIsProfileLoaded(true);
            return;
          }
        } catch (clubSearchErr) {
          console.error("Error searching user club membership:", clubSearchErr);
        }
      }

      if (p) {
        // Auto-resolve active team if set to 'club_global' or invalid when club has teams
        if (p.activeClubId) {
          try {
            const metaSnap = await getDoc(doc(db, 'clubs', p.activeClubId, 'teams', 'club_global', 'data', 'metadata'));
            if (metaSnap.exists()) {
              const teams: ClubTeam[] = metaSnap.data().teams || [];
              if (teams.length > 0) {
                const teamExists = teams.some(t => t.id === p.activeTeamId);
                if (!p.activeTeamId || p.activeTeamId === 'club_global' || !teamExists) {
                  p.activeTeamId = teams[0].id;
                  setDoc(doc(db, 'users', uid, 'data', 'profile'), { activeTeamId: teams[0].id }, { merge: true })
                    .catch(err => console.error("Auto-resolved activeTeamId update failed:", err));
                }
              }
            }
          } catch (metaErr) {
            console.error("Failed to load metadata during profile resolution:", metaErr);
          }
        }

        // Load roles and sync avatar for active club
        if (p.activeClubId) {
          const membersSnap = await getDoc(doc(db, 'clubs', p.activeClubId, 'teams', 'club_global', 'data', 'members'));
          if (membersSnap.exists()) {
            const members: ClubMember[] = membersSnap.data().members || [];
            const myRecord = members.find(m => m.userId === uid || (m.email && m.email.trim().toLowerCase() === cleanUserEmail));
            if (myRecord) {
              setUserRoles(myRecord.roles || []);
              if (myRecord.photoUrl && !p.photoUrl) {
                p.photoUrl = myRecord.photoUrl;
                setDoc(doc(db, 'users', uid, 'data', 'profile'), { photoUrl: myRecord.photoUrl }, { merge: true }).catch(() => {});
              }
            } else {
              setUserRoles([]);
            }
          } else {
            setUserRoles([]);
          }
        } else {
          setUserRoles([]);
        }

        if (p.photoUrl) {
          if (auth.currentUser && !auth.currentUser.photoURL) {
            auth.currentUser.photoURL = p.photoUrl;
          }
          setUser(prev => prev ? { ...prev, photoURL: p.photoUrl || prev.photoURL } : prev);
        }

        setUserProfile(p);
      } else {
        const defaultProfile: UserProfile = {
          fullName: cleanUserEmail ? cleanUserEmail.split('@')[0] : 'Användare',
          email: cleanUserEmail,
          photoUrl: auth.currentUser?.photoURL || undefined,
          activeClubId: null,
          activeTeamId: null,
          status: 'pending',
          onboardingCompleted: false
        };
        setUserProfile(defaultProfile);
        setUserRoles([]);
      }
    } catch (e) {
      console.error('Failed to load user profile:', e);
      setUserRoles([]);
    } finally {
      setIsProfileLoaded(true);
    }
  };

  // Helper to refresh pending user requests count for admins
  const refreshPendingRequestsCount = async () => {
    if (!user) {
      setPendingRequestsCount(0);
      return;
    }
    try {
      if (userProfile.activeClubId) {
        const snap = await getDocs(collection(db, 'clubs', userProfile.activeClubId, 'pending_requests'));
        setPendingRequestsCount(snap.size);
      } else if (isRootAdmin) {
        const snap = await getDocs(collection(db, 'pending_user_requests'));
        setPendingRequestsCount(snap.size);
      } else {
        setPendingRequestsCount(0);
      }
    } catch (err) {
      console.error('Failed to fetch pending requests count:', err);
    }
  };

  useEffect(() => {
    if (isRootAdmin || userRoles.includes('admin') || userRoles.includes('coach')) {
      refreshPendingRequestsCount();
    } else {
      setPendingRequestsCount(0);
    }
  }, [userProfile.activeClubId, userRoles, isRootAdmin, user]);

  const handleProfileUpdated = (updatedProfile: UserProfile) => {
    const clubOrTeamChanged = 
      updatedProfile.activeClubId !== userProfile.activeClubId ||
      updatedProfile.activeTeamId !== userProfile.activeTeamId;

    if (clubOrTeamChanged) {
      console.log("App: Active club or team changed. Flushing pending edits if any, and resetting data context.");
      if (sessionActionCount > 0 && userProfile.activeClubId && userProfile.activeTeamId) {
        try {
          const oldRefs = getDocRefs(user, userProfile);
          setDoc(oldRefs.docSquadRef, { squad: data.squad, updatedAt: Date.now(), lastUpdatedBy: sessionIdRef.current }).catch(() => {});
          setDoc(oldRefs.docSessionsRef, { sessions: data.sessions, deletedSessions: data.deletedSessions, updatedAt: Date.now(), lastUpdatedBy: sessionIdRef.current }).catch(() => {});
          setDoc(oldRefs.docLineupsRef, { lineups: data.lineups, activeLineupId: data.activeLineupId, updatedAt: Date.now(), lastUpdatedBy: sessionIdRef.current }).catch(() => {});
          setDoc(oldRefs.docSettingsRef, { teamUrl, adminUrl, seriesUrl, customFormations, pinnedFormationIds, trainingSettings, activeExerciseId, updatedAt: Date.now(), lastUpdatedBy: sessionIdRef.current }).catch(() => {});
        } catch (e) {
          console.warn("Could not flush old team pending edits:", e);
        }
      }

      setSessionActionCount(0);
      setHasPulledFromCloud(false);
      setIsInitialSyncDone(false);
      lastCloudDataRef.current = null;
      setData(INITIAL_DATA);
    }

    setUserProfile(updatedProfile);
    if (updatedProfile.photoUrl) {
      if (auth.currentUser) {
        auth.currentUser.photoURL = updatedProfile.photoUrl;
      }
      setUser(prev => prev ? { ...prev, photoURL: updatedProfile.photoUrl || prev.photoURL } : prev);
    }
    
    // Reload user roles for the new active club
    if (user) {
      if (updatedProfile.activeClubId) {
        getDoc(doc(db, 'clubs', updatedProfile.activeClubId, 'teams', 'club_global', 'data', 'members')).then(membersSnap => {
          if (membersSnap.exists()) {
            const members: ClubMember[] = membersSnap.data().members || [];
            const myRecord = members.find(m => m.userId === user.uid || (m.email && m.email.trim().toLowerCase() === (user.email || '').trim().toLowerCase()));
            if (myRecord) {
              setUserRoles(myRecord.roles || []);
              if (myRecord.photoUrl && !updatedProfile.photoUrl) {
                const withPhoto = { ...updatedProfile, photoUrl: myRecord.photoUrl };
                setUserProfile(withPhoto);
                if (auth.currentUser) auth.currentUser.photoURL = myRecord.photoUrl;
                setUser(prev => prev ? { ...prev, photoURL: myRecord.photoUrl || prev.photoURL } : prev);
                setDoc(doc(db, 'users', user.uid, 'data', 'profile'), { photoUrl: myRecord.photoUrl }, { merge: true }).catch(() => {});
              }
            } else {
              setUserRoles([]);
            }
          } else {
            setUserRoles([]);
          }
        }).catch(err => console.error('Failed to load roles on profile update:', err));
      } else {
        setUserRoles([]);
      }
    }
  };

  const effectiveUserPhoto = useMemo(() => {
    if (user?.photoURL && user.photoURL.trim()) return user.photoURL;
    if (userProfile?.photoUrl && userProfile.photoUrl.trim()) return userProfile.photoUrl;

    const cleanUserEmail = (user?.email || userProfile?.email || '').trim().toLowerCase();
    const cleanUserName = (userProfile?.fullName || user?.displayName || '').trim().toLowerCase();

    // Check in current squad
    if (squad && squad.length > 0) {
      const match = squad.find(sp => {
        if (!sp.photoUrl || !sp.photoUrl.trim()) return false;
        if (sp.email && cleanUserEmail && sp.email.trim().toLowerCase() === cleanUserEmail) return true;
        if (cleanUserName && sp.name && sp.name.trim().toLowerCase() === cleanUserName) return true;
        return false;
      });
      if (match?.photoUrl) return match.photoUrl;
    }

    return null;
  }, [user?.photoURL, userProfile?.photoUrl, userProfile?.email, userProfile?.fullName, user?.email, user?.displayName, squad]);

  // Clear data on user change
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (newUser) => {
      if (newUser?.uid !== user?.uid) {
        console.log("App: User changed, resetting states and action count");
        setData(INITIAL_DATA);
        setSessionActionCount(0);
        setIsInitialSyncDone(false);
        setIsProfileLoaded(false);
        setHasPulledFromCloud(false);
        lastSyncedAtRef.current = 0;
        syncUserIdRef.current = null;
        lastCloudDataRef.current = null;
      }
      setUser(newUser);
      setIsAuthReady(true);
      if (!newUser) {
        setHasPulledFromCloud(true);
        setIsProfileLoaded(true);
        setUserProfile({
          fullName: '',
          phone: '',
          personnummer: '',
          activeClubId: null,
          activeTeamId: null,
        });
        setUserRoles(['admin', 'coach']);
        setIsRootAdmin(false);
      } else {
        loadUserProfile(newUser.uid, newUser.email || '');
        checkRootAdminStatus(newUser.uid, newUser.email || '', newUser.googleEmail || null);
      }
    });
    return () => unsubscribe();
  }, [user?.uid]);

  // Internal helper to push all dirty data segments cleanly without toggling isSyncing
  const pushDirtySegments = async (forcePushAll = false, overrideData?: Partial<CoachData>) => {
    if (!user) return;
    const now = Date.now();
    const lastUpdatedBy = sessionIdRef.current;

    const effectiveData: CoachData = {
      ...(latestDataRef.current || data),
      ...(overrideData || {})
    };
    const {
      squad: pushSquad,
      exercises: pushExercises,
      sessions: pushSessions,
      deletedSessions: pushDeletedSessions,
      lineups: pushLineups,
      activeLineupId: pushActiveLineupId,
      periods: pushPeriods,
      currentPeriodId: pushCurrentPeriodId,
      teamUrl: pushTeamUrl,
      adminUrl: pushAdminUrl,
      seriesUrl: pushSeriesUrl,
      customFormations: pushCustomFormations,
      pinnedFormationIds: pushPinnedFormationIds,
      trainingSettings: pushTrainingSettings,
      activeExerciseId: pushActiveExerciseId,
      exerciseBank: pushExerciseBank,
      exerciseBankCategories: pushExerciseBankCategories
    } = effectiveData;

    const currentSynced = lastCloudDataRef.current || INITIAL_DATA;
    const nowSquadDirty = JSON.stringify(currentSynced.squad) !== JSON.stringify(pushSquad);
    const nowSessionsDirty = JSON.stringify(currentSynced.sessions) !== JSON.stringify(pushSessions) || JSON.stringify(currentSynced.deletedSessions) !== JSON.stringify(pushDeletedSessions);
    const nowExercisesDirty = JSON.stringify(currentSynced.exercises) !== JSON.stringify(pushExercises) || JSON.stringify(currentSynced.exerciseBank) !== JSON.stringify(pushExerciseBank) || JSON.stringify(currentSynced.exerciseBankCategories) !== JSON.stringify(pushExerciseBankCategories);
    const nowLineupsDirty = JSON.stringify(currentSynced.lineups) !== JSON.stringify(pushLineups) || currentSynced.activeLineupId !== pushActiveLineupId;
    const nowPeriodsDirty = JSON.stringify(currentSynced.periods) !== JSON.stringify(pushPeriods) || currentSynced.currentPeriodId !== pushCurrentPeriodId;
    const nowSettingsDirty = currentSynced.teamUrl !== pushTeamUrl || currentSynced.adminUrl !== pushAdminUrl || currentSynced.seriesUrl !== pushSeriesUrl || JSON.stringify(currentSynced.customFormations) !== JSON.stringify(pushCustomFormations) || JSON.stringify(currentSynced.pinnedFormationIds) !== JSON.stringify(pushPinnedFormationIds) || JSON.stringify(currentSynced.trainingSettings) !== JSON.stringify(pushTrainingSettings) || currentSynced.activeExerciseId !== pushActiveExerciseId;

    const writePromises = [];
    const { docSquadRef, docSessionsRef, docExercisesRef, docLineupsRef, docPeriodsRef, docSettingsRef } = getDocRefs(user, userProfile);

    const shouldForce = forcePushAll || (sessionActionCountRef.current > 0 && !nowSquadDirty && !nowSessionsDirty && !nowExercisesDirty && !nowLineupsDirty && !nowPeriodsDirty && !nowSettingsDirty);

    if (nowSquadDirty || shouldForce) {
      writePromises.push(setDoc(docSquadRef, { squad: pushSquad, updatedAt: now, lastUpdatedBy }));
    }
    if (nowSessionsDirty || shouldForce) {
      writePromises.push(setDoc(docSessionsRef, { sessions: pushSessions, deletedSessions: pushDeletedSessions, updatedAt: now, lastUpdatedBy }));
    }
    if (nowExercisesDirty || shouldForce) {
      writePromises.push(setDoc(docExercisesRef, { exercises: pushExercises, exerciseBank: pushExerciseBank, exerciseBankCategories: pushExerciseBankCategories, updatedAt: now, lastUpdatedBy }));
    }
    if (nowLineupsDirty || shouldForce) {
      writePromises.push(setDoc(docLineupsRef, { lineups: pushLineups, activeLineupId: pushActiveLineupId, updatedAt: now, lastUpdatedBy }));
    }
    if (nowPeriodsDirty || shouldForce) {
      writePromises.push(setDoc(docPeriodsRef, { periods: pushPeriods, currentPeriodId: pushCurrentPeriodId, updatedAt: now, lastUpdatedBy }));
    }
    if (nowSettingsDirty || shouldForce) {
      writePromises.push(setDoc(docSettingsRef, { teamUrl: pushTeamUrl, adminUrl: pushAdminUrl, seriesUrl: pushSeriesUrl, customFormations: pushCustomFormations, pinnedFormationIds: pushPinnedFormationIds, trainingSettings: pushTrainingSettings, activeExerciseId: pushActiveExerciseId, updatedAt: now, lastUpdatedBy }));
    }

    if (writePromises.length === 0) {
      console.log("App: No dirty data segments to push.");
      setSessionActionCount(0);
      return;
    }

    await Promise.all(writePromises);
    lastSyncedAtRef.current = now;
    syncUserIdRef.current = user.uid;
    lastCloudDataRef.current = {
      squad: pushSquad,
      exercises: pushExercises,
      sessions: pushSessions,
      deletedSessions: pushDeletedSessions,
      lineups: pushLineups,
      activeLineupId: pushActiveLineupId,
      periods: pushPeriods,
      currentPeriodId: pushCurrentPeriodId,
      activeExerciseId: pushActiveExerciseId,
      teamUrl: pushTeamUrl,
      adminUrl: pushAdminUrl,
      seriesUrl: pushSeriesUrl,
      customFormations: pushCustomFormations,
      pinnedFormationIds: pushPinnedFormationIds,
      trainingSettings: pushTrainingSettings,
      exerciseBank: pushExerciseBank,
      exerciseBankCategories: pushExerciseBankCategories
    };
    setSessionActionCount(0);
    setPrefixedItem('last_local_sync_at', now.toString(), user);
    setIsQuotaExceeded(false);
    setSyncError(null);
    console.log("App: Push successful for segments:", writePromises.length);
  };

  // Helper to fetch all segmented cloud docs to merge into local state
  const pullLatestData = async () => {
    if (!user || !isProfileLoaded || isSyncingRef.current) return;
    setSyncingStatus(true);

    try {
      // If local unsaved edits exist (sessionActionCount > 0), 
      // first flush them to the cloud so they are not lost before pulling!
      if (sessionActionCountRef.current > 0) {
        console.log("App: Local unsaved changes exist (sessionActionCount > 0). Flushing local changes to cloud first...");
        try {
          await pushDirtySegments(true);
        } catch (pushErr) {
          console.warn("App: Could not flush local edits before pull:", pushErr);
        }
      }

      console.log("App: Manually pulling segmented data from cloud with forceRefresh...");
      const { docSquadRef, docSessionsRef, docExercisesRef, docLineupsRef, docPeriodsRef, docSettingsRef } = getDocRefs(user, userProfile);

      const [squadSnap, sessionsSnap, exercisesSnap, lineupsSnap, periodsSnap, settingsSnap] = await Promise.all([
        getDoc(docSquadRef, { forceRefresh: true }),
        getDoc(docSessionsRef, { forceRefresh: true }),
        getDoc(docExercisesRef, { forceRefresh: true }),
        getDoc(docLineupsRef, { forceRefresh: true }),
        getDoc(docPeriodsRef, { forceRefresh: true }),
        getDoc(docSettingsRef, { forceRefresh: true }),
      ]);

      // Read current local state/cache as fallback for missing cloud docs to prevent wiping
      const savedSquad = getPrefixedItem('football_squad', user);
      const savedSessions = getPrefixedItem('football_sessions', user);
      const savedDeletedSessions = getPrefixedItem('football_deleted_sessions', user);
      const savedExercises = getPrefixedItem('football_exercises', user);
      const savedLineups = getPrefixedItem('football_lineups', user);
      const savedPeriods = getPrefixedItem('football_periods', user);
      const savedExerciseBank = getPrefixedItem('football_exercise_bank', user);
      const savedExerciseBankCategories = getPrefixedItem('football_exercise_bank_categories', user);

      const localSquad = squad.length > 0 ? squad : (savedSquad ? JSON.parse(savedSquad) : []);
      const localSessions = sessions.length > 0 ? sessions : (savedSessions ? JSON.parse(savedSessions) : []);
      const localDeletedSessions = deletedSessions.length > 0 ? deletedSessions : (savedDeletedSessions ? JSON.parse(savedDeletedSessions) : []);
      const localExercises = exercises.length > 0 ? exercises : (savedExercises ? JSON.parse(savedExercises) : []);
      const localExerciseBank = exerciseBank.length > 0 ? exerciseBank : (savedExerciseBank ? JSON.parse(savedExerciseBank) : []);
      const localExerciseBankCategories = exerciseBankCategories.length > 0 ? exerciseBankCategories : (savedExerciseBankCategories ? JSON.parse(savedExerciseBankCategories) : []);
      const localLineups = lineups.length > 0 ? lineups : (savedLineups ? JSON.parse(savedLineups) : []);
      const localPeriods = periods.length > 0 ? periods : (savedPeriods ? JSON.parse(savedPeriods) : []);

      const remoteLineups = lineupsSnap.exists() ? (lineupsSnap.data().lineups || []) : [];
      const mergedLineups = deduplicateById(mergeLineups(remoteLineups, localLineups));
      const targetActiveLineupId = activeLineupId || (lineupsSnap.exists() ? (lineupsSnap.data().activeLineupId || null) : null) || (mergedLineups[0]?.id || null);

      const remoteExercises = exercisesSnap.exists() ? (exercisesSnap.data().exercises || []) : [];
      const mergedExercises = deduplicateById(mergeExercises(remoteExercises, localExercises));

      const remoteSessions = sessionsSnap.exists() ? (sessionsSnap.data().sessions || []) : [];
      const mergedSessions = normalizeSessionMoments(deduplicateById(mergeSessions(remoteSessions, localSessions)));

      const remoteBank = exercisesSnap.exists() ? (exercisesSnap.data().exerciseBank || []) : [];
      const mergedBank = normalizeExerciseBank(deduplicateById(mergeExerciseBank(remoteBank, localExerciseBank)));

      const targetActiveExerciseId = activeExerciseId 
        || (typeof window !== 'undefined' ? sessionStorage.getItem('coach_active_exercise_id') : null)
        || getPrefixedItem('active_exercise_id', user) 
        || (settingsSnap.exists() ? (settingsSnap.data().activeExerciseId || null) : null);

      const updatedState: CoachData = {
        squad: squadSnap.exists() ? deduplicateById(squadSnap.data().squad || []) : deduplicateById(localSquad),
        sessions: mergedSessions,
        deletedSessions: sessionsSnap.exists() ? deduplicateById(sessionsSnap.data().deletedSessions || []) : deduplicateById(localDeletedSessions),
        exercises: mergedExercises,
        exerciseBank: mergedBank,
        exerciseBankCategories: exercisesSnap.exists() ? (exercisesSnap.data().exerciseBankCategories || []) : localExerciseBankCategories,
        lineups: mergedLineups,
        activeLineupId: targetActiveLineupId,
        periods: periodsSnap.exists() ? deduplicateById(periodsSnap.data().periods || []) : deduplicateById(localPeriods),
        currentPeriodId: periodsSnap.exists() ? (periodsSnap.data().currentPeriodId || null) : currentPeriodId,
        teamUrl: settingsSnap.exists() ? (settingsSnap.data().teamUrl || '') : teamUrl,
        adminUrl: settingsSnap.exists() ? (settingsSnap.data().adminUrl || '') : adminUrl,
        seriesUrl: settingsSnap.exists() ? (settingsSnap.data().seriesUrl || '') : seriesUrl,
        customFormations: settingsSnap.exists() ? deduplicateById(settingsSnap.data().customFormations || []) : customFormations,
        pinnedFormationIds: settingsSnap.exists() ? (settingsSnap.data().pinnedFormationIds || ['4-2-3-1', '4-4-2', '4-3-3']) : pinnedFormationIds,
        trainingSettings: settingsSnap.exists() ? (settingsSnap.data().trainingSettings || INITIAL_DATA.trainingSettings) : trainingSettings,
        activeExerciseId: targetActiveExerciseId,
      };

      if (userProfile.activeClubId && userProfile.activeTeamId) {
        const { mergedSquad } = await getMergedSquadAndClubMembers(
          updatedState.squad,
          userProfile.activeClubId,
          userProfile.activeTeamId
        );
        updatedState.squad = mergedSquad;
        syncSquadToClubMembers(mergedSquad, userProfile.activeClubId, userProfile.activeTeamId)
          .catch(err => console.error("Error syncing squad in pullLatestData:", err));
      }

      setData(updatedState);
      lastCloudDataRef.current = updatedState;
      syncUserIdRef.current = user.uid;
      setSessionActionCount(0);
      setIsQuotaExceeded(false);
      setSyncError(null);

      try {
        setPrefixedItem('football_exercises', JSON.stringify(mergedExercises), user);
        setPrefixedItem('football_sessions', JSON.stringify(mergedSessions), user);
        setPrefixedItem('football_lineups', JSON.stringify(mergedLineups), user);
        if (targetActiveExerciseId) {
          setPrefixedItem('active_exercise_id', targetActiveExerciseId, user);
          sessionStorage.setItem('coach_active_exercise_id', targetActiveExerciseId);
        }
      } catch (e) {}

      const hasUnsyncedLocalExercises = mergedExercises.some(me => !remoteExercises.some(re => re.id === me.id));
      const hasUnsyncedLocalSessions = mergedSessions.some(ms => !remoteSessions.some(rs => rs.id === ms.id));
      if (hasUnsyncedLocalExercises || hasUnsyncedLocalSessions) {
        console.log("App: Preserved local unsynced exercises/sessions during pull. Triggering follow-up push.");
        setTimeout(() => {
          pushDirtySegments(true).catch(e => console.warn("App: Follow-up push after pull failed:", e));
        }, 150);
      }

      console.log("App: Segmented manual sync successful!");
    } catch (err) {
      console.error("App: Segmented manual sync failed", err);
      if (isQuotaError(err)) {
        setIsQuotaExceeded(true);
      } else {
        setSyncError((err as Error)?.message || 'Kunde inte hämta data');
      }
      handleFirestoreError(err, OperationType.GET, `users/${user.uid}/data/*`);
    } finally {
      setSyncingStatus(false);
    }
  };

  // Sync when tab gains focus or hides (visibilitychange & beforeunload)
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (sessionActionCount > 0 || isSyncing) {
        handleManualPush();
        e.preventDefault();
        e.returnValue = '';
      }
    };

    const handleVisibilityChange = async () => {
      if (document.visibilityState === 'hidden') {
        if (sessionActionCount > 0 && user && isAuthReady && isProfileLoaded) {
          console.log("App: Tab hidden with unsaved changes. Flushing immediately to cloud...");
          await handleManualPush();
        }
      } else if (document.visibilityState === 'visible') {
        if (sessionActionCount > 0 && user && isAuthReady && isProfileLoaded) {
          console.log("App: Tab focused with unsaved actions. Syncing to cloud...");
          await handleManualPush();
        } else if (user && isAuthReady && isProfileLoaded && isInitialSyncDone && !isSyncing) {
          console.log("App: Tab focused, pulling latest cloud updates...");
          await pullLatestData();
        }
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [sessionActionCount, isSyncing, user, isAuthReady, isProfileLoaded, isInitialSyncDone, squad, sessions, deletedSessions, exercises, exerciseBank, exerciseBankCategories, lineups, activeLineupId, periods, currentPeriodId, teamUrl, adminUrl, seriesUrl, customFormations, trainingSettings, activeExerciseId, userProfile]);

  // Segmented cloud data loader, migration and lineups real-time syncer
  useEffect(() => {
    if (!user || !isAuthReady || !isProfileLoaded) {
      return;
    }

    console.log("App: Initializing segmented cloud loader for", user.email, "profileLoaded:", isProfileLoaded, "club:", userProfile.activeClubId, "team:", userProfile.activeTeamId);
    let isSubscribed = true;
    let unsubscribeLineups: (() => void) | null = null;

    const initializeAndLoad = async () => {
      // Step 0: Ensure flags and state are clean before reading
      setHasPulledFromCloud(false);
      setIsInitialSyncDone(false);
      setSessionActionCount(0);
      lastCloudDataRef.current = null;

      try {
        const { docSquadRef, docSessionsRef, docExercisesRef, docLineupsRef, docPeriodsRef, docSettingsRef } = getDocRefs(user, userProfile);
        const docOldStateRef = doc(db, 'users', user.uid, 'config', 'state');

        // Step 1: Check if any segmented documents exist
        const [squadSnap, sessionsSnap, exercisesSnap, lineupsSnap, periodsSnap, settingsSnap] = await Promise.all([
          getDoc(docSquadRef),
          getDoc(docSessionsRef),
          getDoc(docExercisesRef),
          getDoc(docLineupsRef),
          getDoc(docPeriodsRef),
          getDoc(docSettingsRef),
        ]);

        const docsExist = squadSnap.exists() || sessionsSnap.exists() || exercisesSnap.exists() || lineupsSnap.exists() || periodsSnap.exists() || settingsSnap.exists();

        let loadedState: CoachData;

        if (userProfile.activeClubId && userProfile.activeTeamId) {
          // STRICT CLUB & TEAM ISOLATION
          if (!docsExist) {
            console.log(`App: Clean initial state for new club team [club: ${userProfile.activeClubId}, team: ${userProfile.activeTeamId}]`);
            loadedState = {
              ...INITIAL_DATA,
              squad: [],
              sessions: [],
              deletedSessions: [],
              exercises: [],
              lineups: [],
              activeLineupId: null,
              periods: [],
              currentPeriodId: null,
              activeExerciseId: new URLSearchParams(window.location.search).get('ex') || sessionStorage.getItem('coach_active_exercise_id') || getPrefixedItem('active_exercise_id', user) || null,
              teamUrl: '',
              adminUrl: '',
              seriesUrl: '',
              customFormations: [],
              pinnedFormationIds: ['4-2-3-1', '4-4-2', '4-3-3'],
              trainingSettings: INITIAL_DATA.trainingSettings,
              exerciseBank: [],
              exerciseBankCategories: []
            };
          } else {
            const savedClubLineups = getPrefixedItem('football_lineups', user);
            const cachedClubLineups = savedClubLineups ? deduplicateById<Lineup>(JSON.parse(savedClubLineups)) : [];
            const remoteClubLineups = lineupsSnap.exists() ? (lineupsSnap.data().lineups || []) : [];
            const mergedClubLineups = deduplicateById(mergeLineups(remoteClubLineups, cachedClubLineups));
            const clubActiveId = (lineupsSnap.exists() ? (lineupsSnap.data().activeLineupId || null) : null) || (mergedClubLineups[0]?.id || null);

            const savedClubExercises = getPrefixedItem('football_exercises', user);
            const cachedClubExercises = savedClubExercises ? deduplicateById<Exercise>(JSON.parse(savedClubExercises)) : [];
            const remoteClubExercises = exercisesSnap.exists() ? (exercisesSnap.data().exercises || []) : [];
            const mergedClubExercises = deduplicateById(mergeExercises(remoteClubExercises, cachedClubExercises));

            const savedClubSessions = getPrefixedItem('football_sessions', user);
            const cachedClubSessions = savedClubSessions ? deduplicateById<TrainingSession>(JSON.parse(savedClubSessions)) : [];
            const remoteClubSessions = sessionsSnap.exists() ? (sessionsSnap.data().sessions || []) : [];
            const mergedClubSessions = normalizeSessionMoments(deduplicateById(mergeSessions(remoteClubSessions, cachedClubSessions)));

            const savedClubBank = getPrefixedItem('football_exercise_bank', user);
            const cachedClubBank = savedClubBank ? deduplicateById<BankExercise>(JSON.parse(savedClubBank)) : [];
            const remoteClubBank = exercisesSnap.exists() ? (exercisesSnap.data().exerciseBank || []) : [];
            const mergedClubBank = normalizeExerciseBank(deduplicateById(mergeExerciseBank(remoteClubBank, cachedClubBank)));

            const clubActiveExerciseId = new URLSearchParams(window.location.search).get('ex') 
              || sessionStorage.getItem('coach_active_exercise_id') 
              || getPrefixedItem('active_exercise_id', user) 
              || (settingsSnap.exists() ? (settingsSnap.data().activeExerciseId || null) : null);

            loadedState = {
              squad: squadSnap.exists() ? deduplicateById(squadSnap.data().squad || []) : [],
              sessions: mergedClubSessions,
              deletedSessions: sessionsSnap.exists() ? deduplicateById(sessionsSnap.data().deletedSessions || []) : [],
              exercises: mergedClubExercises,
              exerciseBank: mergedClubBank,
              exerciseBankCategories: exercisesSnap.exists() ? (exercisesSnap.data().exerciseBankCategories || []) : [],
              lineups: mergedClubLineups,
              activeLineupId: clubActiveId,
              periods: periodsSnap.exists() ? deduplicateById(periodsSnap.data().periods || []) : [],
              currentPeriodId: periodsSnap.exists() ? (periodsSnap.data().currentPeriodId || null) : null,
              teamUrl: settingsSnap.exists() ? (settingsSnap.data().teamUrl || '') : '',
              adminUrl: settingsSnap.exists() ? (settingsSnap.data().adminUrl || '') : '',
              seriesUrl: settingsSnap.exists() ? (settingsSnap.data().seriesUrl || '') : '',
              customFormations: settingsSnap.exists() ? deduplicateById(settingsSnap.data().customFormations || []) : [],
              pinnedFormationIds: settingsSnap.exists() ? (settingsSnap.data().pinnedFormationIds || ['4-2-3-1', '4-4-2', '4-3-3']) : ['4-2-3-1', '4-4-2', '4-3-3'],
              trainingSettings: settingsSnap.exists() ? (settingsSnap.data().trainingSettings || INITIAL_DATA.trainingSettings) : INITIAL_DATA.trainingSettings,
              activeExerciseId: clubActiveExerciseId,
            };
          }

          // Merge squad with club members assigned to this team
          const { mergedSquad } = await getMergedSquadAndClubMembers(
            loadedState.squad,
            userProfile.activeClubId,
            userProfile.activeTeamId
          );
          loadedState.squad = mergedSquad;
        } else {
          // Private mode (single user with no active club/team selected)
          // Load local cache as fallback for missing segments or offline recovery
          const savedSquad = getPrefixedItem('football_squad', user);
          const savedSessions = getPrefixedItem('football_sessions', user);
          const savedDeletedSessions = getPrefixedItem('football_deleted_sessions', user);
          const savedExercises = getPrefixedItem('football_exercises', user);
          const savedSettings = getPrefixedItem('training_settings', user);
          const savedLineups = getPrefixedItem('football_lineups', user);
          const savedActiveLineupId = getPrefixedItem('active_lineup_id', user);
          const savedPeriods = getPrefixedItem('football_periods', user);
          const savedCurrentPeriodId = getPrefixedItem('current_period_id', user);
          const savedActiveExerciseId = getPrefixedItem('active_exercise_id', user);
          const savedTeamUrl = getPrefixedItem('team_url', user);
          const savedAdminUrl = getPrefixedItem('admin_url', user);
          const savedSeriesUrl = getPrefixedItem('series_url', user);
          const savedExerciseBank = getPrefixedItem('football_exercise_bank', user);
          const savedExerciseBankCategories = getPrefixedItem('football_exercise_bank_categories', user);

          const cachedSquad = savedSquad ? (Array.from(new Map(JSON.parse(savedSquad).map((p: any) => [p.id, p])).values()) as SquadPlayer[]) : [];
          const cachedSessions = savedSessions ? deduplicateById<TrainingSession>(JSON.parse(savedSessions)) : [];
          const cachedDeletedSessions = savedDeletedSessions ? deduplicateById<TrainingSession>(JSON.parse(savedDeletedSessions)) : [];
          const cachedExercises = savedExercises ? deduplicateById<Exercise>(JSON.parse(savedExercises)) : [];
          const cachedExerciseBank = savedExerciseBank ? deduplicateById<BankExercise>(JSON.parse(savedExerciseBank)) : [];
          const cachedExerciseBankCategories = savedExerciseBankCategories ? JSON.parse(savedExerciseBankCategories) : [];
          const cachedLineups = savedLineups ? deduplicateById<Lineup>(JSON.parse(savedLineups)) : [];
          const cachedPeriods = savedPeriods ? deduplicateById<Period>(JSON.parse(savedPeriods)) : [];
          const cachedCustomFormations = getPrefixedItem('custom_formations', user) ? deduplicateById<any>(JSON.parse(getPrefixedItem('custom_formations', user)!)) : [];
          const cachedPinnedFormations = getPrefixedItem('pinned_formations', user) ? JSON.parse(getPrefixedItem('pinned_formations', user)!) : ['4-2-3-1', '4-4-2', '4-3-3'];
          const cachedSettings = savedSettings ? JSON.parse(savedSettings) : INITIAL_DATA.trainingSettings;

          if (!docsExist) {
            console.log("App: Private mode - segmented data docs not found, checking for old state migration...");
            const oldStateSnap = await getDoc(docOldStateRef);

            if (oldStateSnap.exists()) {
              const oldData = oldStateSnap.data();
              const squadData = { squad: oldData.squad || [] };
              const sessionsData = { sessions: oldData.sessions || [], deletedSessions: oldData.deletedSessions || [] };
              const exercisesData = { exercises: oldData.exercises || [], exerciseBank: oldData.exerciseBank || [], exerciseBankCategories: oldData.exerciseBankCategories || [] };
              const lineupsData = { lineups: oldData.lineups || [], activeLineupId: oldData.activeLineupId || null };
              const periodsData = { periods: oldData.periods || [], currentPeriodId: oldData.currentPeriodId || null };
              const settingsData = {
                teamUrl: oldData.teamUrl || '',
                adminUrl: oldData.adminUrl || '',
                seriesUrl: oldData.seriesUrl || '',
                customFormations: oldData.customFormations || [],
                pinnedFormationIds: oldData.pinnedFormationIds || ['4-2-3-1', '4-4-2', '4-3-3'],
                trainingSettings: oldData.trainingSettings || INITIAL_DATA.trainingSettings,
                activeExerciseId: oldData.activeExerciseId || null,
              };

              const now = Date.now();
              await Promise.all([
                setDoc(docSquadRef, { ...squadData, updatedAt: now, lastUpdatedBy: 'migration' }),
                setDoc(docSessionsRef, { ...sessionsData, updatedAt: now, lastUpdatedBy: 'migration' }),
                setDoc(docExercisesRef, { ...exercisesData, updatedAt: now, lastUpdatedBy: 'migration' }),
                setDoc(docLineupsRef, { ...lineupsData, updatedAt: now, lastUpdatedBy: 'migration' }),
                setDoc(docPeriodsRef, { ...periodsData, updatedAt: now, lastUpdatedBy: 'migration' }),
                setDoc(docSettingsRef, { ...settingsData, updatedAt: now, lastUpdatedBy: 'migration' }),
              ]);

              loadedState = {
                squad: squadData.squad,
                sessions: sessionsData.sessions,
                deletedSessions: sessionsData.deletedSessions,
                exercises: exercisesData.exercises,
                exerciseBank: exercisesData.exerciseBank,
                exerciseBankCategories: exercisesData.exerciseBankCategories,
                lineups: lineupsData.lineups,
                activeLineupId: lineupsData.activeLineupId,
                periods: periodsData.periods,
                currentPeriodId: periodsData.currentPeriodId,
                teamUrl: settingsData.teamUrl,
                adminUrl: settingsData.adminUrl,
                seriesUrl: settingsData.seriesUrl,
                customFormations: settingsData.customFormations,
                pinnedFormationIds: settingsData.pinnedFormationIds,
                trainingSettings: settingsData.trainingSettings,
                activeExerciseId: new URLSearchParams(window.location.search).get('ex') || sessionStorage.getItem('coach_active_exercise_id') || getPrefixedItem('active_exercise_id', user) || settingsData.activeExerciseId,
              };
            } else {
              const hasSquad = cachedSquad.length > 0;
              const hasSessions = cachedSessions.length > 0;
              const hasExercises = cachedExercises.length > 0;
              const hasSettings = savedSettings && JSON.parse(savedSettings).icsUrl;

              if (hasSquad || hasSessions || hasExercises || hasSettings) {
                loadedState = {
                  squad: cachedSquad,
                  exercises: cachedExercises,
                  sessions: cachedSessions,
                  deletedSessions: cachedDeletedSessions,
                  lineups: cachedLineups,
                  activeLineupId: savedActiveLineupId || null,
                  periods: cachedPeriods,
                  currentPeriodId: savedCurrentPeriodId || null,
                  activeExerciseId: new URLSearchParams(window.location.search).get('ex') || sessionStorage.getItem('coach_active_exercise_id') || savedActiveExerciseId || null,
                  teamUrl: savedTeamUrl || '',
                  adminUrl: savedAdminUrl || '',
                  seriesUrl: savedSeriesUrl || '',
                  customFormations: cachedCustomFormations,
                  pinnedFormationIds: cachedPinnedFormations,
                  trainingSettings: cachedSettings,
                  exerciseBank: cachedExerciseBank,
                  exerciseBankCategories: cachedExerciseBankCategories
                };
                setSessionActionCount(1);
              } else {
                loadedState = INITIAL_DATA;
              }
            }
          } else {
            const remoteLineups = lineupsSnap.exists() ? (lineupsSnap.data().lineups || []) : [];
            const mergedLineups = deduplicateById(mergeLineups(remoteLineups, cachedLineups));
            const targetActiveLineupId = (lineupsSnap.exists() ? (lineupsSnap.data().activeLineupId || null) : null) || (savedActiveLineupId || null) || (cachedLineups[0]?.id || null);

            const remoteExercises = exercisesSnap.exists() ? (exercisesSnap.data().exercises || []) : [];
            const mergedExercises = deduplicateById(mergeExercises(remoteExercises, cachedExercises));

            const remoteSessions = sessionsSnap.exists() ? (sessionsSnap.data().sessions || []) : [];
            const mergedSessions = normalizeSessionMoments(deduplicateById(mergeSessions(remoteSessions, cachedSessions)));

            const remoteBank = exercisesSnap.exists() ? (exercisesSnap.data().exerciseBank || []) : [];
            const mergedBank = normalizeExerciseBank(deduplicateById(mergeExerciseBank(remoteBank, cachedExerciseBank)));

            const targetActiveExerciseId = new URLSearchParams(window.location.search).get('ex') 
              || sessionStorage.getItem('coach_active_exercise_id') 
              || savedActiveExerciseId 
              || (settingsSnap.exists() ? (settingsSnap.data().activeExerciseId || null) : null);

            loadedState = {
              squad: squadSnap.exists() ? deduplicateById(squadSnap.data().squad || []) : cachedSquad,
              sessions: mergedSessions,
              deletedSessions: sessionsSnap.exists() ? deduplicateById(sessionsSnap.data().deletedSessions || []) : cachedDeletedSessions,
              exercises: mergedExercises,
              exerciseBank: mergedBank,
              exerciseBankCategories: exercisesSnap.exists() ? (exercisesSnap.data().exerciseBankCategories || []) : cachedExerciseBankCategories,
              lineups: mergedLineups,
              activeLineupId: targetActiveLineupId,
              periods: periodsSnap.exists() ? deduplicateById(periodsSnap.data().periods || []) : cachedPeriods,
              currentPeriodId: periodsSnap.exists() ? (periodsSnap.data().currentPeriodId || null) : (savedCurrentPeriodId || null),
              teamUrl: settingsSnap.exists() ? (settingsSnap.data().teamUrl || '') : (savedTeamUrl || ''),
              adminUrl: settingsSnap.exists() ? (settingsSnap.data().adminUrl || '') : (savedAdminUrl || ''),
              seriesUrl: settingsSnap.exists() ? (settingsSnap.data().seriesUrl || '') : (savedSeriesUrl || ''),
              customFormations: settingsSnap.exists() ? deduplicateById(settingsSnap.data().customFormations || []) : cachedCustomFormations,
              pinnedFormationIds: settingsSnap.exists() ? (settingsSnap.data().pinnedFormationIds || ['4-2-3-1', '4-4-2', '4-3-3']) : cachedPinnedFormations,
              trainingSettings: settingsSnap.exists() ? (settingsSnap.data().trainingSettings || INITIAL_DATA.trainingSettings) : cachedSettings,
              activeExerciseId: targetActiveExerciseId,
            };
          }
        }

        if (userProfile.activeClubId && userProfile.activeTeamId) {
          const { mergedSquad } = await getMergedSquadAndClubMembers(
            loadedState.squad,
            userProfile.activeClubId,
            userProfile.activeTeamId
          );
          loadedState.squad = mergedSquad;
          syncSquadToClubMembers(mergedSquad, userProfile.activeClubId, userProfile.activeTeamId)
            .catch(err => console.error("Error syncing squad on initial load:", err));
        }

        if (isSubscribed) {
          setData(loadedState);
          lastCloudDataRef.current = loadedState;
          syncUserIdRef.current = user.uid;
          const syncTime = Date.now();
          lastSyncedAtRef.current = syncTime;
          localStorage.setItem('last_local_sync_at', syncTime.toString());
          localStorage.setItem('last_local_user_id', user.uid);
          setHasPulledFromCloud(true);
          setIsInitialSyncDone(true);

          try {
            setPrefixedItem('football_exercises', JSON.stringify(loadedState.exercises), user);
            setPrefixedItem('football_sessions', JSON.stringify(loadedState.sessions), user);
            setPrefixedItem('football_lineups', JSON.stringify(loadedState.lineups), user);
            if (loadedState.activeExerciseId) {
              setPrefixedItem('active_exercise_id', loadedState.activeExerciseId, user);
              sessionStorage.setItem('coach_active_exercise_id', loadedState.activeExerciseId);
            }
          } catch (e) {}

          const remoteExercises = exercisesSnap.exists() ? (exercisesSnap.data().exercises || []) : [];
          const remoteSessions = sessionsSnap.exists() ? (sessionsSnap.data().sessions || []) : [];
          const hasUnsyncedExercises = loadedState.exercises.some(le => !remoteExercises.some(re => re.id === le.id));
          const hasUnsyncedSessions = loadedState.sessions.some(ls => !remoteSessions.some(rs => rs.id === ls.id));
          if (hasUnsyncedExercises || hasUnsyncedSessions) {
            console.log("App: Preserved local exercises/sessions on initial load that are not in cloud yet. Syncing to cloud...");
            setTimeout(() => {
              pushDirtySegments(true).catch(e => console.warn("App: Initial sync push failed:", e));
            }, 300);
          }
        }

        // Subscribe to real-time lineups updates
        if (isSubscribed) {
          console.log("App: Listening to real-time lineups updates on users/{uid}/data/lineups...");
          unsubscribeLineups = onSnapshot(docLineupsRef, (snapshot) => {
            if (snapshot.metadata.hasPendingWrites) {
              return;
            }

            if (!snapshot.exists()) return;
            const remoteData = snapshot.data();
            if (!remoteData) return;

            // If the write came from our own active session, ignore it to prevent race condition rollbacks
            if (remoteData.lastUpdatedBy === sessionIdRef.current) {
              if (lastCloudDataRef.current) {
                lastCloudDataRef.current.lineups = remoteData.lineups || [];
                lastCloudDataRef.current.activeLineupId = remoteData.activeLineupId || null;
              }
              return;
            }

            const newLineups = remoteData.lineups || [];
            const newActiveLineupId = remoteData.activeLineupId || null;

            // Skip applying remote updates if local writes/actions are currently pending
            if (sessionActionCountRef.current > 0) {
              pendingCloudUpdateRef.current = { lineups: newLineups, activeLineupId: newActiveLineupId };
              console.log("App: Local edits pending. Queued lineups update from cloud.");
              return;
            }

            setData(prev => {
              const merged = mergeLineups(newLineups, prev.lineups);
              const nextActiveId = prev.activeLineupId || newActiveLineupId || (merged[0]?.id || null);
              if (JSON.stringify(prev.lineups) === JSON.stringify(merged) && prev.activeLineupId === nextActiveId) {
                return prev;
              }
              console.log("App: Real-time update of lineups merged from cloud");
              const updated = {
                ...prev,
                lineups: merged,
                activeLineupId: nextActiveId
              };
              try {
                setPrefixedItem('football_lineups', JSON.stringify(merged), user);
                setPrefixedItem('active_lineup_id', nextActiveId || '', user);
              } catch (e) {}
              if (lastCloudDataRef.current) {
                lastCloudDataRef.current.lineups = merged;
                lastCloudDataRef.current.activeLineupId = nextActiveId;
              }
              return updated;
            });
          }, (error) => {
            console.error("App: Lineup snapshot error:", error);
            if (isQuotaError(error)) {
              setIsQuotaExceeded(true);
            }
            handleFirestoreError(error, OperationType.GET, `users/${user.uid}/data/lineups`);
          });
        }
      } catch (error) {
        console.error("App: Segmented loader initialization failed:", error);
        if (isQuotaError(error)) {
          setIsQuotaExceeded(true);
        }
        if (isSubscribed) {
          syncUserIdRef.current = user.uid;
          setHasPulledFromCloud(true);
          setIsInitialSyncDone(true);
        }
        handleFirestoreError(error, OperationType.GET, `users/${user.uid}/data/*`);
      }
    };

    initializeAndLoad();

    return () => {
      isSubscribed = false;
      if (unsubscribeLineups) {
        unsubscribeLineups();
      }
    };
  }, [user?.uid, isAuthReady, isProfileLoaded, userProfile.activeClubId, userProfile.activeTeamId]);

  // Push Local Actions to Cloud with dynamic debounce and granular dirty tracking
  useEffect(() => {
    if (isTimerRunning) {
      // Pause automatic background push only while the timer is actively ticking down
      return;
    }

    if (user && isAuthReady && isProfileLoaded && isInitialSyncDone && hasPulledFromCloud && sessionActionCount > 0 && !isSyncing && !isQuotaExceeded) {
      if (syncUserIdRef.current && syncUserIdRef.current !== user.uid) return;
      syncUserIdRef.current = user.uid;

      const debounceDelay = 1200; // 1.2s debounce so typing/planning changes sync quickly and cleanly to cloud without spamming

      const syncData = async () => {
        if (!user || (syncUserIdRef.current && syncUserIdRef.current !== user.uid) || isSyncingRef.current) return;

        console.log(`App: Auto-syncing dirty segments to cloud. Debounce used: ${debounceDelay}ms`);
        setSyncingStatus(true);

        try {
          await pushDirtySegments();
        } catch (error) {
          console.error("App: Auto-sync push failed", error);
          if (isQuotaError(error)) {
            setIsQuotaExceeded(true);
            setSessionActionCount(0);
          } else {
            setSyncError((error as Error)?.message || 'Okänt synkfel');
          }
          handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}/data/*`);
        } finally {
          setSyncingStatus(false);
        }
      };

      const timeout = setTimeout(syncData, debounceDelay);
      return () => clearTimeout(timeout);
    }
  }, [squad, exercises, sessions, deletedSessions, lineups, activeLineupId, periods, currentPeriodId, activeExerciseId, teamUrl, adminUrl, seriesUrl, customFormations, pinnedFormationIds, trainingSettings, exerciseBank, exerciseBankCategories, sessionActionCount, user?.uid, isAuthReady, isProfileLoaded, isInitialSyncDone, hasPulledFromCloud, isSyncing, isQuotaExceeded, view]);

  // Sync shared leaderboards globally with optimized, less aggressive debouncing
  useEffect(() => {
    if (activeExerciseId !== null || view === 'exercise') {
      // Skip publishing/sharing leaderboard updates while actively in a competition/exercise view.
      return;
    }
    if (user && isAuthReady && isInitialSyncDone && !isQuotaExceeded) {
      const syncSharedLeaderboards = async () => {
        const sharedPeriods = periods.filter(p => p.shareId);
        if (sharedPeriods.length === 0) return;

        try {
          for (const period of sharedPeriods) {
            const stats = calculateLeaderboard(squad, exercises, period.id, periods);
            
            // Build comparison data WITHOUT the updated timestamp to determine if real data changed
            const comparisonData = {
              id: period.shareId,
              name: period.name,
              standings: stats.map((p: any) => ({
                playerId: p.id,
                playerName: p.name,
                role: p.role,
                imageUrl: p.photoUrl || null,
                points: p.totalPoints,
                history: p.history || []
              })),
              startDate: period.startDate || null,
              endDate: period.endDate || null,
              coachUid: user.uid,
              activeExerciseId: activeExerciseId
            };

            const comparisonString = JSON.stringify(comparisonData);
            if (lastSharedLeaderboardsRef.current[period.shareId!] === comparisonString) {
              console.log(`App: Skipping leaderboard sync for ${period.name} (has not changed)`);
              continue;
            }

            console.log(`App: Leaderboard data changed for ${period.name}, writing to shared_leaderboards`);
            const dataToUpdate = {
              ...comparisonData,
              updatedAt: Date.now()
            };
            
            await setDoc(doc(db, 'shared_leaderboards', period.shareId!), dataToUpdate, { merge: true });
            lastSharedLeaderboardsRef.current[period.shareId!] = comparisonString;
          }
        } catch (error) {
          console.error("Error syncing shared leaderboards globally:", error);
          if (isQuotaError(error)) {
            setIsQuotaExceeded(true);
          }
          handleFirestoreError(error, OperationType.WRITE, `shared_leaderboards/*`);
        }
      };

      let debounceDelay = 45000; // Default 45s low-frequency debounce during general score updates
      const lastSynced = lastCloudDataRef.current;
      if (lastSynced) {
        // If an exercise was recently finished compared to the cloud state, publish the leaderboard final results in 5 seconds
        const hasFinishedChange = exercises.some(e => {
          const cloudEx = lastSynced.exercises.find((cx: any) => cx.id === e.id);
          return e.isFinished && (!cloudEx || !cloudEx.isFinished);
        });
        if (hasFinishedChange) {
          debounceDelay = 5000;
        }
      }

      const timeoutId = setTimeout(syncSharedLeaderboards, debounceDelay);
      return () => clearTimeout(timeoutId);
    }
  }, [squad, exercises, periods, user, isAuthReady, isInitialSyncDone, isQuotaExceeded, activeExerciseId]);

  // Update localStorage for guests
  useEffect(() => {
    if (!user && isAuthReady && isInitialSyncDone) {
      setPrefixedItem('football_squad', JSON.stringify(squad), user);
      setPrefixedItem('football_exercises', JSON.stringify(exercises), user);
      setPrefixedItem('football_lineups', JSON.stringify(lineups), user);
      setPrefixedItem('active_lineup_id', activeLineupId || '', user);
      setPrefixedItem('football_periods', JSON.stringify(periods), user);
      setPrefixedItem('current_period_id', currentPeriodId, user);
    }
  }, [squad, exercises, lineups, activeLineupId, periods, currentPeriodId, user, isAuthReady, isInitialSyncDone]);

  // REMOVED: Redundant secondary listener

  useEffect(() => {
    const handlePopState = () => {
      const params = new URLSearchParams(window.location.search);
      const shareId = params.get('share');
      setSharedLeaderboardId(shareId);
      if (shareId) setView('leaderboard');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  useEffect(() => {
    if (sharedLeaderboardId) {
      setView('leaderboard');
    }
  }, [sharedLeaderboardId]);

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      root.style.colorScheme = 'dark';
    } else {
      root.classList.remove('dark');
      root.style.colorScheme = 'light';
    }
    try {
      localStorage.setItem('score_theme', theme);
    } catch (e) {}
  }, [theme]);

  useEffect(() => {
    if (activeExerciseId) {
      setPrefixedItem('active_exercise_id', activeExerciseId, user);
      sessionStorage.setItem('coach_active_exercise_id', activeExerciseId);
    } else if (view !== 'exercise') {
      removePrefixedItem('active_exercise_id', user);
      sessionStorage.removeItem('coach_active_exercise_id');
    }
  }, [activeExerciseId, user, view]);

  const effectiveActiveExerciseId = activeExerciseId 
    || (typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('ex') : null)
    || (typeof window !== 'undefined' ? sessionStorage.getItem('coach_active_exercise_id') : null);

  const activeExercise = exercises.find(e => e.id === effectiveActiveExerciseId);

  useEffect(() => {
    if (!activeExerciseId && effectiveActiveExerciseId && activeExercise) {
      setData(prev => ({ ...prev, activeExerciseId: effectiveActiveExerciseId }));
    }
  }, [activeExerciseId, effectiveActiveExerciseId, activeExercise]);

  const handleStartExercise = (
    name: string, 
    icon: string, 
    teams: Omit<Team, 'score'>[], 
    sortByScore: boolean, 
    showTimer: boolean, 
    defaultTimerMinutes: number, 
    defaultTimerSeconds: number, 
    jokerPlayerIds: string[], 
    pointsConfig: PointsConfig,
    periodId?: string | null,
    sessionId?: string | null,
    shouldStart?: boolean,
    includeLeaders?: boolean
  ) => {
    const now = Date.now();
    const resolvedSessionId = (sessionId && sessionId !== 'active') ? sessionId : (activeSessionId || undefined);
    
    const newExercise: Exercise = {
      id: crypto.randomUUID(),
      name,
      icon,
      date: now,
      teams: teams.map(t => ({ ...t, playerIds: t.playerIds || [], score: 0 })),
      sortByScore,
      showTimer,
      defaultTimerMinutes,
      defaultTimerSeconds,
      jokerPlayerIds,
      pointsConfig,
      createdAt: now,
      updatedAt: now,
      periodId: periodId || null,
      sessionId: resolvedSessionId,
      includeLeaders
    };
    
    const nextActiveExerciseId = shouldStart !== false ? newExercise.id : previousActiveExerciseId;

    setData(prev => {
      const updatedExercises = [newExercise, ...prev.exercises];
      const updatedSessions = (linkToMomentId && activeSessionId) 
        ? prev.sessions.map(s => s.id === activeSessionId 
            ? { ...s, moments: s.moments.map(m => m.id === linkToMomentId ? { ...m, exerciseId: newExercise.id } : m), updatedAt: Date.now() } 
            : s)
        : prev.sessions;

      const updated = {
        ...prev,
        exercises: updatedExercises,
        activeLineupId: activeLineupId,
        activeExerciseId: nextActiveExerciseId,
        sessions: updatedSessions
      };

      try {
        setPrefixedItem('football_exercises', JSON.stringify(updatedExercises), user);
        setPrefixedItem('football_sessions', JSON.stringify(updatedSessions), user);
        if (nextActiveExerciseId) {
          setPrefixedItem('active_exercise_id', nextActiveExerciseId, user);
          sessionStorage.setItem('coach_active_exercise_id', nextActiveExerciseId);
        }
        setPrefixedItem('data', JSON.stringify(updated), user);
      } catch (e) {}

      return updated;
    });
    setSessionActionCount(prev => prev + 1);
    
    setLinkToMomentId(null);
    setPrefilledName(null);
    setPreviousActiveExerciseId(undefined);

    pushDirtySegments(true, {
      exercises: [newExercise, ...exercises],
      activeExerciseId: nextActiveExerciseId,
      sessions: (linkToMomentId && activeSessionId) 
        ? sessions.map(s => s.id === activeSessionId 
            ? { ...s, moments: s.moments.map(m => m.id === linkToMomentId ? { ...m, exerciseId: newExercise.id } : m), updatedAt: Date.now() } 
            : s)
        : sessions
    }).catch(err => console.warn('App: Immediate push on start exercise:', err));

    if (shouldStart !== false) {
      handleSelectExercise(newExercise.id);
      setEditReturnView(null);
    } else if (editReturnView) {
      setView(editReturnView);
      setEditReturnView(null);
    } else if (resolvedSessionId) {
      setActiveSessionId(resolvedSessionId);
      setView('training');
    } else {
      setActiveSessionId(null);
      setView('training');
    }
  };

  const handleSaveEditedExercise = (
    name: string, 
    icon: string, 
    teams: Omit<Team, 'score'>[], 
    sortByScore: boolean, 
    showTimer: boolean, 
    defaultTimerMinutes: number, 
    defaultTimerSeconds: number, 
    jokerPlayerIds: string[], 
    pointsConfig: PointsConfig,
    periodId?: string | null,
    sessionId?: string | null,
    _shouldStart?: boolean,
    includeLeaders?: boolean
  ) => {
    if (!activeExerciseId) return;
    
    setData(prev => {
      const nextActiveId = previousActiveExerciseId !== undefined ? previousActiveExerciseId : prev.activeExerciseId;
      const updatedExercises = prev.exercises.map(e => {
        if (e.id !== prev.activeExerciseId) return e;
        
        const updatedTeams = teams.map(t => {
          const existingTeam = e.teams.find(et => et.id === t.id);
          return {
            ...t,
            playerIds: t.playerIds || [],
            score: existingTeam ? existingTeam.score : 0
          };
        });

        return {
          ...e,
          name,
          icon,
          teams: updatedTeams,
          sortByScore,
          showTimer,
          defaultTimerMinutes,
          defaultTimerSeconds,
          jokerPlayerIds,
          pointsConfig,
          updatedAt: Date.now(),
          periodId: periodId || e.periodId,
          sessionId: sessionId || (activeSessionId || e.sessionId),
          includeLeaders
        };
      });

      const updatedSessions = linkToMomentId && activeSessionId 
        ? prev.sessions.map(s => s.id === activeSessionId 
            ? { ...s, moments: s.moments.map(m => m.id === linkToMomentId ? { ...m, exerciseId: (prev.activeExerciseId || '') } : m), updatedAt: Date.now() } 
            : s)
        : prev.sessions;

      const updated = {
        ...prev,
        activeExerciseId: nextActiveId,
        exercises: updatedExercises,
        sessions: updatedSessions
      };

      try {
        setPrefixedItem('football_exercises', JSON.stringify(updatedExercises), user);
        setPrefixedItem('football_sessions', JSON.stringify(updatedSessions), user);
        if (nextActiveId) {
          setPrefixedItem('active_exercise_id', nextActiveId, user);
          sessionStorage.setItem('coach_active_exercise_id', nextActiveId);
        }
        setPrefixedItem('data', JSON.stringify(updated), user);
      } catch (e) {}

      return updated;
    });
    setSessionActionCount(prev => prev + 1);
    setIsEditingActiveExercise(false);

    pushDirtySegments(true).catch(err => console.warn('App: Immediate push on save edited exercise:', err));
    
    // Determine where to go back
    const isEditingViewedExercise = activeExerciseId === (exercises.find(e => e.id === activeExerciseId)?.id);

    if (editReturnView) {
      setView(editReturnView);
      setEditReturnView(null);
    } else if (isEditingViewedExercise) {
      setView('exercise');
    } else if (linkToMomentId || activeSessionId) {
      setView('training');
    } else {
      setView('exercise');
    }

    // Clean up common setup states
    setLinkToMomentId(null);
    setPrefilledName(null);
    setPreviousActiveExerciseId(undefined);
  };

  const updateTeamColor = (teamId: string, color: string) => {
    if (!activeExerciseId) return;
    setData(prev => ({
      ...prev,
      exercises: prev.exercises.map(e => {
        if (e.id !== activeExerciseId) return e;
        return {
          ...e,
          updatedAt: Date.now(),
          teams: e.teams.map(t => 
            t.id === teamId ? { ...t, color } : t
          ),
        };
      })
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const updateScore = (teamId: string, delta: number) => {
    if (!activeExerciseId || activeExercise?.isFinished) return;
    setData(prev => ({
      ...prev,
      exercises: prev.exercises.map(e => {
        if (e.id !== activeExerciseId) return e;
        return {
          ...e,
          updatedAt: Date.now(),
          teams: e.teams.map(t => 
            t.id === teamId ? { ...t, score: Math.max(0, t.score + delta) } : t
          ),
        };
      })
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const resetScores = () => {
    if (!activeExerciseId) return;
    setData(prev => ({
      ...prev,
      exercises: prev.exercises.map(e => {
        if (e.id !== activeExerciseId) return e;
        return {
          ...e,
          updatedAt: Date.now(),
          teams: e.teams.map(t => ({ ...t, score: 0 })),
        };
      })
    }));
    setSessionActionCount(prev => prev + 1);
    setShowResetConfirm(false);
  };

  const deleteExercise = (id: string) => {
    setData(prev => ({
      ...prev,
      exercises: prev.exercises.filter(e => e.id !== id),
      activeExerciseId: prev.activeExerciseId === id ? null : prev.activeExerciseId
    }));
    setSessionActionCount(prev => prev + 1);
    if (activeExerciseId === id) {
      setView('training');
    }
  };

  const updateLineup = (newLineup: Lineup) => {
    setData(prev => {
      const exists = prev.lineups.some(l => l.id === newLineup.id);
      const newLineups = exists
        ? prev.lineups.map(l => l.id === newLineup.id ? newLineup : l)
        : [newLineup, ...prev.lineups];
      try {
        setPrefixedItem('football_lineups', JSON.stringify(newLineups), user);
        setPrefixedItem('active_lineup_id', newLineup.id, user);
      } catch (e) {}
      return {
        ...prev,
        lineups: newLineups,
        activeLineupId: newLineup.id
      };
    });
    setSessionActionCount(prev => prev + 1);
  };

  const handleSaveLineup = (newLineup: Lineup) => {
    setData(prev => {
      const exists = prev.lineups.find(l => l.id === newLineup.id);
      const newLineups = exists 
        ? prev.lineups.map(l => l.id === newLineup.id ? newLineup : l)
        : [newLineup, ...prev.lineups];
      
      try {
        setPrefixedItem('football_lineups', JSON.stringify(newLineups), user);
        setPrefixedItem('active_lineup_id', newLineup.id, user);
      } catch (e) {}
      return {
        ...prev,
        lineups: newLineups,
        activeLineupId: newLineup.id
      };
    });
    setSessionActionCount(prev => prev + 1);
  };

  const handleDeleteLineup = (id: string) => {
    setData(prev => {
      const newLineups = prev.lineups.filter(l => l.id !== id);
      const nextActiveId = prev.activeLineupId === id ? (newLineups[0]?.id || null) : prev.activeLineupId;
      try {
        setPrefixedItem('football_lineups', JSON.stringify(newLineups), user);
        setPrefixedItem('active_lineup_id', nextActiveId || '', user);
      } catch (e) {}
      return {
        ...prev,
        lineups: newLineups,
        activeLineupId: nextActiveId
      };
    });
    setSessionActionCount(prev => prev + 1);
  };

  const handleCopyLineup = (id: string) => {
    setData(prev => {
      const source = prev.lineups.find(l => l.id === id);
      if (!source) return prev;
      const copied: Lineup = {
        ...source,
        id: crypto.randomUUID(),
        matchTitle: `${source.matchTitle} (kopia)`,
        date: Date.now(),
        sessionId: undefined, // Frikoppla från ursprungsmatchen
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      const newLineups = [copied, ...prev.lineups];
      try {
        setPrefixedItem('football_lineups', JSON.stringify(newLineups), user);
        setPrefixedItem('active_lineup_id', copied.id, user);
      } catch (e) {}
      return {
        ...prev,
        lineups: newLineups,
        activeLineupId: copied.id
      };
    });
    setSessionActionCount(prev => prev + 1);
  };

  const onNewSession = () => {
    let endTime = trainingSettings?.defaultEndTime;
    
    if (!endTime && trainingSettings?.defaultStartTime && trainingSettings?.defaultDuration) {
      const [h, m] = trainingSettings.defaultStartTime.split(':').map(Number);
      const date = new Date();
      date.setHours(h, m, 0, 0);
      date.setMinutes(date.getMinutes() + trainingSettings.defaultDuration);
      endTime = date.toLocaleTimeString('sv-SE', { hour: '2-digit', minute: '2-digit' });
    }

    const newSession: TrainingSession = {
      id: crypto.randomUUID(),
      title: '',
      date: Date.now(),
      startTime: trainingSettings?.defaultStartTime || '18:00',
      endTime: endTime,
      hideContentForPlayers: trainingSettings?.defaultHideContentForPlayers || false,
      moments: [],
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    let updatedSessionsList: TrainingSession[] = [];
    setData(prev => {
      const updated = {
        ...prev,
        sessions: [newSession, ...(prev.sessions || [])]
      };
      updatedSessionsList = updated.sessions;
      latestDataRef.current = updated;
      try {
        setPrefixedItem('football_sessions', JSON.stringify(updated.sessions), user);
        setPrefixedItem('data', JSON.stringify(updated), user);
      } catch (e) {}
      return updated;
    });
    setActiveSessionId(newSession.id);
    setSessionActionCount(prev => prev + 1);
    pushDirtySegments(true, { sessions: updatedSessionsList }).catch(err => console.warn('App: Instant push on new session:', err));
  };

  const onAddSessionsBatch = (newSessions: TrainingSession[]) => {
    let updatedSessionsList: TrainingSession[] = [];
    setData(prev => {
      const updatedSessions = [...newSessions, ...(prev.sessions || [])];
      updatedSessionsList = updatedSessions;
      const updated = {
        ...prev,
        sessions: updatedSessions
      };
      latestDataRef.current = updated;
      try {
        setPrefixedItem('football_sessions', JSON.stringify(updatedSessions), user);
        setPrefixedItem('data', JSON.stringify(updated), user);
      } catch (e) {}
      return updated;
    });
    setSessionActionCount(prev => prev + 1);
    pushDirtySegments(true, { sessions: updatedSessionsList }).catch(err => console.warn('App: Instant push on batch sessions:', err));
  };

  const onUpdateSession = (updatedSession: TrainingSession, instantPush = false) => {
    let updatedSessionsList: TrainingSession[] = [];
    setData(prev => {
      const updatedSessions = prev.sessions.map(s => s.id === updatedSession.id ? updatedSession : s);
      updatedSessionsList = updatedSessions;
      const updated = {
        ...prev,
        sessions: updatedSessions
      };
      latestDataRef.current = updated;
      try {
        setPrefixedItem('football_sessions', JSON.stringify(updatedSessions), user);
        setPrefixedItem('data', JSON.stringify(updated), user);
      } catch (e) {}
      return updated;
    });
    setSessionActionCount(prev => prev + 1);
    if (instantPush) {
      pushDirtySegments(true, { sessions: updatedSessionsList }).catch(err => console.warn('App: Instant push on update session:', err));
    }
  };

  const addBankExercise = (exercise: Omit<BankExercise, 'id' | 'createdAt'>) => {
    const newEx: BankExercise = {
      ...exercise,
      id: 'bank_' + Math.random().toString(36).substring(7),
      createdAt: Date.now()
    };
    setData(prev => ({
      ...prev,
      exerciseBank: [newEx, ...(prev.exerciseBank || [])]
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const updateBankExercise = (id: string, updates: Partial<BankExercise>) => {
    setData(prev => ({
      ...prev,
      exerciseBank: (prev.exerciseBank || []).map(ex => ex.id === id ? { ...ex, ...updates } : ex)
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const removeBankExercise = (id: string) => {
    setData(prev => ({
      ...prev,
      exerciseBank: (prev.exerciseBank || []).filter(ex => ex.id !== id)
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const addBankCategory = (category: string) => {
    const trimmed = category.trim();
    if (!trimmed) return;
    setData(prev => {
      const existing = prev.exerciseBankCategories || [];
      if (existing.some(c => c.toLowerCase() === trimmed.toLowerCase())) return prev;
      return {
        ...prev,
        exerciseBankCategories: [...existing, trimmed]
      };
    });
    setSessionActionCount(prev => prev + 1);
  };

  const removeBankCategory = (category: string) => {
    setData(prev => ({
      ...prev,
      exerciseBankCategories: (prev.exerciseBankCategories || []).filter(c => c !== category)
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const saveMomentToBank = (moment: SessionMoment) => {
    const bankId = 'bank_' + Math.random().toString(36).substring(7);
    const images: string[] = [];
    if (moment.imageUrls && Array.isArray(moment.imageUrls)) {
      moment.imageUrls.forEach(u => {
        if (typeof u === 'string' && u.trim() && !images.includes(u.trim())) images.push(u.trim());
      });
    }
    if (typeof moment.imageUrl === 'string' && moment.imageUrl.trim() && !images.includes(moment.imageUrl.trim())) {
      images.unshift(moment.imageUrl.trim());
    }
    if (typeof (moment as any).image === 'string' && (moment as any).image.trim() && !images.includes((moment as any).image.trim())) {
      images.push((moment as any).image.trim());
    }
    if (typeof (moment as any).photoUrl === 'string' && (moment as any).photoUrl.trim() && !images.includes((moment as any).photoUrl.trim())) {
      images.push((moment as any).photoUrl.trim());
    }
    if (typeof (moment as any).mediaUrl === 'string' && (moment as any).mediaUrl.trim() && !images.includes((moment as any).mediaUrl.trim())) {
      images.push((moment as any).mediaUrl.trim());
    }
    const primaryImg = images[0] || undefined;
    const newEx: BankExercise = {
      id: bankId,
      name: moment.name || 'Namnlös övning',
      duration: moment.duration || 15,
      description: moment.description,
      imageUrl: primaryImg,
      imageUrls: images.length > 0 ? images : undefined,
      externalLink: moment.externalLink,
      category: 'Annat',
      categories: ['Annat'],
      createdAt: Date.now(),
      tacticalBoards: moment.tacticalBoards ? JSON.parse(JSON.stringify(moment.tacticalBoards)) : undefined
    };
    setData(prev => ({
      ...prev,
      exerciseBank: [newEx, ...(prev.exerciseBank || [])]
    }));
    setSessionActionCount(prev => prev + 1);
    return bankId;
  };

  const onDeleteSession = (id: string) => {
    const isCoachOrAdmin = user ? (isRootAdmin || userRoles.includes('admin') || userRoles.includes('coach')) : true;
    if (!isCoachOrAdmin) return;
    let updatedSessionsList: TrainingSession[] = [];
    let updatedDeletedList: TrainingSession[] = [];
    setData(prev => {
      const sessionToDelete = prev.sessions.find(s => s.id === id);
      const updatedSessions = prev.sessions.filter(s => s.id !== id);
      const updatedDeleted = sessionToDelete 
        ? [sessionToDelete, ...(prev.deletedSessions || [])]
        : (prev.deletedSessions || []);
      
      updatedSessionsList = updatedSessions;
      updatedDeletedList = updatedDeleted;
      const updated = {
        ...prev,
        sessions: updatedSessions,
        deletedSessions: updatedDeleted
      };
      latestDataRef.current = updated;
      try {
        setPrefixedItem('football_sessions', JSON.stringify(updatedSessions), user);
        setPrefixedItem('football_deleted_sessions', JSON.stringify(updatedDeleted), user);
        setPrefixedItem('data', JSON.stringify(updated), user);
      } catch (e) {}
      return updated;
    });
    setSessionActionCount(prev => prev + 1);
    pushDirtySegments(true, { sessions: updatedSessionsList, deletedSessions: updatedDeletedList }).catch(err => console.warn('App: Instant push on delete session:', err));
  };

  const onRestoreSession = (id: string) => {
    let updatedSessionsList: TrainingSession[] = [];
    let updatedDeletedList: TrainingSession[] = [];
    setData(prev => {
      const restoredSession = (prev.deletedSessions || []).find(s => s.id === id);
      const updatedDeleted = (prev.deletedSessions || []).filter(s => s.id !== id);
      const updatedSessions = restoredSession
        ? [restoredSession, ...prev.sessions]
        : prev.sessions;
      
      updatedSessionsList = updatedSessions;
      updatedDeletedList = updatedDeleted;
      const updated = {
        ...prev,
        sessions: updatedSessions,
        deletedSessions: updatedDeleted
      };
      latestDataRef.current = updated;
      try {
        setPrefixedItem('football_sessions', JSON.stringify(updatedSessions), user);
        setPrefixedItem('football_deleted_sessions', JSON.stringify(updatedDeleted), user);
        setPrefixedItem('data', JSON.stringify(updated), user);
      } catch (e) {}
      return updated;
    });
    setSessionActionCount(prev => prev + 1);
    pushDirtySegments(true, { sessions: updatedSessionsList, deletedSessions: updatedDeletedList }).catch(err => console.warn('App: Instant push on restore session:', err));
  };

  const onDeleteSessionPermanent = (ids: string | string[]) => {
    const isCoachOrAdmin = user ? (isRootAdmin || userRoles.includes('admin') || userRoles.includes('coach')) : true;
    if (!isCoachOrAdmin) return;
    const idArray = Array.isArray(ids) ? ids : [ids];
    let updatedDeletedList: TrainingSession[] = [];
    setData(prev => {
      const updatedDeleted = (prev.deletedSessions || []).filter(s => !idArray.includes(s.id));
      updatedDeletedList = updatedDeleted;
      const updated = {
        ...prev,
        deletedSessions: updatedDeleted
      };
      latestDataRef.current = updated;
      try {
        setPrefixedItem('football_deleted_sessions', JSON.stringify(updatedDeleted), user);
        setPrefixedItem('data', JSON.stringify(updated), user);
      } catch (e) {}
      return updated;
    });
    setSessionActionCount(prev => prev + 1);
    pushDirtySegments(true, { deletedSessions: updatedDeletedList }).catch(err => console.warn('App: Instant push on permanent delete:', err));
  };

  const handleCopySession = (id: string) => {
    setData(prev => {
      const source = prev.sessions.find(s => s.id === id);
      if (!source) return prev;

      const newExercises: Exercise[] = [];
      const newMoments = source.moments.map(m => {
        if (m.exerciseId) {
          const sourceExercise = prev.exercises.find(e => e.id === m.exerciseId);
          if (sourceExercise) {
            const newExId = crypto.randomUUID();
            const newEx: Exercise = {
              ...sourceExercise,
              id: newExId,
              name: sourceExercise.name,
              date: Date.now(),
              isFinished: false,
              sessionId: source.id, // Will be updated to newSession.id later if needed
              teams: sourceExercise.teams.map(t => ({ ...t, id: crypto.randomUUID(), score: 0, playerIds: [] })),
              jokerPlayerIds: [],
              createdAt: Date.now(),
              updatedAt: Date.now(),
              periodId: currentPeriodId // Assign to current active period
            };
            newExercises.push(newEx);
            return { ...m, id: crypto.randomUUID(), exerciseId: newExId };
          }
        }
        return { ...m, id: crypto.randomUUID() };
      });

      const newSession: TrainingSession = {
        ...source,
        id: crypto.randomUUID(),
        title: source.title ? `${source.title} (kopia)` : 'Träning (kopia)',
        date: Date.now(),
        isCompleted: false, // Always start as planned
        moments: newMoments,
        createdAt: Date.now(),
        updatedAt: Date.now()
      };

      // Ensure copied exercises refer to the NEW session ID
      const finalizedExercises = newExercises.map(e => ({ ...e, sessionId: newSession.id }));

      return {
        ...prev,
        sessions: [newSession, ...prev.sessions],
        exercises: [...finalizedExercises, ...prev.exercises]
      };
    });
    setSessionActionCount(prev => prev + 1);
  };

  const handleReorderLineups = (reordered: Lineup[]) => {
    setData(prev => ({ ...prev, lineups: reordered }));
    setSessionActionCount(prev => prev + 1);
  };

  const handleRankClick = () => {
    if (!activeExerciseId) return;
    setData(prev => ({
      ...prev,
      exercises: prev.exercises.map(e => {
        if (e.id !== activeExerciseId) return e;
        return {
          ...e,
          updatedAt: Date.now(),
          teams: [...e.teams].sort((a, b) => b.score - a.score)
        };
      })
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const handleUpdateTeamUrl = (url: string) => {
    setData(prev => ({ ...prev, teamUrl: url }));
    setSessionActionCount(prev => prev + 1);
  };

  const handleUpdateAdminUrl = (url: string) => {
    setData(prev => ({ ...prev, adminUrl: url }));
    setSessionActionCount(prev => prev + 1);
  };

  const handleUpdateSeriesUrl = (url: string) => {
    setData(prev => ({ ...prev, seriesUrl: url }));
    setSessionActionCount(prev => prev + 1);
  };

  const updateActiveExerciseDefaultTimer = (minutes: number, seconds: number) => {
    if (!activeExerciseId) return;
    setData(prev => ({
      ...prev,
      exercises: prev.exercises.map(e => {
        if (e.id !== activeExerciseId) return e;
        return {
          ...e,
          defaultTimerMinutes: minutes,
          defaultTimerSeconds: seconds,
          updatedAt: Date.now(),
        };
      })
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const toggleTimerVisibility = () => {
    if (!activeExerciseId) return;
    setData(prev => ({
      ...prev,
      exercises: prev.exercises.map(e => {
        if (e.id !== activeExerciseId) return e;
        return {
          ...e,
          showTimer: !e.showTimer,
          updatedAt: Date.now(),
        };
      })
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const finishExercise = () => {
    if (!activeExerciseId) return;
    
    setData(prev => ({
      ...prev,
      exercises: prev.exercises.map(e => {
        if (e.id !== activeExerciseId) return e;
        return {
          ...e,
          isFinished: true,
          finishedAt: Date.now(),
          updatedAt: Date.now(),
          periodId: finishTargetPeriodId || undefined
        };
      }),
      activeExerciseId: null
    }));
    setSessionActionCount(prev => prev + 1);
    setShowFinishConfirm(false);
    setView('training');
  };

  const unlockExercise = () => {
    if (!activeExerciseId) return;
    setData(prev => ({
      ...prev,
      exercises: prev.exercises.map(e => {
        if (e.id !== activeExerciseId) return e;
        return {
          ...e,
          isFinished: false,
          finishedAt: undefined,
          updatedAt: Date.now(),
        };
      })
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const handleClosePeriod = (name: string, standings: PeriodStandings[]) => {
    const now = Date.now();
    
    setData(prev => ({
      ...prev,
      periods: prev.periods.map(p => {
        if (p.id === currentPeriodId) {
          return {
            ...p,
            name: name || p.name,
            endDate: now,
            isActive: false,
            standings
          };
        }
        return p;
      }),
      currentPeriodId: null
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const handleStartNewPeriod = () => {
    // This is now handled by a more specific function
  };

  const createNewPeriod = (name: string) => {
    const now = Date.now();
    const newId = crypto.randomUUID();
    const newPeriod: Period = {
      id: newId,
      name,
      startDate: now,
      standings: [],
      isActive: true
    };

    setData(prev => {
      const updatedPeriods = prev.periods.map(p => ({ ...p, isActive: false }));
      return {
        ...prev,
        periods: [newPeriod, ...updatedPeriods],
        currentPeriodId: newId
      };
    });
    setSessionActionCount(prev => prev + 1);
  };

  const switchActivePeriod = (id: string) => {
    setData(prev => ({
      ...prev,
      periods: prev.periods.map(p => ({
        ...p,
        isActive: p.id === id
      })),
      currentPeriodId: id
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const renamePeriod = (id: string, newName: string) => {
    setData(prev => ({
      ...prev,
      periods: prev.periods.map(p => p.id === id ? { ...p, name: newName } : p)
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const updatePeriod = (id: string, updates: Partial<Period>) => {
    setData(prev => ({
      ...prev,
      periods: prev.periods.map(p => p.id === id ? { ...p, ...updates } : p)
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const handleDeletePeriod = (id: string) => {
    setData(prev => ({
      ...prev,
      periods: prev.periods.filter(p => p.id !== id),
      exercises: prev.exercises.map(e => {
        if (e.periodId === id) {
          return { ...e, periodId: undefined };
        }
        return e;
      })
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const movePlayer = (exerciseId: string, playerId: string, targetTeamId: string) => {
    setData(prev => ({
      ...prev,
      exercises: prev.exercises.map(e => {
        if (e.id !== exerciseId) return e;
        
        // Remove player from all teams and joker list first
        const updatedTeams = e.teams.map(t => ({
          ...t,
          playerIds: (t.playerIds || []).filter(id => id !== playerId)
        }));
        const updatedJokerIds = (e.jokerPlayerIds || []).filter(id => id !== playerId);
        
        // If target is "joker", add to joker list
        if (targetTeamId === 'joker') {
          return {
            ...e,
            teams: updatedTeams,
            jokerPlayerIds: [...updatedJokerIds, playerId],
            updatedAt: Date.now()
          };
        }

        // If target is "none", just keep removed from everything (moves to unassigned pool)
        if (targetTeamId === 'none') {
          return {
            ...e,
            teams: updatedTeams,
            jokerPlayerIds: updatedJokerIds,
            updatedAt: Date.now()
          };
        }
        
        // Add to target team
        return {
          ...e,
          teams: updatedTeams.map(t => 
            t.id === targetTeamId ? { ...t, playerIds: [...t.playerIds, playerId] } : t
          ),
          jokerPlayerIds: updatedJokerIds,
          updatedAt: Date.now()
        };
      })
    }));
    setSessionActionCount(prev => prev + 1);
  };

  const copyTeams = (sourceExerciseId: string, targetExerciseId: string) => {
    const LOCAL_VEST_COLORS = [
      '#1E3A8A', // Navy (Tröjfärg)
      '#84CC16', // Lime
      '#0EA5E9', // Sky
      '#F97316', // Orange
      '#71717A', // Zinc
    ];

    setData(prev => {
      const sourceEx = prev.exercises.find(e => e.id === sourceExerciseId);
      if (!sourceEx) return prev;
      return {
        ...prev,
        exercises: prev.exercises.map(e => {
          if (e.id !== targetExerciseId) return e;

          const copiedTeams = e.teams.map((t, idx) => {
            const sourceTeam = sourceEx.teams[idx];
            return {
              ...t,
              playerIds: sourceTeam ? [...(sourceTeam.playerIds || [])] : []
            };
          });

          const finalTeams = [...copiedTeams];
          if (sourceEx.teams.length > e.teams.length) {
            const extraTeams = sourceEx.teams.slice(e.teams.length).map((st, idx) => ({
              id: crypto.randomUUID(),
              name: `Lag ${e.teams.length + idx + 1}`,
              color: LOCAL_VEST_COLORS[(e.teams.length + idx) % LOCAL_VEST_COLORS.length] || '#71717A',
              score: 0,
              playerIds: [...(st.playerIds || [])]
            }));
            finalTeams.push(...extraTeams);
          }

          return {
            ...e,
            teams: finalTeams,
            jokerPlayerIds: sourceEx.jokerPlayerIds ? [...sourceEx.jokerPlayerIds] : [],
            updatedAt: Date.now()
          };
        })
      };
    });
    setSessionActionCount(prev => prev + 1);
  };

  const sortedScores = activeExercise ? Array.from(new Set(activeExercise.teams.map(t => t.score))).sort((a: number, b: number) => b - a) : [];

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const handleLogin = async () => {
    try {
      await signInWithGoogle();
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Logout failed", error);
    }
  };

  const handleManualPush = async () => {
    if (!user || isSyncingRef.current) return;
    setSyncingStatus(true);

    try {
      await pushDirtySegments();
      console.log("App: Manual push completed successfully");
    } catch (error: any) {
      console.error("App: Manual push failed", error);
      if (isQuotaError(error)) {
        setIsQuotaExceeded(true);
      } else {
        setSyncError(error?.message || "Synkronisering misslyckades");
      }
      handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}/data/*`);
    } finally {
      setSyncingStatus(false);
    }
  };

  const handleSwitchAccount = async () => {
    try {
      // Force account selection
      await signInWithGoogle(true);
    } catch (error) {
      console.error("Switch account failed", error);
    }
  };

  const clearSharedView = () => {
    setSharedLeaderboardId(null);
    const url = new URL(window.location.href);
    url.searchParams.delete('share');
    window.history.pushState({}, '', url);
    setView('training');
  };

  const handleUpdateSquad = (newSquad: SquadPlayer[]) => {
    const cleanSquad = deduplicateSquad(newSquad);
    setData(prev => {
      if (JSON.stringify(prev.squad) === JSON.stringify(cleanSquad)) {
        return prev;
      }
      return { 
        ...prev, 
        squad: cleanSquad
      };
    });
    setSessionActionCount(prev => prev + 1);

    if (userProfile.activeClubId && userProfile.activeTeamId) {
      syncSquadToClubMembers(cleanSquad, userProfile.activeClubId, userProfile.activeTeamId)
        .catch(err => console.error("Error syncing squad to club members:", err));
    }
  };

  const onUpdateSettings = (settings: TrainingSettings) => {
    setData(prev => ({ ...prev, trainingSettings: settings }));
    setSessionActionCount(prev => prev + 1);
  };

  const isCoachOrAdmin = user ? (isRootAdmin || userRoles.includes('admin') || userRoles.includes('coach')) : true;
  const activeLineup = lineups.find(l => l.id === activeLineupId) || (lineups.length > 0 ? lineups[0] : null);
  const publishedLineups = lineups.filter(l => l.isPublishedToPlayers && !l.isArchived);
  const effectiveActiveLineup = isCoachOrAdmin ? activeLineup : (publishedLineups.find(l => l.id === activeLineupId) || publishedLineups[0] || null);
  const canViewLineup = isCoachOrAdmin || !!trainingSettings?.showLineupsToPlayers;

  useEffect(() => {
    if (!isCoachOrAdmin && view === 'clubadmin') {
      setView('training');
    }
  }, [isCoachOrAdmin, view]);

  if (isAuthReady && user && !isInitialSyncDone) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-zinc-50 dark:bg-zinc-950 p-8 text-center animate-pulse">
        <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 rounded-2xl flex items-center justify-center text-indigo-600 dark:text-indigo-400 mb-6">
          <Cloud size={32} />
        </div>
        <h2 className="text-xl font-black text-zinc-900 dark:text-white mb-2 tracking-tight">Synkroniserar...</h2>
        <p className="text-sm text-zinc-500 dark:text-zinc-400 font-medium">Hämtar information från molnet</p>
      </div>
    );
  }

  return (
    <div className={`fixed inset-0 flex flex-col bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 font-sans selection:bg-indigo-100 transition-colors duration-500 overflow-hidden ${view === 'exercise' || view === 'teampage' ? 'select-none' : ''}`}>
      {view !== 'lineup' && (
        <header className={`bg-white dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-800 z-30 transition-all duration-300 ease-in-out shrink-0 ${
          view === 'exercise' ? 'sticky top-0' : ''
        } ${
          view === 'exercise' && isTimerRunning 
            ? '-mt-14 sm:-mt-16 opacity-0 pointer-events-none overflow-hidden border-b-0' 
            : 'mt-0 opacity-100'
        }`}>
          <div className="max-w-4xl lg:max-w-5xl xl:max-w-6xl 2xl:max-w-7xl mx-auto px-4 h-14 sm:h-16 flex items-center justify-between">
            <div 
              className={`flex items-center gap-3 cursor-pointer group min-w-0 ${((view as any) === 'lineup') ? 'hover:opacity-70' : ''}`}
              onClick={() => { 
                if (sharedLeaderboardId) {
                  clearSharedView();
                } else if (view === 'setup' && isEditingActiveExercise) {
                  // If editing an exercise, go back to where we started editing
                  if (editReturnView) {
                    setView(editReturnView);
                    setEditReturnView(null);
                  } else if (activeExerciseId) {
                    handleSelectExercise(activeExerciseId);
                  } else {
                    setView('training');
                  }
                  setIsEditingActiveExercise(false);
                } else if (view === 'exercise' || view === 'setup') {
                  setView('training'); 
                  setData(prev => ({ ...prev, activeExerciseId: null }));
                  setSessionActionCount(prev => prev + 1);
                  setIsEditingActiveExercise(false);
                  try {
                    const url = new URL(window.location.href);
                    url.searchParams.delete('view');
                    url.searchParams.delete('ex');
                    window.history.replaceState({}, '', url.toString());
                  } catch (e) {}
                  // If we have an active session, let it stay active
                } else if (((view as any) === 'lineup')) {
                  // No action on header click for lineup view
                }
              }}
            >
              {(view === 'exercise' || view === 'setup') && (
                <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200 dark:shadow-none group-hover:scale-110 transition-transform shrink-0">
                  <ArrowLeft size={20} strokeWidth={3} />
                </div>
              )}
              {view !== 'exercise' && (
                <div className="flex flex-col min-w-0">
                  <span className="font-black text-xl tracking-tight dark:text-white truncate">
                    {(() => {
                      if (view === 'setup') return isEditingActiveExercise ? 'Redigera tävlingsmoment' : 'Skapa tävlingsmoment';
                      if (view === 'training') return 'Kalender';
                      if (view === 'squad') return 'Truppen';
                      if (view === 'leaderboard') return 'Poängliga';
                      if (view === 'profile') return 'Profil';
                      if (((view as any) === 'lineup')) return 'Laguppställning';
                      if (view === 'teampage') return 'Lagsidan';
                      if (view === 'clubadmin') return 'Administration';
                      if (sharedLeaderboardId) return 'Delad Poängliga';
                      return 'Kalender';
                    })()}
                  </span>

                  {(view === 'squad' || view === 'leaderboard' || view === 'teampage' || view === 'training' || view === 'clubadmin') && (
                    <span className="hidden sm:block text-[10px] font-black text-zinc-400 uppercase tracking-widest mt-[-2px]">
                      {view === 'squad' ? 'Hantera spelare & ledare' : view === 'leaderboard' ? 'Statistik & poäng' : view === 'training' ? 'Översikt & Planering' : view === 'clubadmin' ? 'Föreningar, lag, databas & kalender' : 'Webb & Kalender'}
                    </span>
                  )}
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              {(isSyncing || (user && sessionActionCount > 0 && view !== 'exercise')) && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all ${
                    isSyncing 
                      ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 border-indigo-100 dark:border-indigo-800 animate-pulse' 
                      : 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 border-amber-100 dark:border-amber-900/30'
                  }`}
                >
                  {isSyncing ? (
                    <>
                      <Cloud size={14} className="animate-bounce" />
                      <span className="text-[10px] font-black uppercase tracking-widest leading-none">Synkar</span>
                    </>
                  ) : (
                    <button 
                      onClick={handleManualPush}
                      className="flex items-center gap-2 cursor-pointer hover:opacity-80 active:scale-95 transition-all"
                      title="Spara ändringar till molnet nu"
                    >
                      <TimerIcon size={14} className="animate-spin-slow" />
                      <span className="text-[10px] font-black uppercase tracking-widest leading-none">Väntar...</span>
                      <div className="w-px h-3 bg-amber-200 dark:bg-amber-800 mx-1" />
                      <span className="text-[10px] font-black uppercase tracking-widest leading-none underline decoration-amber-400">Spara nu</span>
                    </button>
                  )}
                </motion.div>
              )}
              {!sharedLeaderboardId && (
                <>
                  {view === 'exercise' ? (
                    <button
                      type="button"
                      onClick={() => setIsQuickShakeModalOpen(true)}
                      className={`relative w-10 h-10 flex items-center justify-center rounded-xl transition-all border shadow-sm active:scale-95 cursor-pointer ${
                        hasTypedInSession
                          ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 hover:bg-amber-100 dark:hover:bg-amber-900/50 border-amber-300 dark:border-amber-700/60 animate-pulse'
                          : 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 border-emerald-200/80 dark:border-emerald-800/60'
                      }`}
                      title={hasTypedInSession ? "Varning: Text har skrivits. Klicka för att rensa skakminnet." : "Rensa skakminnet (iOS)"}
                    >
                      <VibrateOff size={19} />
                      {hasTypedInSession && (
                        <span className="absolute -top-1 -right-1 flex h-3 w-3">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500 border-2 border-white dark:border-zinc-900"></span>
                        </span>
                      )}
                    </button>
                  ) : (
                    user && isInitialSyncDone && (
                      <button
                        type="button"
                        onClick={pullLatestData}
                        disabled={isSyncing}
                        className="w-10 h-10 flex items-center justify-center rounded-xl bg-indigo-50 dark:bg-indigo-950/30 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-all border border-indigo-100 dark:border-indigo-900/30 disabled:opacity-50"
                        title="Hämta senaste data från molnet (Uppdatera)"
                      >
                        <RefreshCw size={18} className={`${isSyncing ? 'animate-spin' : ''}`} />
                      </button>
                    )
                  )}
                  {view === 'exercise' ? (
                    <button
                      type="button"
                      onClick={() => setShowTeamOverview(true)}
                      className="w-10 h-10 flex items-center justify-center rounded-xl bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-all border border-indigo-100 dark:border-indigo-900/30"
                      title="Visa lagöversikt"
                    >
                      <Users size={20} />
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={toggleTheme}
                      className="w-10 h-10 flex items-center justify-center rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-all cursor-pointer border border-zinc-200 dark:border-zinc-700"
                      title={theme === 'light' ? 'Mörkt läge' : 'Ljust läge'}
                    >
                      {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
                    </button>
                  )}

                  {/* Kalenderinställningar Cogwheel in top-right Nav */}
                  {view === 'training' && isCoachOrAdmin && (
                    <button
                      type="button"
                      onClick={() => setOpenTrainingSettings(true)}
                      className="w-10 h-10 flex items-center justify-center rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 hover:bg-zinc-205 dark:hover:bg-zinc-700 hover:text-indigo-650 dark:hover:text-indigo-400 transition-all cursor-pointer border border-zinc-200 dark:border-zinc-700"
                      title="Kalenderinställningar"
                    >
                      <Settings size={20} />
                    </button>
                  )}

                  {/* Admin Icon Button */}
                  {isAuthReady && view !== 'exercise' && user && isCoachOrAdmin && (
                    <button
                      type="button"
                      onClick={() => setView('clubadmin')}
                      className={`w-10 h-10 flex items-center justify-center rounded-xl transition-all border cursor-pointer ${
                        view === 'clubadmin'
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-md scale-105'
                          : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 hover:text-indigo-600 dark:hover:text-indigo-400 border-zinc-200 dark:border-zinc-700'
                      }`}
                      title="Administration (Föreningar, Lag, Spelare, Databas, PWA, Kalender)"
                    >
                      <ShieldCheck size={20} />
                    </button>
                  )}

                  {isAuthReady && view !== 'exercise' && (
                    user ? (
                      <button
                        onClick={() => setView('profile')}
                        className={`w-10 h-10 flex items-center justify-center rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${view === 'profile' ? 'border-indigo-600 dark:border-indigo-400 scale-110' : 'border-zinc-200 dark:border-zinc-700 hover:border-indigo-400'}`}
                        title={`Profil: ${userProfile.fullName || user.displayName || user.email}`}
                      >
                        {effectiveUserPhoto ? (
                          <img src={effectiveUserPhoto} alt={userProfile.fullName || user.displayName || ''} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="w-full h-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-bold text-xs uppercase">
                            {(userProfile.fullName || user.displayName || user.email || 'U').charAt(0)}
                          </div>
                        )}
                      </button>
                    ) : (
                      <button
                        onClick={handleLogin}
                        className="w-10 h-10 flex items-center justify-center rounded-xl bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-all border border-indigo-100 dark:border-indigo-900/30"
                        title="Logga in"
                      >
                        <LogIn size={20} />
                      </button>
                    )
                  )}
                </>
              )}
              {view === 'exercise' && activeExercise && (
                <>
                  <button
                    onClick={toggleTimerVisibility}
                    className={`p-2 rounded-lg transition-all ${activeExercise.showTimer ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30' : 'text-zinc-500 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'}`}
                    title={activeExercise.showTimer ? "Dölj timer" : "Visa timer"}
                  >
                    <TimerIcon size={20} />
                  </button>
                  {isCoachOrAdmin && (
                    <>
                      <button
                        onClick={() => {
                          setPreviousActiveExerciseId(activeExerciseId);
                          setEditReturnView('exercise');
                          setIsEditingActiveExercise(true);
                          setView('setup');
                        }}
                        className="p-2 text-zinc-500 dark:text-zinc-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition-all cursor-pointer"
                        title="Redigera tävlingsmoment"
                      >
                        <Edit2 size={20} />
                      </button>
                      <button
                        onClick={() => setShowResetConfirm(true)}
                        className="p-2 text-zinc-500 dark:text-zinc-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition-all cursor-pointer"
                        title="Nollställ poäng"
                        disabled={activeExercise.isFinished}
                      >
                        <RotateCcw size={20} />
                      </button>
                      {!activeExercise.isFinished && (
                        <button
                          onClick={() => {
                            setFinishTargetPeriodId(activeExercise.periodId || currentPeriodId);
                            setShowFinishConfirm(true);
                          }}
                          className="ml-2 bg-green-600 text-white px-4 py-2 rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-200 dark:shadow-none flex items-center gap-2 cursor-pointer"
                        >
                          <Check size={18} strokeWidth={3} />
                          <span className="hidden sm:inline">Avsluta</span>
                        </button>
                      )}
                      {activeExercise.isFinished && (
                        <button
                          onClick={unlockExercise}
                          className="p-2 text-zinc-500 dark:text-zinc-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition-all cursor-pointer"
                          title="Lås upp för redigering"
                        >
                          <Unlock size={20} />
                        </button>
                      )}
                    </>
                  )}
                </>
              )}
            </div>
          </div>
        </header>
      )}

      {isQuotaExceeded && (
        <div className="bg-amber-600 text-white px-4 py-3 text-center text-xs font-semibold leading-normal flex flex-wrap items-center justify-center gap-2 relative z-50 animate-fade-in print:hidden border-b border-amber-700 shadow-md">
          <AlertTriangle size={16} className="shrink-0 text-amber-200 animate-pulse" />
          <span>
            <strong>Obs:</strong> Molndatabasens dagliga gratiskvot i Firebase (50 000 anrop) har nåtts för idag. <strong>All din data, alla lag och konton är säkert sparade i Firebase</strong> och inte raderade! Kvoten nollställs automatiskt nästa dygn.
          </span>
          <div className="flex items-center gap-2 ml-1">
            <a
              href="https://console.firebase.google.com/project/tuned-life-pmvz5/firestore/databases/ai-studio-remixcoachassist-3ac8f9c7-729f-4797-87b6-4c498370756c/data?openUpgradeDialog=true"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 bg-white text-amber-900 hover:bg-amber-50 font-bold rounded text-[11px] uppercase tracking-wide transition-all shadow-sm"
            >
              Uppgradera i Firebase &rarr;
            </a>
            <button
              onClick={() => {
                setIsQuotaExceeded(false);
                setSessionActionCount(1);
              }}
              className="underline hover:no-underline font-medium cursor-pointer px-2 py-0.5 bg-black/20 hover:bg-black/30 rounded transition-all text-white text-[11px]"
            >
              Försök igen
            </button>
          </div>
        </div>
      )}

      {(isRootAdmin || userRoles.includes('admin') || userRoles.includes('coach')) && pendingRequestsCount > 0 && (
        <div className="bg-indigo-600 text-white px-4 py-2.5 text-center text-xs font-bold leading-normal flex items-center justify-center gap-2 relative z-50 animate-fade-in print:hidden border-b border-indigo-700 shadow-lg">
          <Bell size={16} className="shrink-0 animate-bounce" />
          <span>
            {pendingRequestsCount === 1 
              ? '1 ny medlemsansökan väntar på godkännande!'
              : `${pendingRequestsCount} nya medlemsansökningar väntar på godkännande!`}
          </span>
          <button
            onClick={() => setIsPendingRequestsModalOpen(true)}
            className="ml-2 px-3 py-1 bg-white text-indigo-700 hover:bg-indigo-50 font-black rounded-lg text-[11px] uppercase tracking-wider transition-all shadow-sm cursor-pointer"
          >
            Granska ansökningar
          </button>
        </div>
      )}

      <main className={`flex-1 flex flex-col min-h-0 w-full max-w-full overflow-x-hidden ${
        view === 'exercise' || view === 'teampage' || (view === 'lineup' && isLineupMaximized)
          ? 'overflow-hidden' 
          : view === 'lineup' 
          ? 'overflow-y-auto pb-28 sm:pb-24' 
          : 'overflow-y-auto pb-20 sm:pb-24'
      }`}>
        <AnimatePresence mode="wait">
          {view === 'training' && (
            sharedLeaderboardId ? (
              <motion.div
                key="training-promo"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="flex-1 flex flex-col items-center justify-center p-8 text-center"
              >
                <div className="w-20 h-20 bg-indigo-100 dark:bg-indigo-900/30 rounded-3xl flex items-center justify-center text-indigo-600 dark:text-indigo-400 mb-6">
                  <Calendar size={40} />
                </div>
                <h2 className="text-2xl font-black text-zinc-900 dark:text-white mb-4 tracking-tight">Planera din kalender</h2>
                <p className="text-zinc-500 dark:text-zinc-400 max-w-xs mb-8 font-medium leading-relaxed">
                  Här kan du planera i kalendern och skapa tävlingsmoment. Starta appen som ledare genom att gå till den här sidan.
                </p>
                <button
                  onClick={() => {
                    setSharedLeaderboardId(null);
                    const url = new URL(window.location.origin);
                    url.searchParams.set('view', 'squad');
                    window.history.pushState({}, '', url);
                    setView('squad');
                  }}
                  className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 dark:shadow-none flex items-center gap-2"
                >
                  <Rocket size={20} />
                  <span>Kom igång här</span>
                </button>
              </motion.div>
            ) : (
              <>
                <TrainingManager 
                  exercises={exercises} 
                  sessions={sessions}
                  deletedSessions={deletedSessions}
                  squad={squad}
                  activeClubId={userProfile.activeClubId}
                  activeTeamId={userProfile.activeTeamId}
                  activeClubInfo={activeClubInfo}
                  isCloudDataLoaded={hasPulledFromCloud}
                  activeTab={trainingTab}
                  onTabChange={setTrainingTab}
                  settings={trainingSettings}
                  onUpdateSettings={onUpdateSettings}
                  openSettings={openTrainingSettings}
                  onCloseSettings={() => setOpenTrainingSettings(false)}
                  exerciseBank={exerciseBank}
                  exerciseBankCategories={exerciseBankCategories}
                  onAddBankCategory={addBankCategory}
                  onRemoveBankCategory={removeBankCategory}
                  onAddBankExercise={addBankExercise}
                  onUpdateBankExercise={updateBankExercise}
                  onRemoveBankExercise={removeBankExercise}
                  user={user}
                  userRoles={userRoles}
                  calendarMonth={calendarMonth}
                  onCalendarMonthChange={handleCalendarMonthChange}
                  onSelectExercise={handleSelectExercise} 
                  onDeleteExercise={(id) => {
                    setData(prev => ({
                      ...prev,
                      exercises: prev.exercises.filter(e => e.id !== id)
                    }));
                    setSessionActionCount(prev => prev + 1);
                  }}
                  onCopyExercise={(id) => {
                    const ex = exercises.find(e => e.id === id);
                    if (ex) {
                      const newEx = {
                        ...ex,
                        id: Math.random().toString(36).substring(7),
                        name: `${ex.name} (kopia)`,
                        createdAt: Date.now(),
                        updatedAt: Date.now(),
                        isFinished: false
                      };
                      setData(prev => ({
                        ...prev,
                        exercises: [newEx, ...prev.exercises]
                      }));
                      setSessionActionCount(prev => prev + 1);
                    }
                  }}
                  onEditExercise={(id) => {
                    setPreviousActiveExerciseId(activeExerciseId);
                    setData(prev => ({ ...prev, activeExerciseId: id }));
                    setEditReturnView(activeExerciseId === id ? 'exercise' : 'training');
                    setIsEditingActiveExercise(true);
                    setView('setup');
                  }}
                  onReorderExercises={(reordered) => {
                    setData(prev => ({ ...prev, exercises: reordered }));
                    setSessionActionCount(prev => prev + 1);
                  }}
                  onNewExercise={() => {
                    setPreviousActiveExerciseId(activeExerciseId);
                    setEditReturnView('training');
                    setIsEditingActiveExercise(false);
                    setView('setup');
                  }}
                  onNewSession={onNewSession}
                  onAddSessionsBatch={onAddSessionsBatch}
                  onSelectSession={(id, initialTab) => {
                    setActiveSessionId(id);
                    setSessionEditorTab(initialTab || 'schema');
                  }}
                  onDeleteSession={onDeleteSession}
                  onRestoreSession={onRestoreSession}
                  onDeleteSessionPermanent={onDeleteSessionPermanent}
                  onCopySession={handleCopySession}
                  onUpdateSession={onUpdateSession}
                  onMovePlayer={movePlayer}
                  onCopyTeams={copyTeams}
                  onReorderSessions={(reordered) => {
                    setData(prev => ({ ...prev, sessions: reordered }));
                    setSessionActionCount(prev => prev + 1);
                  }}
                />
              </>
            )
          )}

          {view === 'setup' && (() => {
            const exerciseBeingEdited = isEditingActiveExercise ? exercises.find(e => e.id === activeExerciseId) : undefined;
            const effectiveSessionId = activeSessionId || exerciseBeingEdited?.sessionId;
            const currentSession = effectiveSessionId ? sessions.find(s => s.id === effectiveSessionId) : undefined;
            
            // Unique key ensures the component remounts and re-initializes its state
            const setupKey = isEditingActiveExercise 
              ? `edit-${activeExerciseId}` 
              : `new-${effectiveSessionId || 'general'}-${prefilledName || 'unnamed'}`;

            return (
              <GameSetup 
                key={setupKey} 
                onStartGame={isEditingActiveExercise ? handleSaveEditedExercise : handleStartExercise} 
                squad={squad} 
                guestPlayers={currentSession?.guestPlayers}
                sessionAttendance={currentSession?.attendance}
                activeSessionId={effectiveSessionId}
                sessions={sessions}
                exercises={exercises}
                currentPeriodId={currentPeriodId}
                onAddGuest={(name, position) => {
                  if (effectiveSessionId) {
                    const sessionToUpdate = sessions.find(s => s.id === effectiveSessionId);
                    if (sessionToUpdate) {
                      const newGuest = {
                        id: `guest_${Date.now()}_${Math.random().toString(36).substring(7)}`,
                        name: name.trim(),
                        position: position || undefined,
                      };
                      onUpdateSession({
                        ...sessionToUpdate,
                        guestPlayers: [...(sessionToUpdate.guestPlayers || []), newGuest],
                        attendance: [...(sessionToUpdate.attendance || []), newGuest.id],
                        updatedAt: Date.now()
                      });
                    }
                  }
                }}
                onAddSquadPlayerToAttendance={(playerId) => {
                  if (effectiveSessionId) {
                    const sessionToUpdate = sessions.find(s => s.id === effectiveSessionId);
                    if (sessionToUpdate) {
                      const currentAttendance = sessionToUpdate.attendance || [];
                      if (!currentAttendance.includes(playerId)) {
                        onUpdateSession({
                          ...sessionToUpdate,
                          attendance: [...currentAttendance, playerId],
                          updatedAt: Date.now()
                        });
                      }
                    }
                  }
                }}
                onRemovePlayerFromAttendance={(playerId) => {
                  if (effectiveSessionId) {
                    const sessionToUpdate = sessions.find(s => s.id === effectiveSessionId);
                    if (sessionToUpdate) {
                      const currentAttendance = sessionToUpdate.attendance || [];
                      const isGuest = playerId.startsWith('guest_');
                      onUpdateSession({
                        ...sessionToUpdate,
                        attendance: currentAttendance.filter(id => id !== playerId),
                        guestPlayers: isGuest ? (sessionToUpdate.guestPlayers || []).filter(p => p.id !== playerId) : sessionToUpdate.guestPlayers,
                        updatedAt: Date.now()
                      });
                    }
                  }
                }}
                initialGame={isEditingActiveExercise 
                  ? exerciseBeingEdited 
                  : (prefilledName ? { name: prefilledName, teams: [], icon: 'Dribbble' } as any : undefined)
                }
                onCancel={() => {
                  if (editReturnView) {
                    setView(editReturnView);
                    setEditReturnView(null);
                  } else if (previousActiveExerciseId) {
                    setView('exercise');
                  } else {
                    setView('training');
                  }
                  if (previousActiveExerciseId !== undefined) {
                    setData(prev => ({ ...prev, activeExerciseId: previousActiveExerciseId }));
                    setPreviousActiveExerciseId(undefined);
                  }
                  setIsEditingActiveExercise(false);
                  setPrefilledName(null);
                  setLinkToMomentId(null);
                }} 
              />
            );
          })()}

          {view === 'squad' && (
            sharedLeaderboardId ? (
              <motion.div
                key="squad-promo"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="flex-1 flex flex-col items-center justify-center p-8 text-center"
              >
                <div className="w-20 h-20 bg-indigo-100 dark:bg-indigo-900/30 rounded-3xl flex items-center justify-center text-indigo-600 dark:text-indigo-400 mb-6">
                  <Users size={40} />
                </div>
                <h2 className="text-2xl font-black text-zinc-900 dark:text-white mb-4 tracking-tight">Hantera din trupp</h2>
                <p className="text-zinc-500 dark:text-zinc-400 max-w-xs mb-8 font-medium leading-relaxed">
                  Här kan du lägga in din egen trupp om du själv vill använda appen. Gå till den här sidan för att komma igång.
                </p>
                <button
                  onClick={() => {
                    setSharedLeaderboardId(null);
                    const url = new URL(window.location.origin);
                    url.searchParams.set('view', 'squad');
                    window.history.pushState({}, '', url);
                    setView('squad');
                  }}
                  className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 dark:shadow-none flex items-center gap-2"
                >
                  <Rocket size={20} />
                  <span>Lägg in din egen trupp</span>
                </button>
              </motion.div>
            ) : (
              <SquadManager
                key={`squad-${userProfile.activeClubId || 'none'}-${userProfile.activeTeamId || 'none'}`}
                squad={squad}
                sessions={sessions}
                onUpdateSquad={handleUpdateSquad}
                activeClubId={userProfile.activeClubId}
                activeTeamId={userProfile.activeTeamId}
                isCoachOrAdmin={isCoachOrAdmin}
              />
            )
          )}

          {view === 'profile' && (
            <motion.div
              key="profile"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-4xl mx-auto p-4 sm:p-8"
            >
              {user ? (
                <div className="space-y-6">
                  {/* Top quick links for admin/clubs */}
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-800 p-6 rounded-3xl shadow-md">
                    <div>
                      <h2 className="text-xl font-extrabold text-zinc-900 dark:text-white tracking-tight">Konto & inställningar</h2>
                      <p className="text-sm text-zinc-500 mt-1 font-medium">Hantera ditt konto, anslutna föreningar och lag.</p>
                    </div>
                    <div className="flex flex-wrap gap-2.5">
                      <button
                        onClick={handleSwitchAccount}
                        className="inline-flex items-center gap-2 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 font-extrabold px-4 py-2.5 rounded-xl transition-all active:scale-95 cursor-pointer text-xs border border-zinc-200 dark:border-zinc-700"
                      >
                        <RotateCcw size={14} />
                        <span>Byt konto</span>
                      </button>
                      <button
                        onClick={handleLogout}
                        className="inline-flex items-center gap-2 bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-900/40 text-red-600 dark:text-red-400 font-extrabold px-4 py-2.5 rounded-xl transition-all active:scale-95 cursor-pointer text-xs"
                      >
                        <LogOut size={14} />
                        <span>Logga ut</span>
                      </button>
                    </div>
                  </div>

                  <ProfileAndSettings
                    userId={user.uid}
                    userEmail={user.email || ''}
                    isRootAdmin={isRootAdmin}
                    onProfileUpdated={handleProfileUpdated}
                    currentProfile={userProfile}
                    onOpenShakeModal={() => setIsShakeInfoModalOpen(true)}
                  />
                  
                  {/* Stats Grid */}
                  <div className="bg-white dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-800 p-6 rounded-3xl shadow-xl">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-4 border-b border-zinc-100 dark:border-zinc-800/60">
                      <div className="flex items-center gap-3 text-indigo-600 dark:text-indigo-400">
                        <LayoutDashboard size={20} />
                        <h3 className="font-black uppercase tracking-wider text-xs">Aktivitetsstatistik ({userProfile.activeClubId ? 'Aktivt lag' : 'Privat trupp'})</h3>
                      </div>
                      {(userRoles.length > 0 || isRootAdmin) && (
                        <div className="flex flex-wrap gap-1.5 items-center">
                          <span className="text-[10px] text-zinc-400 dark:text-zinc-500 font-extrabold uppercase tracking-wider">Mina roller:</span>
                          {isRootAdmin && (
                            <span className="text-[9px] font-black uppercase tracking-wider bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 px-2 py-0.5 rounded-md border border-red-100/40 dark:border-red-900/40 animate-pulse">
                              Root Admin
                            </span>
                          )}
                          {userRoles.map(role => (
                            <span key={role} className="text-[9px] font-black uppercase tracking-wider bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-md border border-indigo-100/40 dark:border-indigo-900/40">
                              {role === 'admin' ? 'Admin' : role === 'coach' ? 'Tränare' : role === 'player' ? 'Spelare' : 'Förälder'}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="bg-zinc-50 dark:bg-zinc-950 p-4 rounded-2xl border border-zinc-100 dark:border-zinc-800">
                        <span className="text-xs text-zinc-500 uppercase font-bold tracking-wider">Spelare</span>
                        <div className="text-2xl font-black text-zinc-900 dark:text-white mt-1">
                          {squad.filter(p => p.role !== 'leader').length}
                        </div>
                      </div>
                      <div className="bg-zinc-50 dark:bg-zinc-950 p-4 rounded-2xl border border-zinc-100 dark:border-zinc-800">
                        <span className="text-xs text-zinc-500 uppercase font-bold tracking-wider">Tränare/Ledare</span>
                        <div className="text-2xl font-black text-zinc-900 dark:text-white mt-1">
                          {squad.filter(p => p.role === 'leader').length}
                        </div>
                      </div>
                      <div className="bg-zinc-50 dark:bg-zinc-950 p-4 rounded-2xl border border-zinc-100 dark:border-zinc-800">
                        <span className="text-xs text-zinc-500 uppercase font-bold tracking-wider">Träningar</span>
                        <div className="text-2xl font-black text-zinc-900 dark:text-white mt-1">
                          {sessions.filter(s => getSessionCategory(s) === 'training').length}
                        </div>
                      </div>
                      <div className="bg-zinc-50 dark:bg-zinc-950 p-4 rounded-2xl border border-zinc-100 dark:border-zinc-800">
                        <span className="text-xs text-zinc-500 uppercase font-bold tracking-wider">Matcher</span>
                        <div className="text-2xl font-black text-zinc-900 dark:text-white mt-1">
                          {sessions.filter(s => getSessionCategory(s) === 'match').length}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-100 dark:border-zinc-800 shadow-xl p-8 text-center max-w-md mx-auto">
                  <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-950/30 rounded-2xl flex items-center justify-center text-indigo-600 dark:text-indigo-400 mx-auto mb-6">
                    <UserIcon size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-zinc-900 dark:text-white mb-2">Logga in för att spara din data</h3>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400 mb-6 font-medium leading-relaxed">
                    Spara dina spelare, kalendrar och poängligor säkert i molnet samt anslut till idrottsklubbar.
                  </p>
                  <button
                    onClick={handleLogin}
                    className="w-full inline-flex items-center justify-center gap-3 bg-indigo-600 text-white px-6 py-3.5 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 dark:shadow-none"
                  >
                    <LogIn size={20} />
                    <span>Logga in med Google</span>
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {view === 'clubadmin' && user && isCoachOrAdmin && (
            <motion.div
              key="clubadmin"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full max-w-6xl mx-auto px-1.5 sm:px-6 py-2 sm:py-6 min-w-0 overflow-x-hidden"
            >
              <ClubAdminDashboard
                userId={user.uid}
                userEmail={user.email || ''}
                isRootAdmin={isRootAdmin}
                isCoachOrAdmin={isCoachOrAdmin}
                userRoles={userRoles}
                onBack={() => setView('training')}
                teamUrl={teamUrl}
                onUpdateTeamUrl={handleUpdateTeamUrl}
                adminUrl={adminUrl}
                onUpdateAdminUrl={handleUpdateAdminUrl}
                seriesUrl={seriesUrl}
                onUpdateSeriesUrl={handleUpdateSeriesUrl}
                activeClubId={userProfile.activeClubId || null}
                activeTeamId={userProfile.activeTeamId || null}
                onSelectActiveTeam={(clubId, teamId) => {
                  const updated = { ...userProfile, activeClubId: clubId, activeTeamId: teamId };
                  if (user) {
                    setDoc(doc(db, 'users', user.uid, 'data', 'profile'), updated, { merge: true })
                      .catch(err => console.error("Failed to save active team profile:", err));
                  }
                  handleProfileUpdated(updated);
                }}
                activeSquad={squad}
                onUpdateSquad={handleUpdateSquad}
                trainingSettings={trainingSettings}
                onUpdateSettings={onUpdateSettings}
                sessions={sessions}
                onUpdateSessions={(newSessions) => {
                  setData(prev => ({ ...prev, sessions: newSessions }));
                  setSessionActionCount(prev => prev + 1);
                }}
              />
            </motion.div>
          )}

          {view === 'leaderboard' && (
            <Leaderboard 
              key="leaderboard" 
              squad={squad} 
              exercises={exercises} 
              periods={periods}
              currentPeriodId={currentPeriodId}
              onClosePeriod={handleClosePeriod}
              onStartNewPeriod={handleStartNewPeriod}
              onDeletePeriod={handleDeletePeriod}
              onCreatePeriod={createNewPeriod}
              onSwitchPeriod={switchActivePeriod}
              onRenamePeriod={renamePeriod}
              onUpdatePeriod={updatePeriod}
              sharedId={sharedLeaderboardId}
              userUid={user?.uid}
            />
          )}

          {view === 'teampage' && (
            <motion.div
              key="teampage"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex-1 flex flex-col min-h-0 w-full"
            >
              <TeamPage 
                initialUrl={teamUrl}
                onUpdateUrl={handleUpdateTeamUrl}
                initialAdminUrl={adminUrl}
                onUpdateAdminUrl={handleUpdateAdminUrl}
                initialSeriesUrl={seriesUrl}
                onUpdateSeriesUrl={handleUpdateSeriesUrl}
              />
              {/* Spacer for bottom nav when not in standalone full-height mode */}
              <div className="h-20 shrink-0" />
            </motion.div>
          )}

          {view === 'lineup' && canViewLineup && (
            <LineupBuilder 
              squad={squad} 
              lineup={effectiveActiveLineup} 
              lineups={lineups}
              sessions={sessions}
              onUpdateLineup={updateLineup}
              onSaveLineup={handleSaveLineup}
              onDeleteLineup={handleDeleteLineup}
              onSelectLineup={(id) => {
                setData(prev => ({ ...prev, activeLineupId: id }));
                setSessionActionCount(prev => prev + 1);
              }}
              onCopyLineup={handleCopyLineup}
              onReorderLineups={handleReorderLineups}
              onUpdateSquad={handleUpdateSquad}
              customFormations={customFormations}
              pinnedFormationIds={pinnedFormationIds}
              onTogglePinFormation={(id) => {
                setData(prev => {
                  const pinned = prev.pinnedFormationIds || ['4-2-3-1', '4-4-2', '4-3-3'];
                  const isPinned = pinned.includes(id);
                  const newPinned = isPinned 
                    ? pinned.filter(pid => pid !== id)
                    : [...pinned, id];
                  return { ...prev, pinnedFormationIds: newPinned };
                });
                setSessionActionCount(prev => prev + 1);
              }}
              onSaveCustomFormation={(formation) => {
                setData(prev => ({
                  ...prev,
                  customFormations: [...(prev.customFormations || []), formation]
                }));
                setSessionActionCount(prev => prev + 1);
              }}
              onDeleteCustomFormation={(id) => {
                setData(prev => ({
                  ...prev,
                  customFormations: (prev.customFormations || []).filter(f => f.id !== id)
                }));
                setSessionActionCount(prev => prev + 1);
              }}
              user={user}
              isSyncing={isSyncing}
              sessionActionCount={sessionActionCount}
              isQuotaExceeded={isQuotaExceeded}
              syncError={syncError}
              isCoachOrAdmin={isCoachOrAdmin}
              onManualSync={pullLatestData}
              onManualPush={handleManualPush}
              onMaximizedChange={setIsLineupMaximized}
            />
          )}

          {view === 'exercise' && (
            activeExercise ? (
              <motion.div
                key="exercise"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className={`max-w-7xl mx-auto w-full h-full flex flex-col px-2 sm:px-4 pb-2 sm:pb-3 overflow-hidden select-none transition-all duration-300 ${
                  isTimerRunning ? 'pt-1 sm:pt-2' : 'pt-0.5 sm:pt-1'
                }`}
              >
              {(() => {
                const exerciseSession = (activeSessionId ? sessions.find(s => s.id === activeSessionId && s.moments?.some(m => m.exerciseId === activeExercise.id)) : null)
                  || (activeExercise.sessionId ? sessions.find(s => s.id === activeExercise.sessionId) : null)
                  || sessions.find(s => s.moments && s.moments.some(m => m.exerciseId === activeExercise.id))
                  || (activeSessionId ? sessions.find(s => s.id === activeSessionId) : null)
                  || null;

                const guestsForExercise = exerciseSession?.guestPlayers || [];
                const combinedExerciseSquad = [...squad, ...guestsForExercise];
                const jokers = Array.from(new Set(activeExercise.jokerPlayerIds || []));

                // Find linked moment and calculate start/end time and duration
                let momentSchedule: { duration: number; timeRange: string; sessionTitle?: string } | null = null;
                if (exerciseSession && exerciseSession.moments && exerciseSession.moments.length > 0) {
                  let momentIndex = exerciseSession.moments.findIndex(m => m.exerciseId === activeExercise.id);
                  if (momentIndex === -1) {
                    momentIndex = exerciseSession.moments.findIndex(m =>
                      m.name && activeExercise.name && (
                        m.name.trim().toLowerCase() === activeExercise.name.trim().toLowerCase() ||
                        activeExercise.name.trim().toLowerCase().startsWith(m.name.trim().toLowerCase())
                      )
                    );
                  }

                  if (momentIndex !== -1) {
                    const moment = exerciseSession.moments[momentIndex];
                    const duration = Number(moment.duration) || 0;
                    let startTimeStr = '';
                    let endTimeStr = '';

                    if (exerciseSession.startTime) {
                      let currentMinutes = 0;
                      const [startH, startM] = exerciseSession.startTime.split(':').map(Number);
                      if (!isNaN(startH) && !isNaN(startM)) {
                        const startDate = exerciseSession.date ? new Date(exerciseSession.date) : new Date();
                        startDate.setHours(startH, startM, 0, 0);

                        for (let i = 0; i < exerciseSession.moments.length; i++) {
                          const m = exerciseSession.moments[i];
                          const mDur = Number(m.duration) || 0;
                          if (i === momentIndex) {
                            const momentStart = new Date(startDate.getTime() + currentMinutes * 60000);
                            const momentEnd = new Date(momentStart.getTime() + mDur * 60000);
                            startTimeStr = momentStart.toLocaleTimeString('sv-SE', { hour: '2-digit', minute: '2-digit' });
                            endTimeStr = momentEnd.toLocaleTimeString('sv-SE', { hour: '2-digit', minute: '2-digit' });
                            break;
                          }
                          currentMinutes += mDur;
                        }
                      }
                    }

                    if (duration > 0 || (startTimeStr && endTimeStr)) {
                      momentSchedule = {
                        duration,
                        timeRange: (startTimeStr && endTimeStr) ? `${startTimeStr}–${endTimeStr}` : '',
                        sessionTitle: exerciseSession.title
                      };
                    }
                  }
                }
                
                return (
                  <div className={`shrink-0 flex flex-col items-center transition-all duration-300 ${
                    isTimerRunning ? 'mb-1 sm:mb-2 gap-0' : 'mb-1.5 sm:mb-2 gap-1 sm:gap-1.5'
                  }`}>
                    {/* Tävlingsmomentets namn i väldigt liten tunn stil precis under toppmenyn (döljs när timern är igång så bara timer & poäng syns) */}
                    {!isTimerRunning && (
                      <div className="text-center px-4 -mt-0.5 mb-0.5 select-none transition-opacity duration-300 flex items-center justify-center gap-1.5 flex-nowrap overflow-hidden text-ellipsis whitespace-nowrap">
                        <span className="text-[11px] sm:text-xs font-semibold tracking-wide text-zinc-700 dark:text-zinc-200 truncate">
                          {activeExercise.name}
                        </span>
                        {momentSchedule && (
                          <span 
                            className="text-[10px] sm:text-[11px] font-medium tracking-wide text-zinc-600 dark:text-zinc-300 shrink-0 inline-flex items-center gap-1.5"
                            title={`Pass: ${momentSchedule.sessionTitle || 'Träningspass'}${momentSchedule.duration ? ` • Längd: ${momentSchedule.duration} min` : ''}${momentSchedule.timeRange ? ` • Tid: ${momentSchedule.timeRange}` : ''}`}
                          >
                            <span className="text-zinc-400 dark:text-zinc-500 select-none">•</span>
                            {momentSchedule.duration > 0 && (
                              <span className="font-semibold text-zinc-800 dark:text-zinc-100">{momentSchedule.duration} min</span>
                            )}
                            {momentSchedule.timeRange && (
                              <span className="text-zinc-600 dark:text-zinc-400 font-medium">
                                ({momentSchedule.timeRange})
                              </span>
                            )}
                          </span>
                        )}
                      </div>
                    )}

                    {hasTypedInSession && !isTimerRunning && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="flex items-center gap-1.5 px-3 py-1 mb-1 rounded-full bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/50 text-[11px] text-amber-800 dark:text-amber-200 shadow-xs"
                      >
                        <span className="font-semibold">⚠️ Text skrevs nyligen:</span>
                        <button
                          type="button"
                          onClick={handleResetShakeProtection}
                          className="underline font-bold text-amber-800 dark:text-amber-200 hover:text-amber-950 dark:hover:text-amber-100 cursor-pointer"
                        >
                          Klicka här för att skaksäkra
                        </button>
                        <span>så slipper du iOS "Ångra"</span>
                      </motion.div>
                    )}

                    {activeExercise.showTimer && (
                      <div className="w-full max-w-sm">
                        <Timer 
                          defaultMinutes={activeExercise.defaultTimerMinutes} 
                          defaultSeconds={activeExercise.defaultTimerSeconds} 
                          onSaveDefault={updateActiveExerciseDefaultTimer}
                          isCoachOrAdmin={isCoachOrAdmin}
                          onRunningChange={setIsTimerRunning}
                        />
                      </div>
                    )}

                    {/* Skjuter upp Jokrar högre upp; döljs när timern är igång så bara timer och poängställning syns */}
                    {!isTimerRunning && (
                    <div 
                      data-team-id="joker"
                      className={`flex flex-wrap items-center gap-1.5 sm:gap-2 px-2.5 py-1 rounded-xl border transition-all duration-300 ${
                        draggedPlayerId 
                          ? 'bg-indigo-100/40 dark:bg-indigo-950/40 border-dashed border-indigo-400 dark:border-indigo-500 scale-105 animate-pulse shadow-md'
                          : 'bg-indigo-50/60 dark:bg-indigo-950/20 border-indigo-100/80 dark:border-indigo-900/40'
                      }`}
                    >
                      <Zap size={13} className="text-indigo-600 dark:text-indigo-400" fill="currentColor" />
                      <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                        Jokrar:
                      </span>
                      
                      <div className="flex flex-wrap gap-1 items-center min-h-[22px]">
                        {Array.from(new Set(jokers as string[])).map((id: string) => {
                          const player = combinedExerciseSquad.find(p => p.id === id);
                          if (!player) return null;
                          return (
                            <motion.span
                              key={id}
                              drag={isCoachOrAdmin}
                              dragSnapToOrigin
                              onDragStart={() => { if (isCoachOrAdmin) setDraggedPlayerId(id); }}
                              onDragEnd={(e: any, info) => {
                                if (!isCoachOrAdmin) return;
                                setDraggedPlayerId(null);
                                const point = (e.nativeEvent || e).clientX !== undefined ? (e.nativeEvent || e) : info.point;
                                const x = point.clientX || point.x;
                                const y = point.clientY || point.y;
                                const elements = document.elementsFromPoint(x, y);
                                const teamElement = elements
                                  .map(el => (el as HTMLElement).closest?.('[data-team-id]'))
                                  .find(te => te && te.getAttribute('data-team-id') !== 'joker');

                                if (teamElement) {
                                  const targetTeamId = teamElement.getAttribute('data-team-id');
                                  if (targetTeamId) {
                                    movePlayer(activeExercise.id, id, targetTeamId);
                                  }
                                }
                              }}
                              whileTap={isCoachOrAdmin ? { scale: 0.95 } : undefined}
                              whileDrag={isCoachOrAdmin ? {
                                zIndex: 9999,
                                scale: 1.1,
                                pointerEvents: 'none'
                              } : undefined}
                              className={`text-[10px] font-black text-zinc-700 dark:text-zinc-200 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 px-2 py-0.5 rounded-md ${isCoachOrAdmin ? 'cursor-grab active:cursor-grabbing' : 'cursor-default'} touch-none z-50 shadow-sm select-none`}
                            >
                              {player.name}
                            </motion.span>
                          );
                        })}
                        {jokers.length === 0 && (
                          <span className="text-[9px] text-indigo-400/80 dark:text-indigo-500/80 font-semibold uppercase tracking-wider pointer-events-none px-1">
                            {isCoachOrAdmin ? 'Släpp spelare här för Joker' : 'Inga jokrar'}
                          </span>
                        )}
                      </div>
                    </div>
                    )}
                  </div>
                );
              })()}

              <div className={`flex-1 flex flex-col gap-2 sm:gap-3 min-h-0 w-full max-w-2xl mx-auto ${activeExercise.teams.length > 5 ? 'overflow-y-auto' : 'overflow-hidden sm:overflow-y-auto'}`}>
                <AnimatePresence mode="popLayout">
                  {(activeExercise.sortByScore 
                    ? [...activeExercise.teams].sort((a, b) => b.score - a.score)
                    : activeExercise.teams
                  ).filter((team, index, self) => 
                    index === self.findIndex((t) => t.id === team.id)
                  ).map((team) => {
                    const exerciseSession = activeExercise.sessionId ? sessions.find(s => s.id === activeExercise.sessionId) : null;
                    const guestsForExercise = exerciseSession?.guestPlayers || [];
                    const combinedExerciseSquad = [...squad, ...guestsForExercise];

                    return (
                      <motion.div 
                        layout
                        key={team.id} 
                        className={`${activeExercise.teams.length > 5 ? 'h-24 shrink-0' : 'flex-1'} min-h-0 flex flex-col`}
                      >
                        <PlayerCard
                          team={team}
                          squad={combinedExerciseSquad}
                          rank={sortedScores.indexOf(team.score) + 1}
                          onUpdateScore={updateScore}
                          onUpdateColor={updateTeamColor}
                          onRankClick={handleRankClick}
                          disabled={activeExercise.isFinished || !isCoachOrAdmin}
                          exerciseId={activeExercise.id}
                          onMovePlayer={movePlayer}
                          draggedPlayerId={isCoachOrAdmin ? draggedPlayerId : null}
                          isAnyPlayerDragging={isCoachOrAdmin && !!draggedPlayerId}
                          onDragStart={(pid) => { if (isCoachOrAdmin) setDraggedPlayerId(pid); }}
                          onDragEnd={() => setDraggedPlayerId(null)}
                        />
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            </motion.div>
            ) : (!isInitialSyncDone || !isProfileLoaded) ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-white dark:bg-zinc-950">
                <div className="w-10 h-10 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4" />
                <p className="text-zinc-500 font-medium text-sm">Laddar tävlingsmoment...</p>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-white dark:bg-zinc-950">
                <div className="w-20 h-20 bg-zinc-100 dark:bg-zinc-800 rounded-3xl flex items-center justify-center text-zinc-400 mb-6">
                  <Trophy size={40} />
                </div>
                <h3 className="text-xl font-bold text-zinc-900 dark:text-white mb-2">Tävlingsmomentet hittades inte</h3>
                <p className="text-zinc-500 dark:text-zinc-400 mb-8 max-w-xs font-medium">
                  Detta kan bero på att momentet har tagits bort eller att du navigerat fel.
                </p>
                <button
                  onClick={() => setView('training')}
                  className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 dark:shadow-none"
                >
                  Gå tillbaka till kalendern
                </button>
              </div>
            )
          )}
        </AnimatePresence>

        {view !== 'exercise' && !(view === 'lineup' && isLineupMaximized) && (
          <div className="mt-8 mb-2 flex flex-col items-center justify-center gap-2">
            {activeClubInfo && (
              isCoachOrAdmin ? (
                <button
                  type="button"
                  onClick={() => setView('clubadmin')}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 border border-indigo-200/60 dark:border-indigo-800/60 text-indigo-700 dark:text-indigo-300 transition-all text-xs font-extrabold cursor-pointer active:scale-95 shadow-2xs"
                  title="Klicka för att hantera eller byta Förening & Lag"
                >
                  <Building2 size={13} className="text-indigo-600 dark:text-indigo-400 shrink-0" />
                  <span>{activeClubInfo.clubName}</span>
                  <span className="text-indigo-300 dark:text-indigo-600">•</span>
                  <Users size={13} className="text-indigo-600 dark:text-indigo-400 shrink-0" />
                  <span>{activeClubInfo.teamName}</span>
                </button>
              ) : (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-100 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-400 text-xs font-bold shadow-2xs">
                  <Building2 size={13} className="text-zinc-500 shrink-0" />
                  <span>{activeClubInfo.clubName}</span>
                  <span className="text-zinc-400">•</span>
                  <Users size={13} className="text-zinc-500 shrink-0" />
                  <span>{activeClubInfo.teamName}</span>
                </div>
              )
            )}
            <VersionFooter />
          </div>
        )}
      </main>

      {/* Bottom Navigation with Apple Liquid Glass aesthetic */}
      {view !== 'exercise' && !(view === 'lineup' && isLineupMaximized) && (
        <nav className="fixed bottom-0 left-0 right-0 liquid-glass border-t border-zinc-200/60 dark:border-zinc-800/60 px-2 sm:px-6 pt-1.5 pb-1.5 z-40">
          <div className="max-w-xl mx-auto flex items-center justify-between gap-1">
            <button
              onClick={() => setView('training')}
              className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 relative ${
                view === 'training'
                  ? 'text-indigo-600 dark:text-indigo-400 liquid-glass-pill font-bold shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200'
              }`}
            >
              <Calendar size={22} className="transition-transform active:scale-90" />
              <span className="text-[10px] font-bold uppercase tracking-wider mt-0.5 leading-none">Kalender</span>
            </button>
            <button
              onClick={() => setView('leaderboard')}
              className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 relative ${
                view === 'leaderboard'
                  ? 'text-indigo-600 dark:text-indigo-400 liquid-glass-pill font-bold shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200'
              }`}
            >
              <LayoutDashboard size={22} className="transition-transform active:scale-90" />
              <span className="text-[10px] font-bold uppercase tracking-wider mt-0.5 leading-none text-center">Poängliga</span>
            </button>
            <button
              onClick={() => setView('squad')}
              className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 relative ${
                view === 'squad'
                  ? 'text-indigo-600 dark:text-indigo-400 liquid-glass-pill font-bold shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200'
              }`}
            >
              <Users size={22} className="transition-transform active:scale-90" />
              <span className="text-[10px] font-bold uppercase tracking-wider mt-0.5 leading-none text-center">Truppen</span>
            </button>
            {canViewLineup && (
              <button
                onClick={() => setView('lineup')}
                className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 relative ${
                  view === 'lineup'
                    ? 'text-indigo-600 dark:text-indigo-400 liquid-glass-pill font-bold shadow-xs'
                    : 'text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200'
                }`}
              >
                <Shirt size={22} className="transition-transform active:scale-90" />
                <span className="text-[10px] font-bold uppercase tracking-wider mt-0.5 leading-none text-center">Laguppst.</span>
              </button>
            )}
            <button
              onClick={() => setView('teampage')}
              className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all duration-200 relative ${
                view === 'teampage'
                  ? 'text-indigo-600 dark:text-indigo-400 liquid-glass-pill font-bold shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200'
              }`}
            >
              <Globe size={22} className="transition-transform active:scale-90" />
              <span className="text-[10px] font-bold uppercase tracking-wider mt-0.5 leading-none text-center">Lagsida</span>
            </button>
          </div>
        </nav>
      )}

      <AnimatePresence>
        {showTeamOverview && activeExercise && (
          <TeamOverviewModal
            exercise={activeExercise}
            squad={[...squad, ...(sessions.find(s => s.id === activeExercise.sessionId)?.guestPlayers || [])]}
            attendingIds={sessions.find(s => s.id === activeExercise.sessionId)?.attendance}
            onMovePlayer={movePlayer}
            onClose={() => setShowTeamOverview(false)}
            exercises={data.exercises}
            onCopyTeams={(sourceId) => copyTeams(sourceId, activeExercise.id)}
            onAddGuest={(name, position) => {
              const session = sessions.find(s => s.id === activeExercise.sessionId);
              if (session) {
                const newGuest = {
                  id: `guest_${Date.now()}_${Math.random().toString(36).substring(7)}`,
                  name: name.trim(),
                  position: position || undefined,
                };
                onUpdateSession({
                  ...session,
                  guestPlayers: [...(session.guestPlayers || []), newGuest],
                  attendance: [...(session.attendance || []), newGuest.id],
                  updatedAt: Date.now()
                });
              }
            }}
            onAddSquadPlayerToAttendance={(playerId) => {
              const session = sessions.find(s => s.id === activeExercise.sessionId);
              if (session) {
                const currentAttendance = session.attendance || [];
                if (!currentAttendance.includes(playerId)) {
                  onUpdateSession({
                    ...session,
                    attendance: [...currentAttendance, playerId],
                    updatedAt: Date.now()
                  });
                }
              }
            }}
            onRemovePlayerFromAttendance={(playerId) => {
              const session = sessions.find(s => s.id === activeExercise.sessionId);
              if (session) {
                const currentAttendance = session.attendance || [];
                const isGuest = playerId.startsWith('guest_');
                onUpdateSession({
                  ...session,
                  attendance: currentAttendance.filter(id => id !== playerId),
                  guestPlayers: isGuest ? (session.guestPlayers || []).filter(p => p.id !== playerId) : session.guestPlayers,
                  updatedAt: Date.now()
                });
              }
            }}
          />
        )}
      </AnimatePresence>

      {/* Sessions & Overlays */}
      <AnimatePresence>
        {activeSessionId && sessions.find(s => s.id === activeSessionId) && view !== 'exercise' && view !== 'setup' && (
          <SessionEditor
            session={sessions.find(s => s.id === activeSessionId)!}
            exercises={exercises}
            squad={squad}
            onUpdate={(updated) => onUpdateSession({ ...updated, isLocallyEdited: true, isPlanned: true })}
            allSessions={sessions}
            onUpdateSession={(updated) => onUpdateSession({ ...updated, isLocallyEdited: true, isPlanned: true })}
            exerciseBank={exerciseBank}
            exerciseBankCategories={exerciseBankCategories}
            onSaveToBank={saveMomentToBank}
            onUpdateBankExercise={updateBankExercise}
            initialMode={sessionMode}
            onModeChange={setSessionMode}
            onMovePlayer={movePlayer}
            onCopyTeams={copyTeams}
            initialTab={sessionEditorTab}
            adminUrl={adminUrl}
            user={user}
            userRoles={userRoles}
            userProfile={userProfile}
            onClose={() => {
              if (sessionActionCountRef.current > 0) {
                pushDirtySegments(true).catch(err => console.warn('App: Push on session editor close:', err));
              }
              setActiveSessionId(null);
              setLinkToMomentId(null);
            }}
            onCreateExercise={(name, momentId) => {
              setPreviousActiveExerciseId(activeExerciseId);
              setLinkToMomentId(momentId);
              setPrefilledName(name || 'Nytt tävlingsmoment');
              setEditReturnView('training');
              setIsEditingActiveExercise(false);
              setView('setup');
              setSessionActionCount(prev => prev + 1);
              return ""; 
            }}
            onSelectExercise={(id) => {
              handleSelectExercise(id);
              // We DON'T call setActiveSessionId(null) here because we want to come back to it
            }}
            onEditExercise={(id) => {
              setPreviousActiveExerciseId(activeExerciseId);
              setData(prev => ({ ...prev, activeExerciseId: id }));
              setEditReturnView('training');
              setIsEditingActiveExercise(true);
              setView('setup');
              setSessionActionCount(prev => prev + 1);
            }}
            onDeleteExercise={deleteExercise}
            onOpenLineup={(sess) => {
              // Check if lineup exists for this session
              let targetLineup = lineups.find(l => l.sessionId === sess.id);
              if (!targetLineup && sess.lineupId) {
                targetLineup = lineups.find(l => l.id === sess.lineupId);
              }

              if (targetLineup) {
                setData(prev => ({
                  ...prev,
                  activeLineupId: targetLineup!.id
                }));
              } else {
                // Auto-create linked lineup with all attending players on bench
                const attendingIds = sess.attendance || [];
                const initialPlayers = attendingIds.map((playerId, idx) => ({
                  id: `player_${Date.now()}_${idx}_${Math.random().toString(36).substring(7)}`,
                  playerId,
                  x: 50,
                  y: 50,
                  isSubstitute: true,
                }));

                const newLineup: Lineup = {
                  id: `lineup_${Date.now()}_${Math.random().toString(36).substring(7)}`,
                  teamName: activeClubInfo?.teamName || '',
                  matchTitle: sess.title || 'Match',
                  date: sess.date || Date.now(),
                  formation: '4-3-3',
                  players: initialPlayers,
                  sessionId: sess.id,
                  createdAt: Date.now(),
                  updatedAt: Date.now(),
                };

                setData(prev => {
                  const updatedLineups = [newLineup, ...prev.lineups];
                  try {
                    setPrefixedItem('football_lineups', JSON.stringify(updatedLineups), user);
                    setPrefixedItem('active_lineup_id', newLineup.id, user);
                  } catch (e) {}
                  return {
                    ...prev,
                    lineups: updatedLineups,
                    activeLineupId: newLineup.id
                  };
                });

                onUpdateSession({
                  ...sess,
                  lineupId: newLineup.id,
                  updatedAt: Date.now()
                });
              }

              setActiveSessionId(null);
              setView('lineup');
              setSessionActionCount(prev => prev + 1);
            }}
          />
        )}
      </AnimatePresence>

      {/* Confirmation Modals */}
      <AnimatePresence>

        {showResetConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowResetConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-zinc-900 rounded-3xl p-8 max-w-sm w-full shadow-2xl border border-zinc-100 dark:border-zinc-800"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-xl font-bold text-zinc-900 dark:text-white mb-2">Nollställ poäng?</h3>
              <p className="text-zinc-500 dark:text-zinc-400 mb-8">
                Detta kommer att sätta alla lags poäng till 0. Handlingen kan inte ångras.
              </p>
              <div className="flex flex-col gap-3">
                <button
                  onClick={resetScores}
                  className="w-full py-3 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition-colors"
                >
                  Ja, nollställ
                </button>
                <button
                  onClick={() => setShowResetConfirm(false)}
                  className="w-full py-3 bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 rounded-xl font-bold hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
                >
                  Avbryt
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}

        {showFinishConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowFinishConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-zinc-900 rounded-3xl p-8 max-w-sm w-full shadow-2xl border border-zinc-100 dark:border-zinc-800"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-2xl flex items-center justify-center text-green-600 dark:text-green-400 mb-6 mx-auto">
                <Trophy size={32} />
              </div>
              <h3 className="text-xl font-bold text-zinc-900 dark:text-white mb-2 text-center">Avsluta tävlingsmomentet?</h3>
              
              <div className="mb-6">
                <label className="block text-[10px] font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-2 text-center">
                  Klarmarkera mot tävling
                </label>
                <select
                  value={finishTargetPeriodId || ''}
                  onChange={(e) => setFinishTargetPeriodId(e.target.value || null)}
                  className="w-full bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-xl px-4 py-3 text-sm font-bold text-zinc-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer"
                >
                  <option value="">Ingen tävling (endast arkiv)</option>
                  {Array.from(new Map<string, Period>(periods.filter(p => !p.endDate).map(p => [p.id, p])).values()).map((p: Period) => (
                    <option key={p.id} value={p.id}>
                      {p.name} {p.isActive ? '(Aktiv)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              <p className="text-zinc-500 dark:text-zinc-400 mb-8 text-sm text-center leading-relaxed">
                Detta kommer att kora vinnare och dela ut poäng till spelarna i den valda tävlingen.
              </p>
              <div className="flex flex-col gap-3">
                <button
                  onClick={finishExercise}
                  className="w-full py-4 bg-green-600 text-white rounded-2xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-200 dark:shadow-none"
                >
                  Ja, avsluta och kora vinnare
                </button>
                <button
                  onClick={() => setShowFinishConfirm(false)}
                  className="w-full py-4 bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 rounded-2xl font-bold hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-all"
                >
                  Fortsätt tävlingsmomentet
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Onboarding Dialog for new / pending users */}
      {user &&
        !isRootAdmin &&
        isProfileLoaded &&
        (!userProfile.onboardingCompleted || userProfile.status === 'pending' || !userProfile.activeClubId) && (
          <OnboardingModal
            user={user}
            userProfile={userProfile}
            onProfileUpdated={handleProfileUpdated}
            onLogout={handleLogout}
          />
      )}

      {/* Admin Approval Modal for pending requests */}
      <PendingRequestsModal
        activeClubId={userProfile.activeClubId || null}
        isOpen={isPendingRequestsModalOpen}
        onClose={() => setIsPendingRequestsModalOpen(false)}
        onRequestHandled={refreshPendingRequestsCount}
      />

      {/* Quick Shake Clear Modal (inside Exercise view - fast 1-click confirmation) */}
      <QuickShakeModal
        isOpen={isQuickShakeModalOpen}
        onClose={() => setIsQuickShakeModalOpen(false)}
        onConfirm={handleSafeShakeReload}
      />

      {/* Shake Protection Modal (iOS Shake to Undo guide & info in Profile & Settings) */}
      <ShakeProtectionModal
        isOpen={isShakeInfoModalOpen}
        onClose={() => setIsShakeInfoModalOpen(false)}
        onSafeReload={handleSafeShakeReload}
        hasTypedInSession={hasTypedInSession}
      />
    </div>
  );
}
