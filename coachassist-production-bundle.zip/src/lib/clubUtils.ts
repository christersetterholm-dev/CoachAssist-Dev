import { SquadPlayer, ClubMember } from '../types';
import { db, doc, getDoc, setDoc } from './firebase';

/**
 * Deduplicates an array of SquadPlayer objects by ID, personnummer, email, or (fullName + number/role).
 */
export function deduplicateSquad(squad: SquadPlayer[]): SquadPlayer[] {
  if (!squad || squad.length === 0) return [];

  const result: SquadPlayer[] = [];

  for (const player of squad) {
    if (!player.name || !player.name.trim()) continue;

    const cleanName = player.name.trim();
    const cleanEmail = (player.email || '').trim().toLowerCase();
    const cleanPnr = (player.personnummer || '').replace(/\D/g, '');
    const cleanNum = (player.number || '').trim();
    const playerRole: 'leader' | 'player' = player.role === 'leader' ? 'leader' : 'player';
    const basePlayerId = (player.id || '').replace('_leader', '');

    const idx = result.findIndex(existing => {
      const exRole: 'leader' | 'player' = existing.role === 'leader' ? 'leader' : 'player';
      // Only treat as duplicate if they have the exact same squad role ('player' vs 'player' or 'leader' vs 'leader')
      if (exRole !== playerRole) return false;

      const baseExId = (existing.id || '').replace('_leader', '');
      const exName = existing.name.trim().toLowerCase();
      const exEmail = (existing.email || '').trim().toLowerCase();
      const exPnr = (existing.personnummer || '').replace(/\D/g, '');
      const exNum = (existing.number || '').trim();

      if (basePlayerId && baseExId && basePlayerId === baseExId) return true;
      if (cleanPnr && exPnr && cleanPnr === exPnr) return true;
      if (cleanEmail && exEmail && cleanEmail === exEmail) return true;

      if (exName === cleanName.toLowerCase()) {
        if (cleanNum && exNum) {
          return cleanNum === exNum;
        }
        return true;
      }
      return false;
    });

    if (idx !== -1) {
      const existing = result[idx];

      const pickVal = (newVal?: string, oldVal?: string) => {
        if (newVal !== undefined && newVal !== null && newVal.trim() !== '') return newVal.trim();
        if (oldVal !== undefined && oldVal !== null && oldVal.trim() !== '') return oldVal.trim();
        return undefined;
      };

      const mergedRoles = Array.from(new Set([...(existing.roles || []), ...(player.roles || [])]));

      result[idx] = {
        id: existing.id || player.id,
        name: player.name?.trim() || existing.name?.trim() || cleanName,
        email: pickVal(player.email, existing.email),
        phone: pickVal(player.phone, existing.phone),
        personnummer: pickVal(player.personnummer, existing.personnummer),
        position: pickVal(player.position, existing.position),
        number: pickVal(player.number, existing.number),
        photoUrl: pickVal(player.photoUrl, existing.photoUrl),
        role: playerRole,
        roles: mergedRoles.length > 0 ? mergedRoles : undefined
      };
    } else {
      result.push({
        ...player,
        name: cleanName,
        email: player.email ? player.email.trim() : undefined,
        phone: player.phone ? player.phone.trim() : undefined,
        personnummer: player.personnummer ? player.personnummer.trim() : undefined,
        position: player.position ? player.position.trim() : undefined,
        number: player.number ? player.number.trim() : undefined,
        photoUrl: player.photoUrl ? player.photoUrl.trim() : undefined,
        role: playerRole
      });
    }
  }

  return result;
}

/**
 * Deduplicates an array of ClubMember objects by userId, personnummer, email, or (fullName + number).
 */
export function deduplicateClubMembers(members: ClubMember[]): ClubMember[] {
  if (!members || members.length === 0) return [];

  const result: ClubMember[] = [];

  for (const member of members) {
    if (!member.fullName || !member.fullName.trim()) continue;

    const cleanName = member.fullName.trim();
    const cleanEmail = (member.email || '').trim().toLowerCase();
    const cleanPnr = (member.personnummer || '').replace(/\D/g, '');
    const cleanNum = (member.number || '').trim();

    const idx = result.findIndex(existing => {
      const exName = existing.fullName.trim().toLowerCase();
      const exEmail = (existing.email || '').trim().toLowerCase();
      const exPnr = (existing.personnummer || '').replace(/\D/g, '');
      const exNum = (existing.number || '').trim();

      if (member.userId && existing.userId && member.userId === existing.userId) return true;
      if (cleanPnr && exPnr && cleanPnr === exPnr) return true;
      if (cleanEmail && exEmail && cleanEmail === exEmail) return true;

      if (exName === cleanName.toLowerCase()) {
        if (cleanNum && exNum) {
          return cleanNum === exNum;
        }
        return true;
      }
      return false;
    });

    if (idx !== -1) {
      const existing = result[idx];

      const pickEmail = () => {
        const memEmail = (member.email || '').trim();
        const exEmail = (existing.email || '').trim();
        if (memEmail && !memEmail.includes('@noemail.local')) return memEmail;
        if (exEmail && !exEmail.includes('@noemail.local')) return exEmail;
        return memEmail || exEmail || '';
      };

      const pickVal = (newVal?: string, oldVal?: string) => {
        if (newVal !== undefined && newVal !== null && newVal.trim() !== '') return newVal.trim();
        if (oldVal !== undefined && oldVal !== null && oldVal.trim() !== '') return oldVal.trim();
        return undefined;
      };

      let bestUserId = member.userId || existing.userId;
      if (existing.userId && !existing.userId.startsWith('player_') && member.userId && member.userId.startsWith('player_')) {
        bestUserId = existing.userId;
      }

      const mergedRoles = Array.from(new Set([...(existing.roles || []), ...(member.roles || [])]));
      const mergedTeams = Array.from(new Set([...(existing.teams || []), ...(member.teams || [])]));

      result[idx] = {
        userId: bestUserId,
        fullName: member.fullName?.trim() || existing.fullName?.trim() || cleanName,
        email: pickEmail(),
        phone: pickVal(member.phone, existing.phone),
        personnummer: pickVal(member.personnummer, existing.personnummer),
        position: pickVal(member.position, existing.position),
        number: pickVal(member.number, existing.number),
        photoUrl: pickVal(member.photoUrl, existing.photoUrl),
        roles: mergedRoles.length > 0 ? mergedRoles : ['player'],
        teams: mergedTeams
      };
    } else {
      result.push({
        ...member,
        fullName: cleanName,
        email: member.email ? member.email.trim() : '',
        phone: member.phone ? member.phone.trim() : undefined,
        personnummer: member.personnummer ? member.personnummer.trim() : undefined,
        position: member.position ? member.position.trim() : undefined,
        number: member.number ? member.number.trim() : undefined,
        photoUrl: member.photoUrl ? member.photoUrl.trim() : undefined,
        roles: member.roles || ['player'],
        teams: member.teams || []
      });
    }
  }

  return result;
}

/**
 * Synchronizes squad players & leaders to the club's global members list,
 * ensuring that every person in `squad` exists as a `ClubMember`
 * assigned to `teamId` with roles `['player']` or `['coach']`.
 */
export async function syncSquadToClubMembers(
  squad: SquadPlayer[],
  clubId: string,
  teamId: string
): Promise<void> {
  if (!clubId || !teamId || !squad || squad.length === 0) return;

  try {
    const cleanSquad = deduplicateSquad(squad);
    const membersRef = doc(db, 'clubs', clubId, 'teams', 'club_global', 'data', 'members');
    const membersSnap = await getDoc(membersRef);
    let members: ClubMember[] = membersSnap.exists() ? (membersSnap.data().members || []) : [];
    members = deduplicateClubMembers(members);

    let isModified = false;

    const playerEntries = cleanSquad.filter(p => p.role !== 'leader');
    const leaderEntries = cleanSquad.filter(p => p.role === 'leader');

    for (const player of cleanSquad) {
      if (!player.name || !player.name.trim()) continue;
      const cleanName = player.name.trim();
      const cleanEmail = (player.email || '').trim().toLowerCase();
      const cleanPnr = (player.personnummer || '').replace(/\D/g, '');
      const cleanNum = (player.number || '').trim();
      const basePlayerId = (player.id || '').replace('_leader', '');

      const idx = members.findIndex(m => {
        const mEmail = (m.email || '').trim().toLowerCase();
        const mName = (m.fullName || '').trim().toLowerCase();
        const mPnr = (m.personnummer || '').replace(/\D/g, '');
        const mNum = (m.number || '').trim();

        if (basePlayerId && (m.userId === basePlayerId || m.userId === player.id)) return true;
        if (cleanPnr && mPnr && cleanPnr === mPnr) return true;
        if (cleanEmail && mEmail === cleanEmail) return true;

        if (mName === cleanName.toLowerCase()) {
          if (cleanNum && mNum) {
            return cleanNum === mNum;
          }
          return true;
        }

        return false;
      });

      if (idx !== -1) {
        const existing = members[idx];
        const existingRoles = existing.roles || [];
        const existingTeams = existing.teams || [];

        const matchesPlayer = (p: SquadPlayer) => {
          const bId = (p.id || '').replace('_leader', '');
          if (bId && (bId === existing.userId || p.id === existing.userId)) return true;
          if (cleanPnr && p.personnummer && cleanPnr === (p.personnummer || '').replace(/\D/g, '')) return true;
          if (cleanEmail && p.email && cleanEmail === (p.email || '').trim().toLowerCase()) return true;
          return p.name.trim().toLowerCase() === existing.fullName.trim().toLowerCase();
        };

        const inPlayerList = playerEntries.some(matchesPlayer);
        const inLeaderList = leaderEntries.some(matchesPlayer);

        let updatedRoles = [...existingRoles];
        if (inPlayerList && !updatedRoles.includes('player')) {
          updatedRoles.push('player');
        }
        if (!inPlayerList && updatedRoles.includes('player') && inLeaderList) {
          updatedRoles = updatedRoles.filter(r => r !== 'player');
        }
        if (inLeaderList && !updatedRoles.includes('coach')) {
          updatedRoles.push('coach');
        }
        if (!inLeaderList && (updatedRoles.includes('coach') || updatedRoles.includes('admin')) && inPlayerList) {
          updatedRoles = updatedRoles.filter(r => r !== 'coach');
        }

        if (updatedRoles.length === 0) {
          updatedRoles = [player.role === 'leader' ? 'coach' : 'player'];
        }

        const updatedTeams = Array.from(new Set([...existingTeams, teamId]));
        const targetPhoto = player.photoUrl || existing.photoUrl;

        const hasChanged = 
          updatedRoles.length !== existingRoles.length ||
          updatedRoles.some(r => !existingRoles.includes(r)) ||
          updatedTeams.length !== existingTeams.length ||
          existing.fullName !== cleanName ||
          (player.phone && existing.phone !== player.phone) ||
          (player.personnummer && existing.personnummer !== player.personnummer) ||
          (player.position && existing.position !== player.position) ||
          (player.number && existing.number !== player.number) ||
          (player.photoUrl && existing.photoUrl !== player.photoUrl) ||
          (cleanEmail && (existing.email || '').trim().toLowerCase() !== cleanEmail);

        if (hasChanged) {
          members[idx] = {
            ...existing,
            fullName: cleanName,
            email: player.email || existing.email || '',
            phone: player.phone || existing.phone,
            personnummer: player.personnummer || existing.personnummer,
            position: player.position || existing.position,
            number: player.number || existing.number,
            photoUrl: targetPhoto,
            roles: updatedRoles,
            teams: updatedTeams
          };
          isModified = true;
        }
      } else {
        const targetRole: 'coach' | 'player' = player.role === 'leader' ? 'coach' : 'player';
        const newMember: ClubMember = {
          userId: basePlayerId || 'player_' + Math.random().toString(36).substring(2, 10),
          email: player.email || '',
          fullName: cleanName,
          phone: player.phone || undefined,
          personnummer: player.personnummer || undefined,
          position: player.position || undefined,
          number: player.number || undefined,
          photoUrl: player.photoUrl || undefined,
          roles: [targetRole],
          teams: [teamId]
        };
        members.push(newMember);
        isModified = true;
      }
    }

    if (isModified) {
      await setDoc(membersRef, { members, updatedAt: Date.now() });
    }
  } catch (err) {
    console.error('Failed to sync squad to club members:', err);
  }
}

/**
 * Scans all team squads in a club and syncs their player photos, roles, and details
 * into the club's global members document.
 */
export async function syncAllTeamSquadsToClubMembers(
  clubId: string,
  teamIds: string[]
): Promise<ClubMember[]> {
  if (!clubId) return [];
  try {
    const membersRef = doc(db, 'clubs', clubId, 'teams', 'club_global', 'data', 'members');
    const membersSnap = await getDoc(membersRef);
    let members: ClubMember[] = membersSnap.exists() ? (membersSnap.data().members || []) : [];
    members = deduplicateClubMembers(members);

    let isModified = false;

    if (teamIds && teamIds.length > 0) {
      for (const teamId of teamIds) {
        try {
          const squadRef = doc(db, 'clubs', clubId, 'teams', teamId, 'data', 'squad');
          const squadSnap = await getDoc(squadRef);
          if (!squadSnap.exists()) continue;

          const squad: SquadPlayer[] = squadSnap.data().squad || [];
          for (const sp of squad) {
            if (!sp.name || !sp.name.trim()) continue;
            const cleanName = sp.name.trim();
            const cleanEmail = (sp.email || '').trim().toLowerCase();
            const cleanPnr = (sp.personnummer || '').replace(/\D/g, '');
            const cleanNum = (sp.number || '').trim();
            const targetRole: 'coach' | 'player' = sp.role === 'leader' ? 'coach' : 'player';

            const idx = members.findIndex(m => {
              const mEmail = (m.email || '').trim().toLowerCase();
              const mName = (m.fullName || '').trim().toLowerCase();
              const mPnr = (m.personnummer || '').replace(/\D/g, '');
              const mNum = (m.number || '').trim();

              if (sp.id && (m.userId === sp.id || m.userId === sp.id.replace('_leader', ''))) return true;
              if (cleanPnr && mPnr && cleanPnr === mPnr) return true;
              if (cleanEmail && mEmail === cleanEmail) return true;

              if (mName === cleanName.toLowerCase()) {
                if (cleanNum && mNum) return cleanNum === mNum;
                return true;
              }
              return false;
            });

            if (idx !== -1) {
              const existing = members[idx];
              const updatedRoles = Array.from(new Set([...(existing.roles || []), targetRole]));
              const updatedTeams = Array.from(new Set([...(existing.teams || []), teamId]));
              const targetPhoto = sp.photoUrl || existing.photoUrl;

              const hasChanged = 
                updatedRoles.length !== (existing.roles || []).length ||
                updatedTeams.length !== (existing.teams || []).length ||
                (sp.photoUrl && existing.photoUrl !== sp.photoUrl) ||
                (sp.phone && existing.phone !== sp.phone) ||
                (sp.personnummer && existing.personnummer !== sp.personnummer) ||
                (sp.position && existing.position !== sp.position) ||
                (sp.number && existing.number !== sp.number);

              if (hasChanged) {
                members[idx] = {
                  ...existing,
                  fullName: existing.fullName || cleanName,
                  email: sp.email || existing.email || '',
                  phone: sp.phone || existing.phone,
                  personnummer: sp.personnummer || existing.personnummer,
                  position: sp.position || existing.position,
                  number: sp.number || existing.number,
                  photoUrl: targetPhoto,
                  roles: updatedRoles,
                  teams: updatedTeams
                };
                isModified = true;
              }
            } else {
              const newMember: ClubMember = {
                userId: sp.id ? sp.id.replace('_leader', '') : 'player_' + Math.random().toString(36).substring(2, 10),
                email: sp.email || '',
                fullName: cleanName,
                phone: sp.phone || undefined,
                personnummer: sp.personnummer || undefined,
                position: sp.position || undefined,
                number: sp.number || undefined,
                photoUrl: sp.photoUrl || undefined,
                roles: [targetRole],
                teams: [teamId]
              };
              members.push(newMember);
              isModified = true;
            }
          }
        } catch (e) {
          console.error(`Failed syncing squad for team ${teamId}:`, e);
        }
      }
    }

    if (isModified) {
      await setDoc(membersRef, { members, updatedAt: Date.now() });
    }

    return members;
  } catch (err) {
    console.error('Failed to sync all team squads to club members:', err);
    return [];
  }
}

/**
 * Fetches club members for a team and merges any members with role player/coach/admin
 * into the team's squad list if they aren't in squad yet. Also pushes any missing
 * squad players into the club members list.
 */
export async function getMergedSquadAndClubMembers(
  squad: SquadPlayer[],
  clubId: string,
  teamId: string
): Promise<{ mergedSquad: SquadPlayer[]; hasChanges: boolean }> {
  const cleanInputSquad = deduplicateSquad(squad);
  if (!clubId || !teamId) return { mergedSquad: cleanInputSquad, hasChanges: cleanInputSquad.length !== squad.length };

  try {
    const membersRef = doc(db, 'clubs', clubId, 'teams', 'club_global', 'data', 'members');
    const membersSnap = await getDoc(membersRef);
    if (!membersSnap.exists()) {
      if (cleanInputSquad && cleanInputSquad.length > 0) {
        await syncSquadToClubMembers(cleanInputSquad, clubId, teamId);
      }
      return { mergedSquad: cleanInputSquad, hasChanges: cleanInputSquad.length !== squad.length };
    }

    let members: ClubMember[] = membersSnap.data().members || [];
    members = deduplicateClubMembers(members);
    const teamMembers = members.filter(m => !m.teams || m.teams.length === 0 || m.teams.includes(teamId) || (m.roles && (m.roles.includes('admin') || m.roles.includes('coach'))));

    let updatedSquad = [...cleanInputSquad];

    for (const member of teamMembers) {
      if (!member.fullName) continue;
      const cleanName = member.fullName.trim();
      const cleanEmail = (member.email || '').trim().toLowerCase();
      const cleanPnr = (member.personnummer || '').replace(/\D/g, '');
      const cleanNum = (member.number || '').trim();
      const memberUserId = member.userId;

      const hasPlayerRole = member.roles?.includes('player') || !member.roles?.some(r => r === 'coach' || r === 'admin');
      const hasLeaderRole = member.roles?.some(r => r === 'coach' || r === 'admin');

      const findSquadIdx = (targetRole: 'player' | 'leader') => {
        return updatedSquad.findIndex(sp => {
          if (sp.role !== targetRole) return false;
          const baseSpId = (sp.id || '').replace('_leader', '');
          const spEmail = (sp.email || '').trim().toLowerCase();
          const spName = (sp.name || '').trim().toLowerCase();
          const spPnr = (sp.personnummer || '').replace(/\D/g, '');
          const spNum = (sp.number || '').trim();

          if (memberUserId && (sp.id === memberUserId || baseSpId === memberUserId)) return true;
          if (cleanPnr && spPnr && cleanPnr === spPnr) return true;
          if (cleanEmail && spEmail === cleanEmail) return true;

          if (spName === cleanName.toLowerCase()) {
            if (cleanNum && spNum) {
              return cleanNum === spNum;
            }
            return true;
          }
          return false;
        });
      };

      if (hasPlayerRole) {
        const playerIdx = findSquadIdx('player');
        if (playerIdx === -1) {
          const newSquadPlayer: SquadPlayer = {
            id: memberUserId || crypto.randomUUID(),
            name: cleanName,
            email: member.email || undefined,
            phone: member.phone || undefined,
            personnummer: member.personnummer || undefined,
            position: member.position || undefined,
            number: member.number || undefined,
            photoUrl: member.photoUrl || undefined,
            role: 'player',
            roles: member.roles || ['player']
          };
          updatedSquad.push(newSquadPlayer);
        } else {
          const existingSp = updatedSquad[playerIdx];
          const mergedRoles = Array.from(new Set([...(existingSp.roles || []), ...(member.roles || [])]));
          updatedSquad[playerIdx] = {
            ...existingSp,
            email: member.email || existingSp.email,
            phone: member.phone || existingSp.phone,
            personnummer: member.personnummer || existingSp.personnummer,
            position: member.position || existingSp.position,
            number: member.number || existingSp.number,
            photoUrl: member.photoUrl || existingSp.photoUrl,
            role: 'player',
            roles: mergedRoles
          };
        }
      }

      if (hasLeaderRole) {
        const leaderIdx = findSquadIdx('leader');
        if (leaderIdx === -1) {
          const newSquadLeader: SquadPlayer = {
            id: memberUserId ? `${memberUserId}_leader` : crypto.randomUUID(),
            name: cleanName,
            email: member.email || undefined,
            phone: member.phone || undefined,
            personnummer: member.personnummer || undefined,
            position: member.position || undefined,
            number: member.number || undefined,
            photoUrl: member.photoUrl || undefined,
            role: 'leader',
            roles: member.roles || ['coach']
          };
          updatedSquad.push(newSquadLeader);
        } else {
          const existingSp = updatedSquad[leaderIdx];
          const mergedRoles = Array.from(new Set([...(existingSp.roles || []), ...(member.roles || [])]));
          updatedSquad[leaderIdx] = {
            ...existingSp,
            email: member.email || existingSp.email,
            phone: member.phone || existingSp.phone,
            personnummer: member.personnummer || existingSp.personnummer,
            position: member.position || existingSp.position,
            number: member.number || existingSp.number,
            photoUrl: member.photoUrl || existingSp.photoUrl,
            role: 'leader',
            roles: mergedRoles
          };
        }
      }
    }

    const finalMergedSquad = deduplicateSquad(updatedSquad);
    const hasChanges = JSON.stringify(finalMergedSquad) !== JSON.stringify(squad);

    const needsSyncToMembers = finalMergedSquad.some(sp => {
      if (!sp.name) return false;
      const spEmail = (sp.email || '').trim().toLowerCase();
      const spName = (sp.name || '').trim().toLowerCase();
      const spPnr = (sp.personnummer || '').replace(/\D/g, '');
      const spNum = (sp.number || '').trim();
      const baseSpId = (sp.id || '').replace('_leader', '');

      const m = members.find(mem => {
        const mEmail = (mem.email || '').trim().toLowerCase();
        const mName = (mem.fullName || '').trim().toLowerCase();
        const mPnr = (mem.personnummer || '').replace(/\D/g, '');
        const mNum = (mem.number || '').trim();

        if (sp.id && (mem.userId === sp.id || mem.userId === baseSpId)) return true;
        if (spPnr && mPnr && spPnr === mPnr) return true;
        if (spEmail && mEmail === spEmail) return true;

        if (spName === mName.toLowerCase()) {
          if (spNum && mNum) return spNum === mNum;
          return true;
        }
        return false;
      });

      if (!m) return true;
      if (sp.photoUrl && m.photoUrl !== sp.photoUrl) return true;
      if (sp.phone && m.phone !== sp.phone) return true;
      if (sp.personnummer && m.personnummer !== sp.personnummer) return true;
      if (sp.position && m.position !== sp.position) return true;
      if (sp.number && m.number !== sp.number) return true;
      return false;
    });

    if (needsSyncToMembers) {
      await syncSquadToClubMembers(finalMergedSquad, clubId, teamId);
    }

    return { mergedSquad: finalMergedSquad, hasChanges };
  } catch (err) {
    console.error('Failed to merge squad with club members:', err);
    return { mergedSquad: deduplicateSquad(squad), hasChanges: false };
  }
}


