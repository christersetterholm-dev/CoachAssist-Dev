export interface User {
  uid: string;
  email: string | null;
  username?: string | null;
  displayName: string | null;
  photoURL: string | null;
  emailVerified: boolean;
  isAnonymous: boolean;
  tenantId: string | null;
  providerData: any[];
  googleLinked?: boolean;
  googleEmail?: string | null;
  hasPassword?: boolean;
}

export const getApiUrl = (path: string): string => {
  if (!path || path.startsWith('http://') || path.startsWith('https://') || path.startsWith('data:') || path.startsWith('blob:')) {
    return path;
  }

  // Allow overriding via environment variable
  const apiBase = (import.meta as any).env?.VITE_API_URL || '';
  if (apiBase) {
    const cleanBase = apiBase.endsWith('/') ? apiBase.slice(0, -1) : apiBase;
    const cleanPath = path.startsWith('/') ? path : '/' + path;
    return cleanBase + cleanPath;
  }

  const pathname = window.location.pathname;
  const cleanPath = path.startsWith('/') ? path : '/' + path;
  
  // Dynamically detect if we are hosted under a subfolder
  // If pathname is not "/" and has segments, the first segment can be our subfolder
  const segments = pathname.split('/').filter(Boolean);
  if (segments.length > 0 && segments[0] !== 'api' && segments[0] !== 'uploads') {
    return '/' + segments[0] + cleanPath;
  }
  
  return cleanPath;
};

export const auth: any = {
  currentUser: null as User | null
};

export const db: any = {};
export const storage: any = {};
export const googleProvider: any = {};

export class GoogleAuthProvider {}

export const initializeApp = () => ({});
export const getAuth = () => auth;
export const initializeFirestore = () => db;
export const getStorage = () => storage;
export const signInWithPopup = () => {};

// Manage Auth State Change Listeners
const listeners: ((user: User | null) => void)[] = [];

export const onAuthStateChanged = (_authObj: any, callback: (user: User | null) => void) => {
  listeners.push(callback);
  // Trigger callback immediately with current state
  callback(auth.currentUser);
  return () => {
    const idx = listeners.indexOf(callback);
    if (idx !== -1) listeners.splice(idx, 1);
  };
};

export const signOut = async (_authObj: any) => {
  localStorage.removeItem('token');
  localStorage.removeItem('cached_auth_user');
  auth.currentUser = null;
  listeners.forEach(cb => cb(null));
};

// Google Identity Services (GSI) Client Loader
let gsiScriptLoaded: Promise<void> | null = null;

export const loadGsiClient = (): Promise<void> => {
  if (gsiScriptLoaded) return gsiScriptLoaded;
  gsiScriptLoaded = new Promise<void>((resolve, reject) => {
    if (typeof (window as any).google !== 'undefined' && (window as any).google?.accounts?.oauth2) {
      resolve();
      return;
    }
    const existing = document.querySelector('script[src="https://accounts.google.com/gsi/client"]');
    if (existing) {
      existing.addEventListener('load', () => resolve());
      existing.addEventListener('error', (e) => reject(new Error('Kunde inte ladda Google Identity Services: ' + e)));
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    script.onload = () => resolve();
    script.onerror = (e) => reject(new Error('Kunde inte ladda Google Identity Services: ' + e));
    document.head.appendChild(script);
  });
  return gsiScriptLoaded;
};

// Retrieve Google OAuth Client ID from env or backend config
export const getGoogleClientId = async (): Promise<string> => {
  const envId = (import.meta as any).env?.VITE_GOOGLE_CLIENT_ID;
  if (envId) return envId;
  try {
    const res = await fetch(getApiUrl('/api/auth/config'));
    if (res.ok) {
      const data = await res.json();
      if (data && data.googleClientId) return data.googleClientId;
    }
  } catch (_) {}
  return '';
};

// Trigger Google OAuth 2.0 Token Popup
export const triggerGoogleAuth = async (forceSelect = false): Promise<{ accessToken: string }> => {
  await loadGsiClient();
  const clientId = await getGoogleClientId();
  if (!clientId) {
    throw new Error('Google-inloggning kräver ett Google OAuth Client ID. Lägg till VITE_GOOGLE_CLIENT_ID (eller GOOGLE_CLIENT_ID) i miljövariablerna (.env).');
  }

  return new Promise((resolve, reject) => {
    try {
      const client = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: clientId,
        scope: 'email profile openid',
        callback: (response: any) => {
          if (response && response.access_token) {
            resolve({ accessToken: response.access_token });
          } else if (response && response.error) {
            reject(new Error(`Google-inloggning avbröts: ${response.error_description || response.error}`));
          } else {
            reject(new Error('Google returnerade ingen giltig token.'));
          }
        },
        error_callback: (err: any) => {
          reject(new Error(err?.message || 'Google OAuth-fönstret misslyckades eller blockerades.'));
        }
      });
      if (forceSelect) {
        client.requestAccessToken({ prompt: 'select_account' });
      } else {
        client.requestAccessToken();
      }
    } catch (err: any) {
      reject(new Error('Kunde inte starta Google-inloggning: ' + (err.message || err)));
    }
  });
};

// Refresh current user session from /api/auth/me
export const refreshCurrentUser = async (): Promise<User | null> => {
  const token = localStorage.getItem('token');
  if (!token) return null;
  try {
    const res = await fetch(getApiUrl('/api/auth/me'), {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (res.ok) {
      const user = await res.json();
      auth.currentUser = user;
      localStorage.setItem('cached_auth_user', JSON.stringify(user));
      listeners.forEach(cb => cb(user));
      return user;
    }
  } catch (e) {
    console.error('Error refreshing current user:', e);
  }
  return auth.currentUser;
};

// Link Google Account to current logged-in user
export const linkGoogleAccount = async (forceSelect = true): Promise<{ success: boolean; googleEmail?: string; message?: string }> => {
  const token = localStorage.getItem('token');
  if (!token) {
    throw new Error('Du måste vara inloggad för att koppla ett konto.');
  }

  const { accessToken } = await triggerGoogleAuth(forceSelect);
  const res = await fetch(getApiUrl('/api/auth/link-google'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ accessToken })
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Kunde inte koppla Google-konto.');
  }

  await refreshCurrentUser();
  return data;
};

// Unlink Google Account from current logged-in user
export const unlinkGoogleAccount = async (): Promise<{ success: boolean; message: string }> => {
  const token = localStorage.getItem('token');
  if (!token) {
    throw new Error('Du måste vara inloggad för att koppla bort ett konto.');
  }

  const res = await fetch(getApiUrl('/api/auth/unlink-google'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    }
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Kunde inte koppla bort Google-konto.');
  }

  await refreshCurrentUser();
  return data;
};

// Programmatic Modal Sign-In with Email, Username, or Google
export const signInWithGoogle = async (_forceSelect = false): Promise<User> => {
  return new Promise<User>((resolve, reject) => {
    if (document.getElementById('custom-auth-modal')) {
      return;
    }

    const isDark = document.documentElement.classList.contains('dark');

    const modal = document.createElement('div');
    modal.id = 'custom-auth-modal';
    modal.className = 'fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300';

    modal.innerHTML = `
      <div class="w-full max-w-md bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl shadow-2xl p-8 transform transition-all scale-95 opacity-0 duration-300 flex flex-col gap-6 font-sans">
        <div class="flex justify-between items-center">
          <div class="flex items-center gap-2">
            <div class="p-2 bg-indigo-50 dark:bg-zinc-800 rounded-xl text-indigo-600 dark:text-indigo-400">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
            <h2 class="text-xl font-black text-zinc-900 dark:text-white uppercase tracking-wide">CoachAssist</h2>
          </div>
          <button id="auth-close-btn" class="p-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
          </button>
        </div>

        <div class="flex flex-col gap-1">
          <h3 id="auth-title" class="text-lg font-bold text-zinc-850 dark:text-zinc-100">Logga in till ditt konto</h3>
          <p id="auth-subtitle" class="text-xs text-zinc-500 dark:text-zinc-400">Logga in med Google eller ange dina inloggningsuppgifter.</p>
        </div>

        <!-- Google Login Button Section -->
        <div id="auth-google-container" class="space-y-3">
          <button type="button" id="auth-google-btn" class="w-full bg-white hover:bg-zinc-50 dark:bg-zinc-800 dark:hover:bg-zinc-750 text-zinc-700 dark:text-zinc-200 border border-zinc-300 dark:border-zinc-700 font-bold py-3.5 px-4 rounded-xl text-sm transition-all shadow-sm flex items-center justify-center gap-3 cursor-pointer hover:shadow">
            <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
            </svg>
            <span id="auth-google-btn-text">Fortsätt med Google</span>
          </button>

          <div id="auth-divider" class="relative flex items-center justify-center my-1">
            <div class="border-t border-zinc-200 dark:border-zinc-800 w-full"></div>
            <span class="bg-white dark:bg-zinc-900 px-3 text-xs text-zinc-400 dark:text-zinc-500 font-medium whitespace-nowrap">eller med uppgifter</span>
            <div class="border-t border-zinc-200 dark:border-zinc-800 w-full"></div>
          </div>
        </div>

        <form id="auth-form" class="space-y-4">
          <div id="auth-username-container" class="hidden">
            <label class="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5" for="auth-username">Användarnamn (rekommenderas)</label>
            <input type="text" id="auth-username" autocapitalize="none" autocorrect="off" spellcheck="false" class="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-sm text-zinc-800 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-500 transition-colors" placeholder="tränare123" />
            <p class="text-[11px] text-zinc-400 dark:text-zinc-500 mt-1">Gör det lättare att logga in om du ändrar din e-postadress.</p>
          </div>

          <div id="auth-email-container">
            <label id="auth-email-label" class="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5" for="auth-email">E-postadress eller användarnamn</label>
            <input type="text" id="auth-email" required autocapitalize="none" autocorrect="off" spellcheck="false" class="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-sm text-zinc-800 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-500 transition-colors" placeholder="coach@lag.se eller användarnamn" />
          </div>

          <div id="auth-code-container" class="hidden">
            <label class="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5" for="auth-code">6-siffrig verifieringskod</label>
            <input type="text" id="auth-code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocapitalize="none" autocorrect="off" spellcheck="false" class="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-center text-xl font-mono font-bold tracking-widest text-indigo-600 dark:text-indigo-400 placeholder-zinc-400 focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-500 transition-colors" placeholder="123456" autocomplete="one-time-code" />
          </div>

          <div id="auth-password-container">
            <div class="flex items-center justify-between mb-1.5">
              <label id="auth-password-label" class="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider" for="auth-password">Lösenord</label>
              <button type="button" id="auth-forgot-btn" class="text-xs text-indigo-500 hover:text-indigo-600 dark:text-indigo-400 underline font-medium transition-colors">Glömt lösenord?</button>
            </div>
            <div class="relative">
              <input type="password" id="auth-password" required autocapitalize="none" autocorrect="off" spellcheck="false" class="w-full pl-4 pr-10 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-sm text-zinc-800 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:border-indigo-500 dark:focus:border-indigo-500 transition-colors" placeholder="••••••••" minlength="6" />
              <button type="button" id="auth-toggle-pwd" class="absolute right-3 top-3 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors p-0.5 rounded-lg focus:outline-none" title="Visa/dölj lösenord">
                <svg id="pwd-eye-icon" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
              </button>
            </div>
          </div>

          <div id="auth-info" class="hidden text-xs font-medium text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/40 px-3.5 py-2.5 rounded-xl"></div>
          <div id="auth-error" class="hidden text-xs font-medium text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/30 px-3.5 py-2.5 rounded-xl"></div>

          <button type="submit" id="auth-submit-btn" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3.5 px-4 rounded-xl text-sm transition-colors shadow-lg shadow-indigo-100 dark:shadow-none flex items-center justify-center gap-2 cursor-pointer">
            <span>Logga in</span>
          </button>
        </form>

        <div class="flex items-center justify-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
          <span id="auth-switch-text">Har du inget konto?</span>
          <button id="auth-switch-btn" class="font-bold text-indigo-500 hover:text-indigo-600 dark:text-indigo-400 dark:hover:text-indigo-300 underline transition-colors cursor-pointer">Skapa konto</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    if (isDark) {
      modal.classList.add('dark');
    }

    setTimeout(() => {
      const card = modal.querySelector('div') as HTMLElement;
      if (card) {
        card.classList.remove('scale-95', 'opacity-0');
        card.classList.add('scale-100', 'opacity-100');
      }
    }, 10);

    let authMode: 'login' | 'register' | 'request-reset' | 'verify-reset' = 'login';

    const closeBtn = modal.querySelector('#auth-close-btn') as HTMLButtonElement;
    const switchBtn = modal.querySelector('#auth-switch-btn') as HTMLButtonElement;
    const forgotBtn = modal.querySelector('#auth-forgot-btn') as HTMLButtonElement;
    const googleBtn = modal.querySelector('#auth-google-btn') as HTMLButtonElement;
    const googleContainer = modal.querySelector('#auth-google-container') as HTMLElement;
    const form = modal.querySelector('#auth-form') as HTMLFormElement;
    const errorDiv = modal.querySelector('#auth-error') as HTMLDivElement;
    const infoDiv = modal.querySelector('#auth-info') as HTMLDivElement;
    const submitBtn = modal.querySelector('#auth-submit-btn') as HTMLButtonElement;
    const title = modal.querySelector('#auth-title') as HTMLElement;
    const subtitle = modal.querySelector('#auth-subtitle') as HTMLElement;
    const switchText = modal.querySelector('#auth-switch-text') as HTMLElement;
    const passwordLabel = modal.querySelector('#auth-password-label') as HTMLElement;
    const emailLabel = modal.querySelector('#auth-email-label') as HTMLElement;
    const emailInput = modal.querySelector('#auth-email') as HTMLInputElement;
    const usernameInput = modal.querySelector('#auth-username') as HTMLInputElement;
    const usernameContainer = modal.querySelector('#auth-username-container') as HTMLElement;
    const codeInput = modal.querySelector('#auth-code') as HTMLInputElement;
    const passwordInput = modal.querySelector('#auth-password') as HTMLInputElement;
    const togglePwdBtn = modal.querySelector('#auth-toggle-pwd') as HTMLButtonElement;

    if (togglePwdBtn && passwordInput) {
      togglePwdBtn.onclick = () => {
        const isPwd = passwordInput.type === 'password';
        passwordInput.type = isPwd ? 'text' : 'password';
        togglePwdBtn.innerHTML = isPwd
          ? `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.52 13.52 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" x2="22" y1="2" y2="22"/></svg>`
          : `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>`;
      };
    }

    const emailContainer = modal.querySelector('#auth-email-container') as HTMLElement;
    const codeContainer = modal.querySelector('#auth-code-container') as HTMLElement;
    const passwordContainer = modal.querySelector('#auth-password-container') as HTMLElement;

    const cleanUpModal = () => {
      const card = modal.querySelector('div') as HTMLElement;
      if (card) {
        card.classList.add('scale-95', 'opacity-0');
      }
      setTimeout(() => {
        if (modal.parentNode) {
          modal.parentNode.removeChild(modal);
        }
      }, 300);
    };

    closeBtn.onclick = () => {
      cleanUpModal();
      reject(new Error('Inloggningen avbröts av användaren'));
    };

    if (googleBtn) {
      googleBtn.onclick = async () => {
        errorDiv.classList.add('hidden');
        infoDiv.classList.add('hidden');
        googleBtn.disabled = true;
        googleBtn.classList.add('opacity-70');
        try {
          const { accessToken } = await triggerGoogleAuth(_forceSelect);
          const url = getApiUrl('/api/auth/google');
          const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ accessToken })
          });
          const resData = await response.json();
          if (!response.ok) {
            throw new Error(resData.error || 'Google-inloggningen misslyckades.');
          }

          localStorage.setItem('token', resData.token);
          if (resData.user) {
            localStorage.setItem('cached_auth_user', JSON.stringify(resData.user));
          }
          auth.currentUser = resData.user;
          listeners.forEach(cb => cb(resData.user));

          cleanUpModal();
          resolve(resData.user);
        } catch (err: any) {
          errorDiv.innerText = err.message || 'Kunde inte logga in med Google';
          errorDiv.classList.remove('hidden');
        } finally {
          googleBtn.disabled = false;
          googleBtn.classList.remove('opacity-70');
        }
      };
    }

    const updateAuthUI = () => {
      errorDiv.classList.add('hidden');
      infoDiv.classList.add('hidden');

      if (authMode === 'register') {
        title.innerText = 'Skapa nytt konto';
        subtitle.innerText = 'Skapa ett konto med Google eller e-post för att spara din trupp och ansluta till lag.';
        passwordLabel.innerText = 'Lösenord';
        if (emailLabel) emailLabel.innerText = 'E-postadress';
        if (emailInput) emailInput.placeholder = 'coach@lag.se';
        googleContainer.classList.remove('hidden');
        usernameContainer.classList.remove('hidden');
        emailContainer.classList.remove('hidden');
        codeContainer.classList.add('hidden');
        passwordContainer.classList.remove('hidden');
        forgotBtn.classList.add('hidden');
        passwordInput.required = true;
        codeInput.required = false;
        submitBtn.querySelector('span')!.innerText = 'Skapa konto';
        switchText.innerText = 'Har du redan ett konto?';
        switchBtn.innerText = 'Logga in';
      } else if (authMode === 'request-reset') {
        title.innerText = 'Återställ lösenord';
        subtitle.innerText = 'Ange din e-postadress för att få en 6-siffrig verifieringskod.';
        if (emailLabel) emailLabel.innerText = 'E-postadress';
        if (emailInput) emailInput.placeholder = 'coach@lag.se';
        googleContainer.classList.add('hidden');
        usernameContainer.classList.add('hidden');
        emailContainer.classList.remove('hidden');
        codeContainer.classList.add('hidden');
        passwordContainer.classList.add('hidden');
        forgotBtn.classList.add('hidden');
        passwordInput.required = false;
        codeInput.required = false;
        submitBtn.querySelector('span')!.innerText = 'Skicka verifieringskod';
        switchText.innerText = 'Kom du ihåg ditt lösenord?';
        switchBtn.innerText = 'Logga in';
      } else if (authMode === 'verify-reset') {
        title.innerText = 'Mata in verifieringskod';
        subtitle.innerText = 'Ange den 6-siffriga koden vi skickat samt ditt nya lösenord.';
        passwordLabel.innerText = 'Nytt lösenord';
        if (emailLabel) emailLabel.innerText = 'E-postadress';
        if (emailInput) emailInput.placeholder = 'coach@lag.se';
        googleContainer.classList.add('hidden');
        usernameContainer.classList.add('hidden');
        emailContainer.classList.remove('hidden');
        codeContainer.classList.remove('hidden');
        passwordContainer.classList.remove('hidden');
        forgotBtn.classList.add('hidden');
        passwordInput.required = true;
        codeInput.required = true;
        submitBtn.querySelector('span')!.innerText = 'Återställ & logga in';
        switchText.innerText = 'Vill du börja om?';
        switchBtn.innerText = 'Tillbaka till inloggning';
      } else {
        title.innerText = 'Logga in till ditt konto';
        subtitle.innerText = 'Logga in med Google, e-post eller användarnamn.';
        passwordLabel.innerText = 'Lösenord';
        if (emailLabel) emailLabel.innerText = 'E-postadress eller användarnamn';
        if (emailInput) emailInput.placeholder = 'coach@lag.se eller användarnamn';
        googleContainer.classList.remove('hidden');
        usernameContainer.classList.add('hidden');
        emailContainer.classList.remove('hidden');
        codeContainer.classList.add('hidden');
        passwordContainer.classList.remove('hidden');
        forgotBtn.classList.remove('hidden');
        passwordInput.required = true;
        codeInput.required = false;
        submitBtn.querySelector('span')!.innerText = 'Logga in';
        switchText.innerText = 'Har du inget konto?';
        switchBtn.innerText = 'Skapa konto';
        switchBtn.classList.remove('hidden');
      }
    };

    forgotBtn.onclick = (e) => {
      e.preventDefault();
      authMode = 'request-reset';
      updateAuthUI();
    };

    switchBtn.onclick = (e) => {
      e.preventDefault();
      if (authMode === 'login') {
        authMode = 'register';
      } else {
        authMode = 'login';
      }
      updateAuthUI();
    };

    form.onsubmit = async (e) => {
      e.preventDefault();
      const email = emailInput.value.trim();
      const username = usernameInput ? usernameInput.value.trim() : '';
      const password = passwordInput.value;
      const code = codeInput.value.trim();

      errorDiv.classList.add('hidden');
      infoDiv.classList.add('hidden');
      submitBtn.disabled = true;
      submitBtn.classList.add('opacity-70');

      try {
        if (authMode === 'request-reset') {
          const url = getApiUrl('/api/auth/request-reset');
          const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email })
          });
          const resData = await response.json();
          if (!response.ok) {
            throw new Error(resData.error || 'Begäran om återställning misslyckades.');
          }

          if (resData.code) {
            codeInput.value = resData.code;
          }

          infoDiv.innerText = resData.message || 'Verifieringskod har skickats till din e-postadress.';
          infoDiv.classList.remove('hidden');
          authMode = 'verify-reset';
          updateAuthUI();
          if (resData.code) {
            codeInput.value = resData.code;
          }
          infoDiv.classList.remove('hidden');
          return;
        }

        let endpoint = '/api/auth/login';
        let bodyPayload: any = { identifier: email, email, password };

        if (authMode === 'register') {
          endpoint = '/api/auth/register';
          bodyPayload = { email, username, password };
        } else if (authMode === 'verify-reset') {
          endpoint = '/api/auth/reset-password';
          bodyPayload = { email, code, newPassword: password };
        }

        const url = getApiUrl(endpoint);
        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(bodyPayload)
        });

        const resData = await response.json();

        if (!response.ok) {
          if (response.status === 429 || resData.code === 'RESOURCE_EXHAUSTED' || (resData.error && resData.error.toLowerCase().includes('kvot'))) {
            const upUrl = resData.upgradeUrl || 'https://console.firebase.google.com/project/tuned-life-pmvz5/firestore/databases/ai-studio-remixcoachassist-3ac8f9c7-729f-4797-87b6-4c498370756c/data?openUpgradeDialog=true';
            errorDiv.innerHTML = `
              <div class="space-y-1">
                <p class="font-bold text-amber-300">Firebase dygnsgräns nådd (50 000 läsningar)</p>
                <p class="text-xs text-amber-100">${resData.error || 'Dina konton och data är säkra i molnet, men inloggningen är tillfälligt pausad tills kvoten nollställs imorgon.'}</p>
                <a href="${upUrl}" target="_blank" rel="noopener noreferrer" class="inline-block mt-1 text-xs text-amber-200 underline hover:text-white">Öppna Firebase Console för uppgradering &rarr;</a>
              </div>
            `;
            errorDiv.classList.remove('hidden');
            return;
          }
          throw new Error(resData.error || 'Åtgärden misslyckades');
        }

        localStorage.setItem('token', resData.token);
        if (resData.user) {
          localStorage.setItem('cached_auth_user', JSON.stringify(resData.user));
        }
        auth.currentUser = resData.user;
        listeners.forEach(cb => cb(resData.user));

        cleanUpModal();
        resolve(resData.user);
      } catch (err: any) {
        errorDiv.innerText = err.message || 'Ett fel uppstod';
        errorDiv.classList.remove('hidden');
      } finally {
        submitBtn.disabled = false;
        submitBtn.classList.remove('opacity-70');
      }
    };
  });
};

// On module load, restore login session from JWT if exists
const initializeSession = async () => {
  const token = localStorage.getItem('token');
  const cachedUserStr = localStorage.getItem('cached_auth_user');
  let cachedUser = null;
  if (cachedUserStr) {
    try {
      cachedUser = JSON.parse(cachedUserStr);
    } catch (_) {}
  }

  if (token) {
    try {
      const res = await fetch(getApiUrl('/api/auth/me'), {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (res.ok) {
        const user = await res.json();
        auth.currentUser = user;
        localStorage.setItem('cached_auth_user', JSON.stringify(user));
        listeners.forEach(cb => cb(user));
      } else if (res.status === 401 || res.status === 403) {
        localStorage.removeItem('token');
        localStorage.removeItem('cached_auth_user');
        listeners.forEach(cb => cb(null));
      } else {
        // Server returned 5xx or transient error - keep session using cached user if available
        if (cachedUser) {
          auth.currentUser = cachedUser;
          listeners.forEach(cb => cb(cachedUser));
        } else {
          listeners.forEach(cb => cb(null));
        }
      }
    } catch (e) {
      console.error('Failed to restore session on startup (network error):', e);
      if (cachedUser) {
        auth.currentUser = cachedUser;
        listeners.forEach(cb => cb(cachedUser));
      } else {
        listeners.forEach(cb => cb(null));
      }
    }
  } else {
    // Notify loaded with no user
    setTimeout(() => listeners.forEach(cb => cb(null)), 50);
  }
};
initializeSession();

// Helper for safe fetch with timeout to prevent hung promises
const fetchWithTimeout = async (url: string, options: RequestInit = {}, timeoutMs = 12000): Promise<Response> => {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      ...options,
      signal: options.signal || controller.signal
    });
    return res;
  } finally {
    clearTimeout(id);
  }
};

// Firestore Client-Side Emulation
export const doc = (_dbObj: any, ...parts: string[]) => {
  return { path: parts.join('/') };
};

export const getDoc = async (docRef: { path: string }, options?: { forceRefresh?: boolean }) => {
  const token = localStorage.getItem('token');
  const headers: Record<string, string> = {};
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  if (options?.forceRefresh) {
    headers['Cache-Control'] = 'no-cache';
    headers['Pragma'] = 'no-cache';
  }

  const queryParams = new URLSearchParams({ path: docRef.path });
  if (options?.forceRefresh) {
    queryParams.set('force', 'true');
    queryParams.set('refresh', 'true');
    queryParams.set('_t', Date.now().toString());
  }

  try {
    const res = await fetchWithTimeout(getApiUrl(`/api/docs?${queryParams.toString()}`), {
      headers
    }, 12000);

    if (!res.ok) {
      if (res.status === 429) {
        const errData = await res.json().catch(() => ({}));
        const quotaErr: any = new Error(errData.message || errData.error || "Quota exceeded for quota metric 'Free daily read units per project (free tier database)'");
        quotaErr.code = 'resource-exhausted';
        quotaErr.status = 429;
        quotaErr.upgradeUrl = errData.upgradeUrl;
        throw quotaErr;
      }
      if (res.status === 404 || res.status === 401 || res.status === 403) {
        return { exists: () => false, data: () => null };
      }
      return { exists: () => false, data: () => null };
    }

    const data = await res.json();
    return {
      exists: () => true,
      data: () => data
    };
  } catch (err: any) {
    if (err.status === 429 || err.code === 'resource-exhausted' || (err.message && err.message.toLowerCase().includes('quota'))) {
      throw err;
    }
    console.warn(`[getDoc] Could not load doc ${docRef.path}:`, err);
    return { exists: () => false, data: () => null };
  }
};

export const setDoc = async (docRef: { path: string }, data: any, _options?: { merge?: boolean }) => {
  const token = localStorage.getItem('token');
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetchWithTimeout(getApiUrl(`/api/docs?path=${encodeURIComponent(docRef.path)}`), {
    method: 'POST',
    headers,
    body: JSON.stringify({ data })
  }, 12000);

  if (!res.ok) {
    const errBody = await res.json().catch(() => ({}));
    throw new Error(errBody.error || `Failed to save doc (${res.status})`);
  }
};

export const deleteDoc = async (docRef: { path: string }) => {
  const token = localStorage.getItem('token');
  const headers: Record<string, string> = {};
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetchWithTimeout(getApiUrl(`/api/docs?path=${encodeURIComponent(docRef.path)}`), {
    method: 'DELETE',
    headers
  }, 12000);

  if (!res.ok && res.status !== 404) {
    throw new Error('Failed to delete doc');
  }
};

export const collection = (_dbObj: any, ...parts: string[]) => {
  return { path: parts.join('/') };
};

export const getDocs = async (collectionRef: { path: string }) => {
  const token = localStorage.getItem('token');
  const headers: Record<string, string> = {};
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const res = await fetchWithTimeout(getApiUrl(`/api/docs?path=${encodeURIComponent(collectionRef.path)}`), {
      headers
    }, 12000);

    if (!res.ok) {
      return { docs: [], size: 0, empty: true, forEach: () => {} };
    }

    const data = await res.json();
    const items = Array.isArray(data) ? data : (data.requests || data.items || []);
    const docs = items.map((item: any) => ({
      id: item.id || item.userId || item.email,
      exists: () => true,
      data: () => item
    }));

    return {
      docs,
      size: docs.length,
      empty: docs.length === 0,
      forEach: (cb: (doc: any) => void) => docs.forEach(cb)
    };
  } catch (err) {
    console.warn(`[getDocs] Could not load collection ${collectionRef.path}:`, err);
    return { docs: [], size: 0, empty: true, forEach: () => {} };
  }
};

// Simulated Firestore Live Polling Listener (onSnapshot)
export const onSnapshot = (docRef: { path: string }, callback: (snapshot: any) => void, _errorCallback?: (error: any) => void) => {
  let isStopped = false;
  let intervalId: any = null;
  
  const poll = async () => {
    if (isStopped) return;
    if (typeof document !== 'undefined' && document.hidden) return; // Skip if tab is hidden
    try {
      const snap = await getDoc(docRef, { forceRefresh: false });
      if (!isStopped) {
        callback({
          exists: () => snap.exists(),
          data: () => snap.data(),
          metadata: { hasPendingWrites: false }
        });
      }
    } catch (e: any) {
      console.warn("Snapshot polling notice for " + docRef.path + ":", e?.message || e);
      if (_errorCallback) {
        _errorCallback(e);
      }
      // If quota exceeded, don't spam polling
      const msg = (e?.message || String(e)).toLowerCase();
      if (e?.code === 'resource-exhausted' || msg.includes('quota')) {
        clearInterval(intervalId);
        // Retry gently in 5 minutes
        intervalId = setInterval(poll, 300000);
      }
    }
  };
  
  poll();
  intervalId = setInterval(poll, 60000); // 60 seconds interval instead of 8 seconds
  
  return () => {
    isStopped = true;
    if (intervalId) clearInterval(intervalId);
  };
};

// Storage Client-Side Emulation
export const ref = (_storageObj: any, path: string) => {
  return { path };
};

export const uploadBytes = async (storageRef: { path: string }, blob: Blob) => {
  const token = localStorage.getItem('token');
  const formData = new FormData();
  formData.append('file', blob);
  formData.append('path', storageRef.path);

  const headers: Record<string, string> = {};
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(getApiUrl('/api/upload'), {
    method: 'POST',
    headers,
    body: formData
  });

  if (!res.ok) {
    throw new Error('Failed to upload file');
  }

  const data = await res.json();
  return {
    ref: {
      path: storageRef.path,
      url: data.url
    }
  };
};

export const uploadBytesResumable = (storageRef: { path: string }, blob: Blob) => {
  const task = {
    snapshot: {
      ref: storageRef as any,
      bytesTransferred: 100,
      totalBytes: 100
    },
    on: (_event: string, next: (snap: any) => void, error: (err: any) => void, complete: () => void) => {
      uploadBytes(storageRef, blob)
        .then((result) => {
          task.snapshot.ref = result.ref as any;
          next({ bytesTransferred: 100, totalBytes: 100 });
          complete();
        })
        .catch((err) => {
          error(err);
        });
    },
    then: (onfulfilled: any) => {
      return uploadBytes(storageRef, blob).then(onfulfilled);
    }
  };
  return task;
};

export const getDownloadURL = async (refObj: any) => {
  if (refObj && refObj.url) {
    return refObj.url.startsWith('http') ? refObj.url : getApiUrl(refObj.url);
  }
  return getApiUrl(`/uploads/${refObj.path}`);
};

export const deleteObject = async (refObj: any) => {
  const token = localStorage.getItem('token');
  const headers: Record<string, string> = {};
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    await fetch(getApiUrl(`/api/delete-file?path=${encodeURIComponent(refObj.path)}`), {
      method: 'DELETE',
      headers
    });
  } catch (e) {
    console.error("Error deleting file:", e);
  }
};

// Existing Error Utilities (kept for full compatibility with original setup)
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.warn('Firestore Error logged: ', JSON.stringify(errInfo));
}
