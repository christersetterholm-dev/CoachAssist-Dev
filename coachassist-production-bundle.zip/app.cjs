// This file acts as the entry point for cPanel Node.js Selector / Phusion Passenger.
// It is written in CommonJS format (app.cjs) to prevent Phusion Passenger's loader 
// from crashing with ERR_REQUIRE_ESM when loading an ES module.
// It imports the bundled production server from the dist folder if it exists.
// Otherwise, it auto-restores from deploy/ or starts an automatic background build.

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const http = require('http');

const distDir = path.join(__dirname, 'dist');
const serverPath = path.join(distDir, 'server.cjs');
const deployServerPath = path.join(__dirname, 'deploy', 'server.cjs');
const deployIndexPath = path.join(__dirname, 'deploy', 'index.html');

// 1. If dist/server.cjs is missing but deploy/server.cjs exists, auto-restore immediately without needing a heavy build!
if (!fs.existsSync(serverPath) && fs.existsSync(deployServerPath)) {
  try {
    if (!fs.existsSync(distDir)) {
      fs.mkdirSync(distDir, { recursive: true });
    }
    fs.copyFileSync(deployServerPath, serverPath);
    if (fs.existsSync(deployIndexPath) && !fs.existsSync(path.join(distDir, 'index.html'))) {
      fs.copyFileSync(deployIndexPath, path.join(distDir, 'index.html'));
    }
    console.log('Restored dist/server.cjs and dist/index.html from deploy/ folder successfully.');
  } catch (restoreErr) {
    console.warn('Could not auto-restore from deploy/ folder:', restoreErr.message);
  }
}

if (fs.existsSync(serverPath)) {
  console.log('Production server found. Starting Coach Assist...');
  process.env.NODE_ENV = 'production'; // Force production mode

  // Ensure persistent database mode from db_mode_config.json is active
  if (!process.env.DATABASE_MODE) {
    const configPaths = [
      path.join(__dirname, 'db_mode_config.json'),
      path.join(__dirname, 'data', 'db_mode_config.json')
    ];
    for (const p of configPaths) {
      if (fs.existsSync(p)) {
        try {
          const cfg = JSON.parse(fs.readFileSync(p, 'utf8'));
          if (cfg && cfg.mode) {
            process.env.DATABASE_MODE = cfg.mode;
            console.log(`[Passenger] Initialized process.env.DATABASE_MODE = "${cfg.mode}" from ${p}`);
            break;
          }
        } catch (_) {}
      }
    }
  }

  try {
    require('./dist/server.cjs');
  } catch (startupErr) {
    console.error('CRITICAL: dist/server.cjs failed to start:', startupErr);
    try {
      fs.writeFileSync(path.join(__dirname, 'server-crash.log'), String(startupErr && startupErr.stack ? startupErr.stack : startupErr));
    } catch (_) {}

    // Start fallback diagnostic server so user can see exactly why it failed
    const http = require('http');
    const port = process.env.PORT || 3000;
    const server = http.createServer((req, res) => {
      res.writeHead(500, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(`<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>CoachAssist - Serverfel</title></head>
<body style="font-family:system-ui,sans-serif;background:#0f172a;color:#f8fafc;padding:40px;margin:0;">
  <div style="max-width:800px;margin:0 auto;background:#1e293b;border-radius:12px;padding:30px;border:1px solid #334155;">
    <h2 style="color:#f87171;margin-top:0;">⚠️ Serverfel vid uppstart av CoachAssist</h2>
    <p>Node.js försökte starta <code>dist/server.cjs</code> men stötte på ett fel:</p>
    <pre style="background:#090d16;padding:16px;border-radius:8px;color:#cbd5e1;overflow-x:auto;font-size:13px;line-height:1.5;">${startupErr && startupErr.stack ? startupErr.stack : startupErr}</pre>
    <div style="background:#064e3b;padding:16px;border-radius:8px;margin-top:20px;color:#a7f3d0;">
      <strong>Lösning:</strong><br/>
      Om felet nämner <em>"Cannot find module"</em>, gå till cPanel &rarr; <strong>Setup Node.js App</strong> och klicka på <strong>Run NPM Install</strong>.
    </div>
  </div>
</body>
</html>`);
    });

    if (typeof port === 'string' && isNaN(Number(port))) {
      server.listen(port);
    } else {
      server.listen(Number(port), '0.0.0.0');
    }
  }
} else {
  console.log('Production server bundle not found yet. Starting automatic background build and fallback server...');

  let buildStatus = 'idle'; // 'idle', 'building', 'success', 'failed'
  let buildLog = '';
  let buildError = '';

  const runBuild = () => {
    if (buildStatus === 'building') return;
    buildStatus = 'building';
    
    // Check if we need to run npm install first
    const hasVite = fs.existsSync(path.join(__dirname, 'node_modules', 'vite'));
    let needsInstall = !hasVite;

    // Check if all production dependencies exist in node_modules
    if (!needsInstall) {
      try {
        const pkgPath = path.join(__dirname, 'package.json');
        if (fs.existsSync(pkgPath)) {
          const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
          const deps = Object.keys(pkg.dependencies || {});
          for (const dep of deps) {
            if (!fs.existsSync(path.join(__dirname, 'node_modules', dep))) {
              console.log(`Missing dependency in node_modules: ${dep}. Triggering npm install first...`);
              buildLog += `Paketet "${dep}" saknas i node_modules. Kör npm install först...\n`;
              needsInstall = true;
              break;
            }
          }
        }
      } catch (e) {
        console.warn('Could not verify dependencies in package.json:', e);
      }
    }
    
    buildLog = '';
    
    // Dynamically resolve the Node.js binary directory of the virtual environment
    // Prepend it to process.env.PATH so that child processes find the same node/npm/npx
    const nodeBinDir = path.dirname(process.execPath);
    const customEnv = {
      ...process.env,
      PATH: nodeBinDir + (process.platform === 'win32' ? ';' : ':') + (process.env.PATH || ''),
      RAYON_NUM_THREADS: '1',
      UV_THREADPOOL_SIZE: '1',
      ESBUILD_WORKERS: '1'
    };

    const startBuildStep = () => {
      buildLog += 'Starting build process: npm run build...\n';
      console.log('Running build command...');
      
      const buildProcess = exec('npm run build', { 
        cwd: __dirname,
        env: customEnv
      });

      buildProcess.stdout.on('data', (data) => {
        buildLog += data.toString();
        console.log(data.toString());
      });

      buildProcess.stderr.on('data', (data) => {
        buildLog += data.toString();
        console.error(data.toString());
      });

      buildProcess.on('close', (code) => {
        if (code === 0) {
          buildStatus = 'success';
          buildLog += '\nBuild completed successfully!\n';
          console.log('Build succeeded! Touching tmp/restart.txt to restart Phusion Passenger...');
          
          try {
            const tmpDir = path.join(__dirname, 'tmp');
            if (!fs.existsSync(tmpDir)) {
              fs.mkdirSync(tmpDir);
            }
            fs.writeFileSync(path.join(tmpDir, 'restart.txt'), String(Date.now()));
            buildLog += 'Restart triggered successfully.\n';
          } catch (err) {
            console.error('Failed to touch tmp/restart.txt:', err);
            buildLog += `Failed to trigger automatic restart: ${err.message}\n`;
          }

          // Allow the success response to be sent to the browser, then exit so Passenger starts the real server
          setTimeout(() => {
            console.log('Exiting builder process so Passenger spawns production server...');
            process.exit(0);
          }, 3000);
        } else {
          buildStatus = 'failed';
          buildError = `Build process exited with code ${code}`;
          buildLog += `\nBuild failed with code ${code}.\n`;
          console.error(`Build failed with code ${code}`);
        }
      });
    };

    if (needsInstall) {
      buildLog += 'node_modules or vite not found. Installing dependencies first with npm install...\n';
      console.log('Running npm install inside server container...');
      
      const installProcess = exec('npm install --no-audit --no-fund', {
        cwd: __dirname,
        env: customEnv
      });

      installProcess.stdout.on('data', (data) => {
        buildLog += data.toString();
        console.log(data.toString());
      });

      installProcess.stderr.on('data', (data) => {
        buildLog += data.toString();
        console.error(data.toString());
      });

      installProcess.on('close', (code) => {
        if (code === 0) {
          buildLog += '\nnpm install completed successfully! Now starting the build...\n';
          console.log('npm install succeeded, starting build...');
          startBuildStep();
        } else {
          buildStatus = 'failed';
          buildError = `npm install exited with code ${code}`;
          buildLog += `\nnpm install failed with code ${code}.\n`;
          console.error(`npm install failed with code ${code}`);
        }
      });
    } else {
      startBuildStep();
    }
  };

  // Trigger the build immediately
  runBuild();

  const server = http.createServer((req, res) => {
    // Handle rebuilding from the button
    if (req.method === 'POST' && req.url === '/rebuild') {
      if (buildStatus !== 'building') {
        runBuild();
      }
      res.writeHead(302, { 'Location': '/' });
      return res.end();
    }

    // Handle clean rebuilding (deletes node_modules first)
    if (req.method === 'POST' && req.url === '/clean-rebuild') {
      if (buildStatus !== 'building') {
        buildStatus = 'building';
        buildLog = 'Deletes node_modules to perform a clean installation...\n';
        try {
          const nmPath = path.join(__dirname, 'node_modules');
          if (fs.existsSync(nmPath)) {
            fs.rmSync(nmPath, { recursive: true, force: true });
            buildLog += 'Successfully deleted node_modules!\n';
          } else {
            buildLog += 'node_modules does not exist. Skipping deletion.\n';
          }
        } catch (err) {
          buildLog += `Warning: Failed to delete node_modules directory: ${err.message}\nTrying to run npm install anyway...\n`;
        }
        buildStatus = 'idle'; // Reset so runBuild doesn't bypass
        runBuild();
      }
      res.writeHead(302, { 'Location': '/' });
      return res.end();
    }

    // If the build succeeded, show a restart loading page
    if (buildStatus === 'success') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(`
        <!DOCTYPE html>
        <html lang="sv">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <meta http-equiv="refresh" content="3">
          <title>Coach Assist - Startar om...</title>
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              display: flex;
              justify-content: center;
              align-items: center;
              min-height: 100vh;
              margin: 0;
              background-color: #f3f4f6;
              color: #1f2937;
            }
            .card {
              background: white;
              padding: 2.5rem;
              border-radius: 12px;
              box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
              max-width: 500px;
              width: 90%;
              text-align: center;
            }
            h1 {
              color: #10b981;
              font-size: 1.75rem;
              margin-top: 0;
            }
            .spinner {
              border: 4px solid #f3f4f6;
              border-top: 4px solid #10b981;
              border-radius: 50%;
              width: 45px;
              height: 45px;
              animation: spin 1s linear infinite;
              margin: 2rem auto;
            }
            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          </style>
        </head>
        <body>
          <div class="card">
            <div class="spinner"></div>
            <h1>Bygget lyckades! 🎉</h1>
            <p>Applikationen byggdes framgångsrikt. Servern startar nu om automatiskt med den riktiga koden...</p>
            <p style="font-size: 0.85rem; color: #6b7280;">Sidan laddas om automatiskt om några sekunder.</p>
          </div>
        </body>
        </html>
      `);
    }

    // Default status page while building or failed
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(`
      <!DOCTYPE html>
      <html lang="sv">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        ${buildStatus === 'building' ? '<meta http-equiv="refresh" content="5">' : ''}
        <title>Coach Assist - Bygger applikation</title>
        <style>
          body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: #f3f4f6;
            color: #1f2937;
            margin: 0;
            padding: 2rem 1rem;
          }
          .container {
            max-width: 800px;
            margin: 0 auto;
          }
          .card {
            background: white;
            padding: 2.5rem;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            margin-bottom: 1.5rem;
          }
          h1 {
            font-size: 1.75rem;
            margin-top: 0;
            margin-bottom: 0.5rem;
            color: #2563eb;
          }
          .status-badge {
            display: inline-block;
            background-color: #fef3c7;
            color: #92400e;
            font-size: 0.875rem;
            font-weight: 600;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            margin-bottom: 1.5rem;
          }
          .status-badge.building {
            background-color: #dbeafe;
            color: #1e40af;
            animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
          }
          .status-badge.failed {
            background-color: #fee2e2;
            color: #991b1b;
          }
          @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: .5; }
          }
          .log-container {
            background-color: #1e293b;
            color: #f8fafc;
            padding: 1.25rem;
            border-radius: 8px;
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, monospace;
            font-size: 0.85rem;
            overflow-x: auto;
            white-space: pre-wrap;
            max-height: 400px;
            border: 1px solid #334155;
          }
          .button {
            display: inline-block;
            background-color: #2563eb;
            color: white;
            padding: 0.625rem 1.25rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.875rem;
            border: none;
            cursor: pointer;
            transition: background-color 0.2s;
          }
          .button:hover {
            background-color: #1d4ed8;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="card">
            ${
              buildStatus === 'building' 
                ? '<div class="status-badge building">Bygger applikationen...</div>' 
                : '<div class="status-badge failed">Bygget misslyckades</div>'
            }
            <h1>Coach Assist - Installation pågår</h1>
            <p>
              Eftersom du inte har tillgång till en terminal bygger vi applikationen automatiskt åt dig direkt på servern. Detta skapar de kompilerade produktionsfilerna och tar vanligtvis 15-45 sekunder.
            </p>
            ${
              buildStatus === 'building'
                ? '<p>Sidan laddas om automatiskt var 5:e sekund för att visa förloppet.</p>'
                : `
                <p>Något gick fel under byggprocessen på webbhotellet. Om webbhotellet (t.ex. CloudLinux/cPanel) har strikta minnesgränser kan WebAssembly/Vite krascha vid bygge på servern. <strong>Lösning:</strong> Använd den färdiga produktionspaketeringen <code>coachassist-production-bundle.zip</code> (eller se till att mapparna <code>dist/</code> eller <code>deploy/</code> laddas upp) och klicka sedan på "Run NPM Install" i cPanel.</p>
                <div style="display: flex; gap: 10px; margin-top: 1rem; flex-wrap: wrap;">
                  <form method="POST" action="/rebuild">
                    <button class="button" type="submit">Försök bygga igen</button>
                  </form>
                  <form method="POST" action="/clean-rebuild">
                    <button class="button" style="background-color: #dc2626;" type="submit">Gör en helt ren installation</button>
                  </form>
                </div>
                `
            }
          </div>

          <div class="card">
            <h2 style="margin-top: 0; font-size: 1.25rem; color: #0f172a;">Bygglogg</h2>
            <div class="log-container">${buildLog || 'Väntar på att loggen ska starta...'}</div>
            ${buildError ? `<p style="color: #ef4444; font-weight: bold; margin-top: 1rem;">Fel: ${buildError}</p>` : ''}
          </div>
        </div>
      </body>
      </html>
    `);
  });

  const port = process.env.PORT || 3000;
  server.listen(port, () => {
    console.log(`Fallback server running on port ${port}`);
  });
}
